import Vue from 'vue'
import { ToastPlugin, ModalPlugin } from 'bootstrap-vue'
import VueCompositionAPI from '@vue/composition-api'

// eslint-disable-next-line import/extensions,no-unused-vars
import ToastificationContent from '@core/components/toastification/ToastificationContent'
import messagePlugin from '@/utils/message.plugin'
import VueSweetalert2 from 'vue-sweetalert2'
import router from './router'
import store from './store'
import App from './App.vue'
import './axios'
// eslint-disable-next-line import/order
// Global Components
import './global-components'

// 3rd party plugins
import '@/libs/portal-vue'
import '@/libs/toastification'

// BSV Plugin Registration
Vue.use(ToastPlugin)
Vue.use(ModalPlugin)
Vue.use(VueSweetalert2)

// Composition API
Vue.use(VueCompositionAPI)
// eslint-disable-next-line no-unused-vars

// import core styles
require('@core/scss/core.scss')

// import assets styles
require('@/assets/scss/style.scss')

Vue.config.productionTip = false
Vue.use(messagePlugin)
new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
