// eslint-disable-next-line import/extensions
import ToastificationContent from '@core/components/toastification/ToastificationContent'

export default {
  // eslint-disable-next-line no-unused-vars
  install: (Vue, options) => {
    // eslint-disable-next-line no-param-reassign
    Vue.prototype.$message = function (title, text, icon, variant) {
      this.$toast({
        component: ToastificationContent,
        props: {
          title,
          text,
          icon,
          variant,
        },
      })
    }
  },
}
