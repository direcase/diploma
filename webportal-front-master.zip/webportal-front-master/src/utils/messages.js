export default {
  /* eslint-disable */
  'login' :{
    title : 'Войдите в систему',
    text : 'Чтобы продолжить, войдите в систему',
    icon : 'LogInIcon',
    variant : 'primary'
  },
  'logged' :{
    title : 'Вы успешно вошли 😎',
    text : 'Вы успешно вошли в систему',
    icon : 'LogInIcon',
    variant : 'success'
  },
  'auth/token-expired' : {
    title : 'Срок действия токена истек ⏰',
    text : 'Войдите в систему заново',
    icon : 'WatchIcon',
    'variant' : 'danger'
  },
  'service-center/exists-by-name': {
    title : 'Сервисный центр с таким названием уже существует',
    text : 'Сервисный центр с таким названием уже существует',
    icon : 'Edit2Icon',
    'variant' : 'danger'
  },
  'validation/failed': {
    title : 'Валидация провалена',
    text : 'Проверьте данные',
    icon : 'Edit2Icon',
    'variant' : 'danger'
  },
  'data/not-delete': {
    title : 'Невозможно удалить',
    text : 'Невозможно удалить так как он уже используется',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'service-center/not-found': {
    title : 'Не найдено',
    text : 'Сервисный центр с этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'user/exists-by-username': {
    title : 'Невозможно добавить',
    text : 'Пользователь с таким логином уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'experience-model/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Опыт с таким названием уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'experience-model/exists-by-coefficient': {
    title : 'Невозможно добавить',
    text : 'Опыт с таким процентом уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'service-center/not-active': {
    title : 'Невозможно авторизоваться',
    text : 'Ваш сервисный центр не активен',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'service-center/not-active-token': {
    title : 'Обратитесь к администратору',
    text : 'Ваш сервисный центр не активен',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'user/not-found': {
    title : 'Не найдено',
    text : 'Пользователь с этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'logout' :{
    title : 'Вы вышли из системы 👋',
    text : 'Вы вышли из системы',
    icon : 'LogOutIcon',
    variant : 'success'
  },
  'auth/invalid-username-and-password' :{
    title : 'Неверный логин или пароль 🤯',
    text : 'Введите корректный логин и пароль',
    icon : 'AlertTriangleIcon',
    variant : 'danger'
  },
  'notpermitted' :{
    title : 'Не разрешено ✋',
    text : 'У вас нет доступа к данной странице',
    icon : 'AlertTriangleIcon',
    variant : 'danger'
  },
  'type/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Тип устройства с таким названием уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'type/not-found': {
    title : 'Не найдено',
    text : 'Тип устройства c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'model/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Модель устройства с таким названием уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'model/not-found': {
    title : 'Не найдено',
    text : 'Модель устройства c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'discount/not-found': {
    title : 'Не найдено',
    text : 'Скидка c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'discount/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Скидка с таким названием уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'discount/exists-by-percent': {
    title : 'Невозможно добавить',
    text : 'Скидка с таким процентом уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'client/not-found': {
    title : 'Не найдено',
    text : 'Клиент c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'provider/not-found': {
    title : 'Не найдено',
    text : 'Поставщик c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'provider/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Поставщик с таким именем уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'service/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Услуга с таким наименованием уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'service/not-found': {
    title : 'Не найдено',
    text : 'Услуга c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'product/exists-by-name': {
    title : 'Невозможно добавить',
    text : 'Товар с таким наименованием уже существует',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'product/not-found': {
    title : 'Не найдено',
    text : 'Товар c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'product/incoming-history/not-enough-in-storage': {
    title : 'Невозможно удалить историю добавление так как на складе недостаточно товаров.',
    text : 'Товар c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'order/not-found': {
    title : 'Не найдено',
    text : 'Заказ c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'storage/product-not-enough': {
    title : 'Невозможно добавить',
    text : 'Не хватает товаров на складе.',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'order/status-not-change': {
    title : 'Невозможно изменить статус заказа.',
    text : '',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'order/notified': {
    title : 'Клиент уже уведомлен',
    text : 'Клиент уже уведомлен',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'order/not-notified': {
    title : 'Клиент не уведомлен',
    text : 'Мы не смогли отправить смс попробуйте позже',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'order-item/not-found': {
    title : 'Не найдено',
    text : 'Элемент заказа c этим идентификатором не найдено',
    icon : 'DatabaseIcon',
    'variant' : 'danger'
  },
  'user/not-active': {
    title : 'Не активен',
    text : 'Ваш аккаунт не активен. Обратитесь к администратору',
    icon : 'UserXIcon',
    'variant' : 'danger'
  },
}
