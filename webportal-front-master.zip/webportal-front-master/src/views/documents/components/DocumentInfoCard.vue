<template>
  <b-card>

    <b-row>
      <!-- User Info: Left col -->
      <b-col
        cols="21"
        xl="6"
        class="d-flex justify-content-between flex-column"
      >
        <!-- User Avatar & Action Buttons -->
        <div class="d-flex justify-content-start">
          <b-avatar
            :text="'ES'"
            :variant="'light-success'"
            size="104px"
            rounded
          />
          <div class="d-flex flex-column ml-1">
            <div class="mb-1">
              <h4
                class="mb-0"
              >
                {{ getDocumentType() }}
              </h4>
            </div>
            <div class="d-flex flex-wrap">
              <b-button
                variant="gradient-primary"
                class="btn-icon mr-1"
                @click="open"
              >
                <feather-icon icon="ExternalLinkIcon" />
              </b-button>
              <b-button
                variant="gradient-success"
                class="btn-icon mr-1"
                size="md"
                @click="download"
              >
                <feather-icon icon="DownloadIcon" />
              </b-button>
            </div>
          </div>
        </div>
        <!-- Order Buttons -->
        <div class="d-flex align-items-center">
          <document-buttons
            :document="document"
            @print="print"
            @sign="sign"
          />
        </div>
      </b-col>

      <!-- Right Col: Table -->
      <b-col
        cols="12"
        xl="6"
      >
        <table class="mt-2 mt-xl-0 w-100">
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="ClipboardIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Тип Документа</span>
            </th>
            <td class="pb-50">
              {{ getDocumentType() }}
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="CheckIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Статус</span>
            </th>
            <td class="pb-50 text-capitalize">
              <b-badge
                pill
                :variant="getDocumentStatusVariant()"
              >
                {{ getDocumentStatus() }}
              </b-badge>
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="MenuIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Заказ</span>
            </th>
            <b-link :to="'/orders/'+document.order.id">
              <td class="pb-50">
                № {{ document.order.id }}
              </td>
            </b-link>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="UserIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Клиент</span>
            </th>
            <b-link
              v-if="user.roles.includes('MODERATOR')&&document.order.client"
              :to="'/clients/'+document.order.client.id"
            >
              <td class="mb-0">
                {{ getClientName() }}
              </td>
            </b-link>
            <td
              v-else
              class="mb-0"
            >
              {{ getClientName() }}
            </td>
          </tr>
        </table>
      </b-col>
    </b-row>
  </b-card>
</template>

<script>
import {
  BCard, BButton, BAvatar, BBadge, BRow, BCol, BLink,
} from 'bootstrap-vue'
import { avatarText } from '@core/utils/filter'
import DocumentButtons from '@/views/documents/components/DocumentButtons.vue'
import util from '@/views/documents/utils/documentUtil'
import orderUtil from '@/views/orders/utils/orderUtil'
import fonts from '@/utils/fonts'
import jsPDF from 'jspdf'
import 'jspdf-autotable'

export default {
  components: {
    BCard, BButton, BRow, BCol, BAvatar, BBadge, BLink, DocumentButtons,
  },
  props: {
    document: {
      type: Object,
    },
  },
  mounted() {
    console.log('MOUNTED', this.document)
    this.order = this.document.order
  },
  setup() {
    return {
      avatarText,
    }
  },
  computed: {
    user() {
      return this.$store.getters.user
    },
  },
  methods: {
    print() {
      this.$emit('print')
    },
    sign() {
      this.$emit('sign')
    },
    certificateGenerator(documentType, type) {
      if (documentType === 'ACCEPTANCE_CERTIFICATE') {
        this.acceptanceCertificateGenerator(type)
      }
      if (documentType === 'CERTIFICATE_OF_COMPLETION') {
        this.certificateOfCompletionGenerator(type)
      }
    },
    setFontToJsPdf(doc) {
      doc.addFileToVFS('Roboto-Black.ttf', fonts['Roboto-Black'])
      doc.addFont('Roboto-Black.ttf', 'roboto-black', 'normal')
      doc.addFileToVFS('Roboto-Italic.ttf', fonts['Roboto-Italic'])
      doc.addFont('Roboto-Italic.ttf', 'roboto-italic', 'normal')
      doc.addFileToVFS('Roboto-Light.ttf', fonts['Roboto-Light'])
      doc.addFont('Roboto-Light.ttf', 'roboto-light', 'normal')
      doc.addFileToVFS('Roboto-BlackItalic.ttf', fonts['Roboto-BlackItalic'])
      doc.addFont('Roboto-BlackItalic.ttf', 'roboto-black-italic', 'normal')
    },
    setHeaderToJsPdf(doc) {
      // Service Center Name
      doc.setFont('roboto-black')
        .setFontSize(12)
        .text(14, 12, `Сервисный центр "${this.order.serviceCenter.name}"`)

      // Address
      doc.setFont('roboto-light')
        .setFontSize(10)
        .text(14, 18, `Адрес: ${this.order.serviceCenter.address}, тел: ${this.order.serviceCenter.phoneNumber}`)

      // Email
      doc.setFont('roboto-light')
        .setFontSize(10)
        .text(14, 24, `Email: ${this.order.serviceCenter.email}`)

      // Line
      doc.setLineWidth(0.01).line(14, 30, 196, 30)
    },
    acceptanceCertificateGenerator(type) {
      // eslint-disable-next-line new-cap
      // eslint-disable-next-line new-cap
      const doc = new jsPDF()
      // Adding fonts
      this.setFontToJsPdf(doc)
      // set Header
      this.setHeaderToJsPdf(doc)
      // Номер квитанций
      doc.setFont('roboto-black')
        .setFontSize(11)
        .text(14, 36, `Квитанция о приемке № ${this.order.id} от ${this.getDateByFormat(this.order.acceptedDate, 'date')}`)
      // Table
      doc.autoTable({
        startY: 42,
        theme: 'grid',
        // Border color Black
        // bodyStyles: { lineColor: [0, 0, 0] },
        body: [
          ['Клиент: ', this.getName()],
          ['Тел: ', this.getNumber()],
          ['Адрес: ', ''],
          ['Устройство: ', this.getType()],
          ['Сер.№(IMEI): ', this.order.serialNumber || ''],
          ['Комплектность: ', ''],
          ['Дата приемки: ', this.getDateByFormat(this.order.acceptedDate, 'date')],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })

      let lastY = doc.autoTable.previous.finalY + 5

      const width = doc.internal.pageSize.getWidth()

      doc.setFont('roboto-black').setFontSize(11).text('Заявленные неисправности', width / 2, lastY, { align: 'center' })
      lastY += 3
      doc.autoTable({
        startY: lastY,
        theme: 'grid',
        body: [
          [this.order.problem],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      lastY = doc.autoTable.previous.finalY + 5
      doc.setFont('roboto-black').setFontSize(11).text('Примечания', width / 2, lastY, { align: 'center' })
      lastY += 3
      doc.autoTable({
        startY: lastY,
        theme: 'grid',
        body: [
          [''],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      lastY = doc.autoTable.previous.finalY + 5
      doc.setFont('roboto-black').setFontSize(11).text('Условия ремонта', width / 2, lastY, { align: 'center' })
      lastY += 3
      doc.autoTable({
        startY: lastY,
        theme: 'grid',
        body: [
          ['1. Ремонт техники со спедами влаги, коррозии, ударов, падений - выполняется без гарантийных обязательств (БЕЗ ГАРАНТИИ навыполненый ремонт)\n'
          + '2. Ремонт производится только на заявленые неисправности клиентом\n'
          + '3. Исполнитель не несет ответственность за сохранность информации на аппарате и его носителях памяти\n'
          + '4. Аппарат с сотпасия клиента принят без разборки и проверки внутренних повреждений. Клиент понимает, что все неисправности и внутр. повреждения, которые могут быть обнаружены в аппарате при его техническом обслуживании, возникли до приема аппарата в ремонт.\n'
          + '5. Клиент принимает на себя риск возможной полной или частичной утраты работоспособности аппарата в процессе ремонта в случае грубых нарушений пользователем условий эксллуатации,наличия следов коррозии, попадания влаги, либо механических воздействий'],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      doc.setDrawColor('black')

      lastY = doc.autoTable.previous.finalY + 10
      doc.setFont('roboto-black').setFontSize(10.5).text('Подпись клиента', 14, lastY)

      lastY += 3
      doc.setLineWidth(0.01).line(14, lastY, 196, lastY)

      lastY += 7
      doc.setFont('roboto-black').setFontSize(10.5).text('Подпись исполнителя', 14, lastY)

      lastY += 3
      doc.setLineWidth(0.01).line(14, lastY, 196, lastY)
      doc.setProperties({ title: `Акт Приемки Перадачи заказа №${this.order.id}` })
      if (type.includes('open')) { doc.output('dataurlnewwindow') }
      if (type.includes('download')) doc.save(`Акт Приемки Перадачи заказа №${this.order.id}.pdf`)
    },
    certificateOfCompletionGenerator(type) {
      // eslint-disable-next-line new-cap
      // eslint-disable-next-line new-cap
      const doc = new jsPDF()
      // Ширина
      const width = doc.internal.pageSize.getWidth()
      // Adding fonts
      this.setFontToJsPdf(doc)
      // set Header
      this.setHeaderToJsPdf(doc)
      // Акт выполненных работ номер текст
      // Номер квитанций
      doc.setFont('roboto-black')
        .setFontSize(11)
        .text(`Акт выполненных работ № ${this.order.id} от ${this.getDateByFormat(this.order.acceptedDate, 'date')}`, width / 2, 36, { align: 'center' })
      // Table
      // Table
      doc.autoTable({
        startY: 42,
        theme: 'grid',
        // Border color Black
        // bodyStyles: { lineColor: [0, 0, 0] },
        body: [
          ['Клиент: ', this.getName()],
          ['Тел: ', this.getNumber()],
          ['Адрес: ', ''],
          ['Устройство: ', this.getType()],
          ['Сер.№(IMEI): ', this.order.serialNumber || ''],
          ['Комплектность: ', ''],
          ['Дата выдачи: ', this.getDateByFormat(this.order.gaveDate, 'datetime')],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      let lastY = doc.autoTable.previous.finalY + 5

      doc.setFont('roboto-black').setFontSize(11).text(14, lastY, 'Выполненные работы:')
      // Order Items
      const discount = this.order.discountPercent
      this.order.items.forEach(item => {
        lastY += 5
        if (item.service) {
          if (discount === 0) doc.setFont('roboto-italic').setFontSize(10.5).text(28, lastY, `${item.service.name} - ${Number.parseFloat(item.soldPrice).toFixed(2)} KZT * ${item.quantity} = ${Number.parseFloat(this.getItemTotal(item, discount)).toFixed(2)} KZT`)
          if (discount > 0) doc.setFont('roboto-italic').setFontSize(10.5).text(28, lastY, `${item.service.name} - (${Number.parseFloat(item.soldPrice).toFixed(2)} KZT * ${item.quantity}) - ${discount}% = ${Number.parseFloat(this.getItemTotal(item, discount)).toFixed(2)} KZT`)
        } else {
          doc.setFont('roboto-italic').setFontSize(10.5).text(28, lastY, `${item.product.name} - ${Number.parseFloat(item.soldPrice).toFixed(2)} KZT * ${item.quantity} = ${Number.parseFloat(this.getItemTotal(item, discount)).toFixed(2)} KZT`)
        }
      })
      // Total Amount
      lastY += 10
      doc.setFont('roboto-black-italic').setFontSize(11).text(14, lastY, `Итоговая стоимость ремонта: ${this.getTotalAmount(this.order.items, discount)} KZT`)
      // Текст не имею притензий
      lastY += 5
      doc.setFont('roboto-italic').setFontSize(10).text(14, lastY, 'Работа выполнена полностью и в срок, к качеству претензий не имею')
      // Линия подпися клиента
      doc.setDrawColor('black')
      doc.setLineWidth(0.02).line(150, lastY, 196, lastY)
      // Текст под линие подпися
      lastY += 4
      doc.setFont('roboto-italic').setFontSize(9).text('подпись клиента', 173, lastY, { align: 'center' })
      lastY += 7
      doc.setFont('roboto-black').setFontSize(11).text(14, lastY, 'Подпись исполнителя')
      doc.setProperties({ title: `Акт Выполненных Работ заказа №${this.order.id}.pdf` })
      if (type.includes('open')) { doc.output('dataurlnewwindow') }
      if (type.includes('download')) doc.save(`Акт Выполненных Работ заказа №${this.order.id}.pdf`)
    },
    getName() {
      if (this.order.client) {
        return `${this.order.client.surname} ${this.order.client.name}`
      }
      return this.order.clientName
    },
    getItemTotal(item, discountPercent) {
      let sum = 0
      if (item.service) {
        sum = item.soldPrice * item.quantity * ((100 - discountPercent) / 100)
      } else {
        sum = item.soldPrice * item.quantity
      }
      return sum
    },
    getTotalAmount(items, discountPercent) {
      let sum = 0
      items.forEach(item => {
        sum += this.getItemTotal(item, discountPercent)
      })
      return Number.parseFloat(sum).toFixed(2)
    },
    getNumber() {
      if (this.order.client) {
        return `${this.order.client.phoneNumber}`
      }
      return this.order.phoneNumber
    },
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = '2-digit'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
    getType() {
      return `${this.order.type.name} ${this.order.model.name} ${this.order.modelCompany}`
    },
    open() {
      this.certificateGenerator(this.document.documentType, 'open')
    },
    download() {
      this.certificateGenerator(this.document.documentType, 'download')
    },
    // eslint-disable-next-line consistent-return
    getDocumentType() {
      return util.getDocumentType(this.document.documentType)
    },
    // eslint-disable-next-line consistent-return
    getDocumentStatus() {
      return util.getDocumentStatus(this.document.documentStatus)
    },
    // eslint-disable-next-line consistent-return
    getDocumentStatusVariant() {
      return util.getDocumentStatusVariant(this.document.documentStatus)
    },
    getClientName() {
      return orderUtil.getName(this.document.order)
    },
    deleteDocument() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(result => {
        if (result.value) {
          this.$emit('deleteDocument')
        }
      })
    },
  },
}
</script>

<style>

</style>
