<template>
  <b-card title="Даты">
    <app-timeline>
      <!-- 12 INVOICES HAVE BEEN PAID -->
      <app-timeline-item variant="warning">
        <div class="d-flex flex-sm-row flex-column flex-wrap justify-content-between mb-1 mb-sm-0">
          <h6>Создан</h6>
          <small class="text-muted">{{ getRelativeTime(document.created) }}</small>
        </div>
        <p>{{ getDateByFormat(document.created, 'datetime') }}</p>
      </app-timeline-item>
      <app-timeline-item
        v-if="document.printed"
        variant="primary"
      >
        <div class="d-flex flex-sm-row flex-column flex-wrap justify-content-between mb-1 mb-sm-0">
          <h6>Распечатан</h6>
          <small class="text-muted">{{ getRelativeTime(document.printed) }}</small>
        </div>
        <p>{{ getDateByFormat(document.printed, 'datetime') }}</p>
      </app-timeline-item>
      <app-timeline-item
        v-if="document.signed"
        variant="success"
      >
        <div class="d-flex flex-sm-row flex-column flex-wrap justify-content-between mb-1 mb-sm-0">
          <h6>Подписан</h6>
          <small class="text-muted">{{ getRelativeTime(document.signed) }}</small>
        </div>
        <p>{{ getDateByFormat(document.signed, 'datetime') }}</p>
      </app-timeline-item>
    </app-timeline></b-card>
</template>

<script>
import {
  BCard,
} from 'bootstrap-vue'
import AppTimeline from '@core/components/app-timeline/AppTimeline.vue'
import AppTimelineItem from '@core/components/app-timeline/AppTimelineItem.vue'
import moment from 'moment'

export default {
  components: {
    BCard,
    AppTimeline,
    AppTimelineItem,
  },
  props: {
    document: {
      type: Object,
      required: true,
    },
  },
  methods: {
    getRelativeTime(date) {
      const d = new Date(date)
      moment.locale('ru-RU')
      return moment(d).fromNow()
    },
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = 'long'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
  },
}
</script>

<style>

</style>
