<template>
  <div class="demo-inline-spacing">
    <b-button
      v-if="document.documentStatus === 'CREATED'"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="warning"
      @click="print"
    >
      <feather-icon
        icon="PrinterIcon"
        class="mr-50"
      />
      <span class="align-middle">Распечатан</span>
    </b-button>
    <b-button
      v-if="document.documentStatus === 'PRINTED'"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="success"
      @click="sign"
    >
      <feather-icon
        icon="Edit3Icon"
        class="mr-50"
      />
      <span class="align-middle">Подписан</span>
    </b-button>
  </div>
</template>

<script>
import { BButton } from 'bootstrap-vue'
import Ripple from 'vue-ripple-directive'
import 'jspdf-autotable'

export default {
  components: {
    BButton,
  },
  directives: {
    Ripple,
  },
  props: {
    document: {
      type: Object,
    },
  },
  data: () => ({
  }),
  computed: {
  },
  methods: {
    sign() {
      this.$emit('sign')
    },
    print() {
      this.$emit('print')
    },
  },
}
</script>
