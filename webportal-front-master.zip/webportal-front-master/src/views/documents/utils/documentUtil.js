// eslint-disable-next-line consistent-return,no-unused-vars
function getDocumentType(data) {
  if (data === 'ACCEPTANCE_CERTIFICATE') return 'Акт приемки передачи'
  if (data === 'CERTIFICATE_OF_COMPLETION') return 'Акт выполненных работ'
}

// eslint-disable-next-line consistent-return,no-unused-vars
function getDocumentStatus(data) {
  if (data === 'CREATED') return 'Создан'
  if (data === 'PRINTED') return 'Распечатан'
  if (data === 'SIGNED') return 'Подписан'
}

// eslint-disable-next-line consistent-return,no-unused-vars
function getDocumentStatusVariant(data) {
  if (data === 'CREATED') return 'danger'
  if (data === 'PRINTED') return 'warning'
  if (data === 'SIGNED') return 'success'
}

module.exports = {
  getDocumentType,
  getDocumentStatus,
  getDocumentStatusVariant,
}
