<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="document === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного документа с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/documents'"
          >
            Список документов
          </b-link>
        </div>
      </b-alert>

      <template v-if="document">
        <hr>
        <h3>{{ getDocumentType() }}</h3>
        <hr>
        <b-row>
          <b-col
            cols="12"
            xl="7"
            lg="7"
            md="7"
          >
            <document-info-card
              :document="document"
              @print="print"
              @sign="sign"
            />
          </b-col>
          <b-col
            cols="12"
            md="5"
            xl="5"
            lg="5"
          >
            <document-time-line :document="document" />
          </b-col>
        </b-row>
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BRow, BCol,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import DocumentInfoCard from '@/views/documents/components/DocumentInfoCard.vue'
import DocumentTimeLine from '@/views/documents/components/DocumentTimeLine.vue'
import documentUtil from '@/views/documents/utils/documentUtil'

export default {
  components: {
    // eslint-disable-next-line vue/no-unused-components
    Loader,
    BRow,
    BCol,
    BAlert,
    BLink,
    DocumentTimeLine,
    DocumentInfoCard,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    document: {},
    loader: true,
  }),
  async mounted() {
    try {
      await this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    getDocumentType() {
      return documentUtil.getDocumentType(this.document.documentType)
    },
    deleteDocument() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteDocument', this.discount.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Докумен удален с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/documents')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    async print() {
      try {
        const sendData = {}
        sendData.orderId = this.document.order.id
        sendData.documentId = this.document.id
        sendData.documentStatus = 'PRINTED'
        const data = await this.$store.dispatch('changeDocumentStatus', sendData)
        this.document = data
        this.$message('Статус Документа успешно изменен', 'Статус Документа успешно изменен', 'PrinterIcon', 'success')
        // eslint-disable-next-line no-empty
      } catch (e) {
      }
    },
    async sign() {
      try {
        const sendData = {}
        sendData.orderId = this.document.order.id
        sendData.documentId = this.document.id
        sendData.documentStatus = 'SIGNED'
        const data = await this.$store.dispatch('changeDocumentStatus', sendData)
        this.document = data
        this.$message('Статус Документа успешно изменен', 'Статус Документа успешно изменен', 'Edit3Icon', 'success')
        // eslint-disable-next-line no-empty
      } catch (e) {
      }
    },
    async fetchAllData() {
      this.loader = true
      this.document = await this.$store.dispatch('fetchDocumentById', this.$route.params.id)
      this.loader = false
    },
  },
}
</script>

<style>

</style>
