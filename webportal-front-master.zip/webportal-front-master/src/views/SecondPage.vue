<template>
  <b-card title="Create Awesome 🙌">
    <b-card-text>This is your second page.</b-card-text>
    <b-card-text>Chocolate sesame snaps pie carrot cake pastry pie lollipop muffin. Carrot cake dragée chupa chups jujubes. Macaroon liquorice cookie wafer tart marzipan bonbon. Gingerbread jelly-o dragée chocolate.</b-card-text>
  </b-card>
</template>

<script>
import { BCard, BCardText } from 'bootstrap-vue'
/* import messages from '@/utils/messages' */

export default {
  components: {
    BCard,
    BCardText,
  },
  watch: {
    // eslint-disable-next-line no-unused-vars
    /* $route(to, from) {
      if (to.query.message) {
        this.$message(messages[to.query.message].title, messages[to.query.message].text, messages[to.query.message].icon, messages[to.query.message].variant)
      }
    }, */
  },
}
</script>

<style>

</style>
