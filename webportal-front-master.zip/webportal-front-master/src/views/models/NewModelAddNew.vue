<template>
  <b-modal
    id="modal-scrollable"
    ref="modal"
    scrollable
    centered
    title="Добавить новую модель 💻"
    cancel-title="Отменить"
    ok-title="Добавить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Наименование скидки"
          rules="required"
        >
          <b-form-group
            label="наименование модели"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="TagIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="modelData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'DiscountAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankModelData = {
      name: '',
    }
    const modelData = ref(JSON.parse(JSON.stringify(blankModelData)))
    const resetOrderData = () => {
      modelData.value = JSON.parse(JSON.stringify(modelData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      modelData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    resetModelData() {
      this.modelData.name = ''
    },
    reset() {
      this.resetModelData()
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('addModel', this.modelData)
        this.$message(`Модель ${data.name} успешно добавлен в базу`, `${data.name} успешно добавлен в базу`, 'DatabaseIcon', 'success')
        this.validation = {}
        this.$emit('addModel', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
