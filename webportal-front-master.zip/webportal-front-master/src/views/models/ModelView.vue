<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="model === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одной модели с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/models'"
          >
            Список моделей
          </b-link>
        </div>
      </b-alert>

      <template v-if="model">
        <new-model-update
          ref="updateModal"
          :model="model"
          @updateModel="updateModel"
        />
        <hr>
        <h3>{{ model.name }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3"
            @click="showUpdateModal"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteModel"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="success"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <model-info-card
          :model="model"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import NewModelUpdate from '@/views/models/components/NewModelUpdate.vue'
import ModelInfoCard from '@/views/models/components/ModelInfoCard.vue'

export default {
  components: {
    // eslint-disable-next-line vue/no-unused-components
    NewModelUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    ModelInfoCard,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    model: {},
    loader: true,
  }),
  async mounted() {
    try {
      await this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    updateModel(data) {
      if (data) {
        this.model = data
      }
    },
    deleteModel() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteModel', this.model.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Модель удалена с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/models')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    async fetchAllData() {
      this.loader = true
      this.model = await this.$store.dispatch('fetchModelById', this.$route.params.id)
      this.loader = false
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
