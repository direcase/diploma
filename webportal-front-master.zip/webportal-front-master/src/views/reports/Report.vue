<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <b-row>
        <b-col
          cols="12"
          xl="6"
          md="6"
          sm="12"
        >
          <b-card title="Отчет по мастерской 🏢">
            <b-card-text>Заполните форму чтобы получит отчет</b-card-text>
            <b-form
              class="auth-login-form mt-2"
              @submit.prevent="firstReportHandler"
            >
              <label for="date1">Выберите Дату *</label>
              <b-form-datepicker
                id="date1"
                v-model="reportOrder.date1"
                label-no-date-selected="Дата не выбрана"
                required
                label-help="Используйте клавиши курсора для навигации по календарным датам"
                class="mb-2"
              />
              <label for="date2">Выберите Дату *</label>
              <b-form-datepicker
                id="date2"
                v-model="reportOrder.date2"
                required
                label-no-date-selected="Дата не выбрана"
                label-help="Используйте клавиши курсора для навигации по календарным датам"
                class="mb-2"
                orientation="bottom"
              />
              <div>
                <b-form-group>
                  <label for="status1">Статус *</label>
                  <v-select
                    id="status1"
                    v-model="reportOrder.status"
                    :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
                    :options="statusOptions"
                    label="title"
                  >
                    <template #option="{ title, icon }">
                      <feather-icon
                        :icon="icon"
                        size="16"
                        class="align-middle mr-50"
                      />
                      <span> {{ title }}</span>
                    </template>
                  </v-select>
                </b-form-group>
              </div>
              <br>
              <div>
                <b-button
                  type="submit"
                  variant="primary"
                  block
                >
                  Сформировать
                </b-button>
              </div>
            </b-form>
          </b-card>
        </b-col>

        <b-col
          cols="12"
          xl="6"
          md="6"
          sm="12"
        >
          <b-card title="Отчет по мастеру 🧑‍💼">
            <b-card-text>Заполните форму чтобы получит отчет</b-card-text>
            <b-form
              class="auth-login-form mt-2"
              @submit.prevent="secondReportHandler"
            >
              <label for="date1">Выберите Дату *</label>
              <b-form-datepicker
                id="reportSalaryDate1"
                v-model="reportSalary.date1"
                label-no-date-selected="Дата не выбрана"
                required
                label-help="Используйте клавиши курсора для навигации по календарным датам"
                class="mb-2"
              />
              <label for="date2">Выберите Дату *</label>
              <b-form-datepicker
                id="reportSalaryDate2"
                v-model="reportSalary.date2"
                required
                label-no-date-selected="Дата не выбрана"
                label-help="Используйте клавиши курсора для навигации по календарным датам"
                class="mb-2"
                orientation="bottom"
              />
              <b-form-group
                label="Мастер *"
                label-for="users"
              >
                <v-select
                  v-model="reportSalary.user"
                  :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
                  :options="userOptions"
                  :reduce="val => val.value"
                  :clearable="false"
                  label="surname"
                  input-id="users"
                >
                  <template
                    slot="option"
                    slot-scope="option"
                  >
                    {{ option.surname + ' ' + option.name }}
                  </template>
                  <template
                    slot="selected-option"
                    slot-scope="option"
                  >
                    {{ option.surname + ' ' + option.name }}
                  </template>
                </v-select>
                <p
                  v-if="validation.userId"
                  class="text-danger"
                >
                  {{ validation.userId }}
                </p>
              </b-form-group>
              <br>
              <div>
                <b-button
                  type="submit"
                  variant="primary"
                  block
                >
                  Сформировать
                </b-button>
              </div>
            </b-form>
          </b-card>
        </b-col>
        <!--    <b-card title="Want to integrate JWT? 🔒">
      <b-card-text>We carefully crafted JWT flow so you can implement JWT with ease and with minimum efforts.</b-card-text>
      <b-card-text>Please read our  JWT Documentation to get more out of JWT authentication.</b-card-text>
    </b-card>-->
      </b-row>
    </div>
  </div>
</template>

<script>
import vSelect from 'vue-select'
import {
  BCard, BCardText, BForm, BButton, BFormDatepicker, BFormGroup, BRow, BCol,
} from 'bootstrap-vue'
import Loader from '@/layouts/components/Loader.vue'

export default {
  components: {
    BCard,
    BRow,
    BCol,
    BFormGroup,
    BCardText,
    BForm,
    BFormDatepicker,
    BButton,
    vSelect,
    Loader,
  },
  data() {
    return {
      reportOrder: {
        date1: null,
        date2: null,
        status: {
          title: 'Выдано',
          value: 'given',
          icon: 'CheckSquareIcon',
        },
      },
      reportSalary: {
        date1: null,
        date2: null,
        user: null,
      },
      validation: {},
      userOptions: [],
      loader: true,
      statusOptions: [
        {
          title: 'Принято',
          value: 'accepted',
          icon: 'PackageIcon',
        },
        {
          title: 'Сделано ',
          value: 'done',
          icon: 'SettingsIcon',
        },
        {
          title: 'Выдано',
          value: 'given',
          icon: 'CheckSquareIcon',
        },
      ],
    }
  },
  async mounted() {
    this.loader = true
    this.userOptions = await this.$store.dispatch('fetchAllUsersForSelect')
    this.loader = false
  },
  methods: {
    async firstReportHandler() {
      try {
        // eslint-disable-next-line default-case
        switch (this.reportOrder.status.value) {
          case 'accepted':
            await this.$router.push(`/report-accepted?date1=${this.reportOrder.date1}&date2=${this.reportOrder.date2}&size=10&page=1&sortBy=orderId&sortDirection=desc`)
            break
          case 'done':
            await this.$router.push(`/report-done?date1=${this.reportOrder.date1}&date2=${this.reportOrder.date2}&size=10&page=1&sortBy=orderId&sortDirection=desc`)
            break
          case 'given':
            await this.$router.push(`/report-given?date1=${this.reportOrder.date1}&date2=${this.reportOrder.date2}&size=10&page=1&sortBy=orderId&sortDirection=desc`)
            break
          default:
            this.$message('Произошла ошибка повторите еще раз', 'Произошла ошибка повторите еще раз', 'AlertCircleIcon', 'danger')
        }
        // eslint-disable-next-line no-empty
      } catch (e) {
      }
    },
    async secondReportHandler() {
      try {
        await this.$router.push(`/report-salary?date1=${this.reportSalary.date1}&date2=${this.reportSalary.date2}&userId=${this.reportSalary.user}`)
        // eslint-disable-next-line no-empty
      } catch (e) {
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';
</style>
