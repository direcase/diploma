<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="UserIcon"
          :statistic="client.surname+' '+client.name"
          statistic-title="ФИО Клиента"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <b-link :href="'tel:'+client.phoneNumber">
          <statistic-card-vertical
            color="primary"
            icon="PhoneIcon"
            :statistic="client.phoneNumber"
            statistic-title="Телефон Клиента"
          />
        </b-link>
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <b-link :to="'/discounts/'+client.discount.id">
          <statistic-card-vertical
            color="success"
            icon="PercentIcon"
            :statistic="client.discount.discountName"
            statistic-title="Скидка"
          />
        </b-link>
      </b-col>
    </b-row>
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol, BLink,
} from 'bootstrap-vue'

export default {
  components: {
    BRow,
    BLink,
    BCol,
    StatisticCardVertical,
  },
  props: {
    client: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  methods: {
  },
}
</script>

<style>

</style>
