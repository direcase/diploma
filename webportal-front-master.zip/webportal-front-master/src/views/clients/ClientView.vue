<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="client === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного клиента с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/clients'"
          >
            Список Клиентов
          </b-link>
        </div>
      </b-alert>

      <template v-if="client">
        <new-client-update
          ref="updateModal"
          :client="client"
          :discount-options="discountOptions"
          @updateClient="updateClient"
        />
        <hr>
        <h3>{{ client.surname+' ' + client.name }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3"
            @click="showUpdateModal"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteDiscount"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="success"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <client-info-card
          :client="client"
        />
        <client-orders
          :client="client"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import NewClientUpdate from '@/views/clients/components/NewClientUpdate.vue'
import ClientInfoCard from '@/views/clients/components/ClientInfoCard.vue'
import ClientOrders from '@/views/clients/components/ClientOrders.vue'

export default {
  components: {
    // eslint-disable-next-line vue/no-unused-components
    NewClientUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    ClientInfoCard,
    ClientOrders,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    client: {},
    discountOptions: [],
    clientOrders: [],
    loader: true,
  }),

  async mounted() {
    try {
      await this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    deleteDiscount() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteClient', this.client.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Клиент удалена с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/clients')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    updateClient(data) {
      if (data) {
        this.client = data
      }
    },
    async fetchAllData() {
      this.loader = true
      this.client = await this.$store.dispatch('fetchClientById', this.$route.params.id)
      this.discountOptions = await this.$store.dispatch('fetchAllDiscounts')
      this.loader = false
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
