<template>
  <b-modal
    id="modal-tall"
    ref="modal"
    centered
    title="Добавить нового клиента 💁"
    cancel-title="Отменить"
    ok-title="Добавить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Client Name -->
        <validation-provider
          #default="validationContext"
          name="Имя клиента"
          rules="required"
        >
          <b-form-group
            label="Имя клиента"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="UserIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="clientData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Client Name -->
        <validation-provider
          #default="validationContext"
          name="Фамилия клиента"
          rules="required"
        >
          <b-form-group
            label="Фамилия клиента"
            label-for="surname"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="UserIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="surname"
                v-model="clientData.surname"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.surname"
              class="text-danger"
            >
              {{ validation.surname }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <validation-provider
          #default="validationContext"
          name="Тел. Клиента"
          rules="required"
        >
          <b-form-group
            label="Тел. Клиента"
            label-for="phoneNumber"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PhoneIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="phoneNumber"
                v-model.number="clientData.phoneNumber"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.phoneNumber"
              class="text-danger"
            >
              {{ validation.phoneNumber }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Discount -->
        <validation-provider
          #default="validationContext"
          name="Скидка"
          rules="required"
        >
          <b-form-group
            label="Скидка"
            label-for="discount"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="clientData.discountId"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="discountOptions"
              :reduce="val => val.value"
              :clearable="false"
              input-id="discount"
            >
              <template
                slot="option"
                slot-scope="option"
              >
                {{ option.label }} || {{ option.percentage }}
              </template>
              <template
                slot="selected-option"
                slot-scope="option"
              >
                {{ option.label }}
              </template>
            </v-select>
            <p
              v-if="validation.discountId"
              class="text-danger"
            >
              {{ validation.discountId }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import vSelect from 'vue-select'

export default {
  name: 'DiscountAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
    vSelect,
  },
  directives: {
    Ripple,
  },
  props: {
    discountOptions: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankClientData = {
      name: '',
      surname: '',
      phoneNumber: '',
      discountId: null,
    }
    const clientData = ref(JSON.parse(JSON.stringify(blankClientData)))
    const resetOrderData = () => {
      clientData.value = JSON.parse(JSON.stringify(blankClientData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      clientData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    resetClientData() {
      this.clientData.name = ''
      this.clientData.surname = ''
      this.clientData.phoneNumber = ''
      this.clientData.discountId = null
    },
    reset() {
      this.resetClientData()
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('addClient', this.clientData)
        this.$message(`Клиент ${data.surname} ${data.name} успешно добавлен в базу`, ` Клиент ${data.surname} ${data.name} успешно добавлен в базу`, 'UserIcon', 'success')
        this.validation = {}
        this.$emit('addClient', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
