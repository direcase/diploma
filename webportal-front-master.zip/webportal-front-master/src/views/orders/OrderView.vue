<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="order === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного пользователя с этим идентификатором пользователя. Проверить
          <b-link
            class="alert-link"
            :to="'/orders'"
          >
            Список заказов
          </b-link>
          для других Заказов.
        </div>
      </b-alert>

      <template v-if="order">
        <!-- First Row -->
        <b-row>
          <b-col
            cols="12"
            xl="8"
            lg="8"
            md="7"
          >
            <order-info-card
              :order="order"
              :model-options="modelOptions"
              :discount-options="discountOptions"
              :type-options="typeOptions"
              :client-options="clientOptions"
              :documents="documents"
              @addDocument="addDocument"
              @updateMessage="updateMessage"
              @orderDone="orderDone"
              @notify="notify"
              @waitPayment="waitPayment"
              @updateOrder="updateOrder"
              @deleteOrder="deleteOrder"
            />
          </b-col>
          <b-col
            cols="12"
            md="5"
            xl="4"
            lg="4"
          >
            <order-time-line-card :order="order" />
          </b-col>
        </b-row>
        <order-items
          :id="order.id"
          :order="order"
          :order-items="order.items"
          :products="products"
          :services="services"
          :discount-percent="order.discountPercent"
          @addItem="addItem"
          @refresh="refresh"
          @removeItem="removeItem"
        />
        <order-documents
          :order="order"
          :documents="documents"
        />
        <!--      <invoice-list />-->
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BCol, BRow,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import OrderInfoCard from '@/views/orders/components/OrderInfoCard'
import OrderTimeLineCard from '@/views/orders/components/OrderTimeLine.vue'
import OrderItems from '@/views/orders/components/OrderItems.vue'
import Loader from '@/layouts/components/Loader.vue'
import OrderDocuments from '@/views/orders/components/OrderDocuments.vue'

export default {
  components: {
    Loader,
    BAlert,
    BLink,
    BCol,
    BRow,
    OrderInfoCard,
    OrderItems,
    OrderTimeLineCard,
    OrderDocuments,
  },
  data: () => ({
    order: {},
    products: [],
    services: [],
    discountOptions: [],
    typeOptions: [],
    modelOptions: [],
    clientOptions: [],
    documents: [],
    loader: true,
  }),
  computed: {
  },
  async mounted() {
    await this.fetchAllData()
  },
  methods: {
    async fetchAllData() {
      try {
        this.loader = true
        this.order = await this.$store.dispatch('fetchOrderById', this.$route.params.id)
        this.products = await this.$store.dispatch('fetchAllProducts')
        this.services = await this.$store.dispatch('fetchAllServices')
        this.discountOptions = await this.$store.dispatch('fetchAllDiscounts')
        this.typeOptions = await this.$store.dispatch('fetchAllTypes')
        this.modelOptions = await this.$store.dispatch('fetchAllModels')
        this.clientOptions = await this.$store.dispatch('fetchAllClients')
        this.documents = await this.$store.dispatch('fetchOrderDocuments', this.$route.params.id)
        console.log('documents', this.documents)
        this.loader = false
      } catch (e) {
        if (e.response.data.code === 'order/not-found') {
          this.order = undefined
          this.loader = false
        }
      }
    },
    async refresh() {
      console.log(this.$route.params.id)
      this.loader = true
      this.order = await this.$store.dispatch('fetchOrderById', this.$route.params.id)
      this.loader = false
    },
    addItem(data) {
      this.order.items.push(data)
      if (data.product) {
        this.decrementProductStorage(data.product.id, data.quantity)
      }
    },
    addDocument(data) {
      this.documents.push(data)
    },
    async orderDone() {
      try {
        const data = await this.$store.dispatch('orderDone', this.order.id)
        this.order = data
        this.$message('Статус заказа изменена', 'Сделано', 'CheckSquareIcon', 'success')
        // eslint-disable-next-line no-empty
      } catch (e) {}
    },
    async updateMessage(messageData) {
      try {
        // eslint-disable-next-line no-param-reassign
        messageData.orderId = this.order.id
        await this.$store.dispatch('addMessage', messageData)
        this.$message('Комментарии успешно обновлена', messageData.message, 'MessageSquareIcon', 'success')
        this.order.comment = messageData.message
        // eslint-disable-next-line no-empty
      } catch (e) {}
    },
    updateOrder(orderData) {
      this.order = orderData
    },
    async deleteOrder() {
      try {
        await this.$store.dispatch('deleteOrder', this.order.id)
        this.$swal({
          icon: 'success',
          title: 'Удалено!',
          text: 'Заказ удален.',
          customClass: {
            confirmButton: 'btn btn-success',
          },
        })
        this.$router.push('/orders')
        // eslint-disable-next-line no-empty
      } catch (e) {}
    },
    async notify() {
      try {
        // eslint-disable-next-line no-unused-vars
        const data = await this.$store.dispatch('notify', this.order.id)
        this.$message('Клиент успешно уведомлен', '', 'MailIcon', 'success')
        this.order.notified = true
        // eslint-disable-next-line no-empty
      } catch (e) {}
    },
    async waitPayment() {
      try {
        const data = await this.$store.dispatch('waitPayment', this.order.id)
        this.$message('Статус заказа изменена', 'Ожидается платеж', 'DollarSignIcon', 'success')
        this.order = data
        // eslint-disable-next-line no-empty
      } catch (e) {}
    },
    async removeItem(itemId) {
      try {
        const data = {}
        data.itemId = itemId
        data.orderId = this.order.id
        await this.$store.dispatch('removeOrderItem', data)
        // eslint-disable-next-line no-plusplus
        for (let i = 0; i < this.order.items.length; i++) {
          // eslint-disable-next-line eqeqeq
          if (this.order.items[i].id == itemId) {
            if (this.order.items[i].product) {
              this.incrementProductStorage(this.order.items[i].product.id, this.order.items[i].quantity)
            }
            this.order.items.splice(i, 1)
          }
        }
        this.$message('Успешно удалено из заказа', `Услуга или Товар под номером ${itemId} успешно удален`, 'BoxIcon', 'success')
        // eslint-disable-next-line no-empty
      } catch (e) {}
    },
    incrementProductStorage(id, quantity) {
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < this.products.length; i++) {
        // eslint-disable-next-line eqeqeq
        if (this.products[i].value == id) {
          // eslint-disable-next-line operator-assignment
          this.products[i].storage = this.products[i].storage + quantity
        }
      }
    },
    decrementProductStorage(id, quantity) {
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < this.products.length; i++) {
        // eslint-disable-next-line eqeqeq
        if (this.products[i].value == id) {
          // eslint-disable-next-line operator-assignment
          this.products[i].storage = this.products[i].storage - quantity
        }
      }
    },
  },
}
</script>

<style>

</style>
