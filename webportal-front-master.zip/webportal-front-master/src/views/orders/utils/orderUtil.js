// eslint-disable-next-line no-unused-vars
function getName(order) {
  if (order.client) {
    return `${order.client.surname} ${order.client.name}`
  }
  return order.clientName
}

// eslint-disable-next-line no-unused-vars
function getDateByFormat(date, format) {
  const options = {}
  if (format.includes('date')) {
    options.day = '2-digit'
    options.month = '2-digit'
    options.year = 'numeric'
  }
  if (format.includes('time')) {
    options.hour = '2-digit'
    options.minute = '2-digit'
    options.second = '2-digit'
  }
  const locale = 'ru-RU'
  return new Intl.DateTimeFormat(locale, options).format(new Date(date))
}
// eslint-disable-next-line no-unused-vars
function getType(order) {
  return `${order.type.name} ${order.model.name} ${order.modelCompany}`
}

// eslint-disable-next-line no-unused-vars
function getNumber(order) {
  if (order.client) {
    return `${order.client.phoneNumber}`
  }
  return order.phoneNumber
}

module.exports = {
  getName,
  getNumber,
  getDateByFormat,
  getType,
}
