<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isAddNewMessageSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="resetForm"
    @change="(val) => $emit('update:is-add-new-message-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
        <h5 class="mb-0">
          Добавить / Изменить Комментарии
        </h5>

        <feather-icon
          class="ml-1 cursor-pointer"
          icon="XIcon"
          size="16"
          @click="hide"
        />

      </div>

      <!-- BODY -->
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandler"
          @reset.prevent="resetForm"
        >
          <!-- ModelType -->
          <validation-provider
            #default="validationContext"
            name="Комментарии"
          >
            <b-form-group
              label="Комментарии"
              label-for="message"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="MonitorIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="message"
                  v-model="message"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>

              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!-- ModelType -->
          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Добавить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>

        </b-form>
      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'OrderMessage',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  model: {
    prop: 'isAddNewMessageSidebarActive',
    event: 'update:is-add-new-message-sidebar-active',
  },
  props: {
    isAddNewMessageSidebarActive: {
      type: Boolean,
      required: true,
    },
    // eslint-disable-next-line vue/require-default-prop
    message: {
      type: String,
    },
    id: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
    }
  },
  computed: {
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankMessageData = {
      message: '',
    }

    const messageData = ref(JSON.parse(JSON.stringify(blankMessageData)))
    const resetMessageData = () => {
      messageData.value = JSON.parse(JSON.stringify(blankMessageData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetMessageData)

    return {
      messageData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    submitHandler() {
      try {
        this.messageData.message = this.message
        this.$emit('updateMessage', this.messageData)
        // eslint-disable-next-line no-empty
      } catch (e) {
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
