<template>
  <b-card title="Даты">
    <app-timeline>
      <!-- 12 INVOICES HAVE BEEN PAID -->
      <app-timeline-item variant="warning">
        <div class="d-flex flex-sm-row flex-column flex-wrap justify-content-between mb-1 mb-sm-0">
          <h6>Принято</h6>
          <small class="text-muted">{{ getRelativeTime(order.acceptedDate) }}</small>
        </div>
        <p>{{ getDateByFormat(order.acceptedDate, 'datetime') }}</p>
        <p class="mb-0">
          <span class="align-bottom">
            <b-link
              v-if="user.roles.includes('ADMIN')"
              :to="'/users/'+order.acceptedUser.id"
            >
              {{ accepted() }}
            </b-link>
            <template v-else>
              {{ accepted() }}
            </template>
          </span>
        </p>
      </app-timeline-item>
      <app-timeline-item
        v-if="order.doneDate"
        variant="primary"
      >
        <div class="d-flex flex-sm-row flex-column flex-wrap justify-content-between mb-1 mb-sm-0">
          <h6>Сделано</h6>
          <small class="text-muted">{{ getRelativeTime(order.doneDate) }}</small>
        </div>
        <p>{{ getDateByFormat(order.doneDate, 'datetime') }}</p>
        <p class="mb-0">
          <span class="align-bottom">
            <b-link
              v-if="user.roles.includes('ADMIN')"
              :to="'/users/'+order.doneUser.id"
            >
              {{ done() }}
            </b-link>
            <template v-else>
              {{ done() }}
            </template>
          </span>
        </p>
      </app-timeline-item>
      <app-timeline-item
        v-if="order.gaveDate"
        variant="success"
      >
        <div class="d-flex flex-sm-row flex-column flex-wrap justify-content-between mb-1 mb-sm-0">
          <h6>Выдано</h6>
          <small class="text-muted">{{ getRelativeTime(order.gaveDate) }}</small>
        </div>
        <p>{{ getDateByFormat(order.gaveDate, 'datetime') }}</p>
        <p class="mb-0">
          <span class="align-bottom">
            <b-link
              v-if="user.roles.includes('ADMIN')"
              :to="'/users/'+order.giveUser.id"
            >
              {{ give() }}
            </b-link>
            <template v-else>
              {{ give() }}
            </template>
          </span>
        </p>
      </app-timeline-item>
    </app-timeline></b-card>
</template>

<script>
import {
  BCard, BLink,
} from 'bootstrap-vue'
import AppTimeline from '@core/components/app-timeline/AppTimeline.vue'
import AppTimelineItem from '@core/components/app-timeline/AppTimelineItem.vue'
import moment from 'moment'

export default {
  components: {
    BCard,
    BLink,
    AppTimeline,
    AppTimelineItem,
  },
  props: {
    order: {
      type: Object,
      required: true,
    },
  },
  computed: {
    user() {
      return this.$store.getters.user
    },
  },
  methods: {
    getRelativeTime(date) {
      const d = new Date(date)
      moment.locale('ru-RU')
      return moment(d).fromNow()
    },
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = 'long'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
    accepted() {
      return `${this.order.acceptedUser.surname} ${this.order.acceptedUser.name}`
    },
    done() {
      return `${this.order.doneUser.surname} ${this.order.doneUser.name}`
    },
    give() {
      return `${this.order.giveUser.surname} ${this.order.giveUser.name}`
    },
  },
}
</script>

<style>

</style>
