<template>
  <b-modal
    id="modal-tall"
    ref="modal"
    centered
    title="Добавить товары и услуги 📦👨‍🔧"
    :hide-footer="true"
    cancel-title="Отменить"
    ok-title="Добавить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form Product -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandlerService"
        @reset.prevent="resetForm"
      >
        <div class="d-flex justify-content-center align-items-center">
          <h5 class="mb-0">
            Добавить услугу 👨‍🔧
          </h5>
        </div>
        <hr>
        <!-- Full Name -->
        <!-- Discount -->
        <validation-provider
          #default="validationContext"
          name="Услуга"
          rules="required"
        >
          <b-form-group
            label="Услуга"
            label-for="service"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="itemData.serviceId"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="services"
              :reduce="val => val.value"
              :clearable="false"
              input-id="service"
            >
              <template
                slot="option"
                slot-scope="option"
              >
                {{ option.label }}
              </template>
              <template
                slot="selected-option"
                slot-scope="option"
              >
                {{ option.label }}
              </template>
            </v-select>
            <p
              v-if="validation.service_id"
              class="text-danger"
            >
              {{ validation.service_id }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Количество"
          rules="required"
        >
          <b-form-group
            label="Количество"
            label-for="quantity-service"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="SettingsIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="quantity-service"
                v-model.number="itemData.quantity"
                :state="getValidationState(validationContext)"
                trim
              />
            </b-input-group>
            <p
              v-if="validation.quantity"
              class="text-danger"
            >
              {{ validation.quantity }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!-- Form Actions -->
        <div class="d-flex mt-2">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3 mr-2"
            type="submit"
          >
            Добавить
          </b-button>
          <b-button
            v-ripple.400="'rgba(186, 191, 199, 0.15)'"
            type="button"
            variant="outline-secondary"
            @click="hide"
          >
            Отменить
          </b-button>
        </div>

      </b-form>
      <!--        Form Service-->
      <b-form
        class="p-2"
        @submit.prevent="submitHandlerProduct"
        @reset.prevent="reset"
      >
        <div class="d-flex justify-content-center align-items-center">
          <h5 class="mb-0">
            Добавить товар 📦
          </h5>
        </div>
        <hr>
        <!-- Full Name -->
        <!-- Discount -->
        <validation-provider
          #default="validationContext"
          name="Товар"
          rules="required"
        >
          <b-form-group
            label="Товар"
            label-for="product"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="itemData.productId"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="products"
              :reduce="val => val.value"
              :clearable="false"
              input-id="product"
              label="name"
            >
              <template
                slot="option"
                slot-scope="option"
              >
                {{ option.name }} || {{ option.storage }}
              </template>
              <template
                slot="selected-option"
                slot-scope="option"
              >
                {{ option.name }} || {{ option.storage }}
              </template>
            </v-select>
            <p
              v-if="validation.product_id"
              class="text-danger"
            >
              {{ validation.product_id }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Количество"
          rules="required"
        >
          <b-form-group
            label="Количество"
            label-for="quantity"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="BoxIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="quantity"
                v-model.number="itemData.quantity"
                :state="getValidationState(validationContext)"
                trim
              />
            </b-input-group>
            <p
              v-if="validation.quantity"
              class="text-danger"
            >
              {{ validation.quantity }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!-- Form Actions -->
        <div class="d-flex mt-2">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3 mr-2"
            type="submit"
          >
            Добавить
          </b-button>
          <b-button
            v-ripple.400="'rgba(186, 191, 199, 0.15)'"
            type="button"
            variant="outline-secondary"
            @click="hide"
          >
            Отменить
          </b-button>
        </div>

      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BButton, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import vSelect from 'vue-select'

export default {
  name: 'DiscountAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
    vSelect,
  },
  directives: {
    Ripple,
  },
  props: {
    products: {
      type: Array,
      required: true,
    },
    services: {
      type: Array,
      required: true,
    },
    id: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankItemData = {
      productId: 0,
      serviceId: 0,
      quantity: 0,
    }

    const itemData = ref(JSON.parse(JSON.stringify(blankItemData)))
    const resetItemData = () => {
      itemData.value = JSON.parse(JSON.stringify(blankItemData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetItemData)

    return {
      itemData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    hide() {
      this.$refs.modal.hide()
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    resetItemData() {
      this.itemData.productId = 0
      this.itemData.serviceId = 0
      this.itemData.quantity = 0
    },
    reset() {
      this.resetItemData()
      this.validation = {}
    },
    async submitHandlerProduct() {
      try {
        const formData = this.itemData
        // eslint-disable-next-line array-callback-return
        this.products.filter(async c => {
          // eslint-disable-next-line eqeqeq
          if (formData.productId == c.value) {
            if (c.storage < formData.quantity) {
              this.validation.quantity = `Недостаточно в количестве ${formData.quantity - c.storage}`
              this.$message('Недостаточно товара на складе', `Недостаточно в количестве ${formData.quantity - c.storage}`, 'BoxIcon', 'warning')
            } else {
              formData.id = this.id
              const data = await this.$store.dispatch('addOrderItemProduct', formData)
              this.$message('Товар успешно добавлен в заказ', `${data.product.name} успешно добавлен`, 'BoxIcon', 'success')
              this.itemData.productId = 0
              this.itemData.quantity = 0
              this.validation = {}
              this.$emit('addItem', data)
            }
          }
        })
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
    async submitHandlerService() {
      try {
        const formData = this.itemData
        formData.id = this.id
        const data = await this.$store.dispatch('addOrderItemService', formData)
        this.$message('Услуга успешно добавлен в заказ', `${data.service.name} успешно добавлен`, 'BoxIcon', 'success')
        this.itemData.serviceId = 0
        this.itemData.quantity = 0
        this.validation = {}
        this.$emit('addItem', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
