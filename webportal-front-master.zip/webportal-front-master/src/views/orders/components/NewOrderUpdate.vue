<template>
  <b-modal
    id="modal-tall"
    ref="modal"
    centered
    title="Изменить заказ"
    cancel-title="Отменить"
    ok-title="Изменить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >
    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >

        <!-- Full Name -->
        <validation-provider
          #default="validationContext"
          name="ФИО"
          rules="required"
        >
          <b-form-group
            label="ФИО клиента *"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="UserIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="orderData.clientId"
                autofocus
                :state="getValidationState(validationContext)"
                trim
                list="my-list-id"
                placeholder="ФИО"
                @change="changeClient"
              />
            </b-input-group>
            <datalist id="my-list-id">
              <option
                v-for="client in clientOptions"
                :key="client.id"
                :value="client.value"
              >
                {{ client.label }}
              </option>
            </datalist>
            <p
              v-if="validation.clientId"
              class="text-danger"
            >
              {{ validation.clientId }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Тел номер"
          rules="required"
        >
          <b-form-group
            label="Телефон Номер *"
            label-for="phoneNumber"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PhoneIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="phoneNumber"
                v-model="orderData.client_number"
                :state="getValidationState(validationContext)"
                trim
              />
            </b-input-group>
            <p
              v-if="validation.client_number"
              class="text-danger"
            >
              {{ validation.client_number }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Discount -->
        <validation-provider
          #default="validationContext"
          name="Скидка"
          rules="required"
        >
          <b-form-group
            label="Скидка *"
            label-for="discount"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="orderData.discount_id"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="discountOptions"
              :reduce="val => val.value"
              :clearable="false"
              input-id="discount"
            >
              <template
                slot="option"
                slot-scope="option"
              >
                {{ option.label }} || {{ option.percentage }}
              </template>
              <template
                slot="selected-option"
                slot-scope="option"
              >
                {{ option.label }}
              </template>
            </v-select>
            <p
              v-if="validation.discountId"
              class="text-danger"
            >
              {{ validation.discount_id }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--Тип устройства-->
        <validation-provider
          #default="validationContext"
          name="Тип устройства"
          rules="required"
        >
          <b-form-group
            label="Тип устройства *"
            label-for="type"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="orderData.type_id"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="typeOptions"
              :reduce="val => val.value"
              :clearable="false"
              input-id="type"
            />
            <p
              v-if="validation.type_id"
              class="text-danger"
            >
              {{ validation.type_id }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--Firm Created-->
        <validation-provider
          #default="validationContext"
          name="Фирма производителя"
          rules="required"
        >
          <b-form-group
            label="Фирма производителя *"
            label-for="model"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="orderData.model_id"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="modelOptions"
              :reduce="val => val.value"
              :clearable="false"
              input-id="model"
            />
            <p
              v-if="validation.model_id"
              class="text-danger"
            >
              {{ validation.model_id }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- ModelType -->
        <validation-provider
          #default="validationContext"
          name="Модель Устройства"
        >
          <b-form-group
            label="Модель Устройства *"
            label-for="modelType"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="MonitorIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="modelType"
                v-model="orderData.modelType"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.modelType"
              class="text-danger"
            >
              {{ validation.modelType }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <validation-provider
          #default="validationContext"
          name="Серийный номер"
        >
          <b-form-group
            label="Сер.№(IMEI)"
            label-for="serialNumber"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="AlignJustifyIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="serialNumber"
                v-model="orderData.serialNumber"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.serialNumber"
              class="text-danger"
            >
              {{ validation.serialNumber }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!-- ModelType -->
        <validation-provider
          #default="validationContext"
          name="Проблема"
        >
          <b-form-group
            label="Проблема *"
            label-for="problem"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="AlertCircleIcon" />
              </b-input-group-prepend>
              <b-form-textarea
                id="problem"
                v-model="orderData.problem"
                placeholder="Textarea"
                rows="3"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.problem"
              class="text-danger"
            >
              {{ validation.problem }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormTextarea, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import vSelect from 'vue-select'

export default {
  name: 'UpdateOrderModal',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormTextarea,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
    vSelect,
  },
  directives: {
    Ripple,
  },
  props: {
    order: {
      type: Object,
      required: true,
    },
    modelOptions: {
      type: Array,
      required: true,
    },
    typeOptions: {
      type: Array,
      required: true,
    },
    clientOptions: {
      type: Array,
      required: true,
    },
    discountOptions: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.order) {
      this.setData(this.order)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankOrderData = {
      id: null,
      clientId: '',
      client_number: '',
      discount_id: null,
      model_id: null,
      type_id: null,
      problem: '',
      modelType: '',
      serialNumber: '',
    }

    const orderData = ref(JSON.parse(JSON.stringify(blankOrderData)))
    const resetOrderData = () => {
      orderData.value = JSON.parse(JSON.stringify(blankOrderData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      orderData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    setData(data) {
      this.orderData.id = data.id
      if (data.client) {
        this.orderData.clientId = data.client.id
      } else {
        this.orderData.clientId = data.clientName
      }
      if (data.client) {
        this.orderData.client_number = data.client.phoneNumber
      } else {
        this.orderData.client_number = data.phoneNumber
      }
      if (data.client) {
        this.orderData.discount_id = data.client.discount.id
      } else {
        this.orderData.discount_id = data.discount.id
      }
      this.orderData.model_id = data.model.id
      this.orderData.type_id = data.type.id
      this.orderData.problem = data.problem
      this.orderData.modelType = data.modelCompany
      this.orderData.serialNumber = data.serialNumber
      console.log(this.orderData)
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    reset() {
      this.setData(this.order)
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateOrder', this.orderData)
        this.reset()
        this.$message('Заказ успешно обновлен', `Заказ № ${data.id} успешно обновлен`, 'CheckSquareIcon', 'success')
        this.$emit('updateOrder', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
    // eslint-disable-next-line no-unused-vars
    changeClient(data) {
      // eslint-disable-next-line array-callback-return
      this.clientOptions.filter(c => {
        // eslint-disable-next-line eqeqeq
        if (data == c.value) {
          this.orderData.discount_id = c.discount_id
          this.orderData.client_number = c.number
        }
      })
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
