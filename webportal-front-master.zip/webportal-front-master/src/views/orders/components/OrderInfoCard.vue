<template>
  <b-card>

    <b-row>
      <new-order-update
        ref="updateModal"
        :order="order"
        :model-options="modelOptions"
        :discount-options="discountOptions"
        :type-options="typeOptions"
        :client-options="clientOptions"
        @updateOrder="updateOrder"
      />
      <!-- User Info: Left col -->
      <b-col
        cols="21"
        xl="6"
        class="d-flex justify-content-between flex-column"
      >
        <!-- User Avatar & Action Buttons -->
        <div class="d-flex justify-content-start">
          <b-avatar
            :text="'ES'"
            :variant="'light-success'"
            size="104px"
            rounded
          />
          <div class="d-flex flex-column ml-1">
            <div class="mb-1">
              <b-link
                v-if="user.roles.includes('MODERATOR')&&order.client"
                :to="'/clients/'+order.client.id"
              >
                <h4 class="mb-0">
                  {{ getName() }}
                </h4>
              </b-link>
              <h4
                v-else
                class="mb-0"
              >
                {{ getName() }}
              </h4>
              <span class="card-text">{{ getNumber() }}</span>
            </div>
            <div class="d-flex flex-wrap">
              <b-button
                variant="gradient-primary"
                class="btn-icon mr-1"
                @click="showUpdateModal"
              >
                <feather-icon icon="EditIcon" />
              </b-button>
              <b-button
                variant="gradient-danger"
                class="btn-icon mr-1"
                size="md"
                @click="deleteOrder"
              >
                <feather-icon icon="Trash2Icon" />
              </b-button>
              <b-button
                variant="gradient-warning"
                class="btn-icon mr-1"
                size="md"
                @click="print"
              >
                <i class="fa fa-qrcode" />
              </b-button>
              <BLink
                v-if="getNumber()"
                :href="'tel:'+getNumber()"
              >
                <b-button
                  variant="gradient-success"
                  class="btn-icon mr-1"
                  size="md"
                >
                  <feather-icon icon="PhoneIcon" />
                </b-button>
              </BLink>
            </div>
          </div>
        </div>
        <!-- Order Buttons -->
        <div class="d-flex align-items-center">
          <OrderButtons
            :order="order"
            :documents="documents"
            @addDocument="addDocument"
            @updateMessage="updateMessage"
            @orderDone="orderDone"
            @notify="notify"
            @waitPayment="waitPayment"
          />
        </div>
      </b-col>

      <!-- Right Col: Table -->
      <b-col
        cols="12"
        xl="6"
      >
        <table class="mt-2 mt-xl-0 w-100">
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="HardDriveIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Тип устройства:</span>
            </th>
            <td class="pb-50">
              {{ getType() }}
            </td>
          </tr>
          <tr v-if="order.serialNumber">
            <th class="pb-50">
              <feather-icon
                icon="AlignJustifyIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Сер.№(IMEI):</span>
            </th>
            <td class="pb-50">
              {{ order.serialNumber }}
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="CheckIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Статус:</span>
            </th>
            <td class="pb-50 text-capitalize">
              <b-badge
                pill
                :variant="getStatusVariant()"
              >
                {{ getStatusText() }}
              </b-badge>
            </td>
          </tr>
          <tr>
            <th>
              <feather-icon
                icon="InfoIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Проблема:</span>
            </th>
            <td>
              {{ order.problem }}
            </td>
          </tr>
          <tr v-if="order.comment">
            <th>
              <feather-icon
                icon="MessageSquareIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Комментарии:</span>
            </th>
            <td>
              {{ order.comment }}
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="MailIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Уведомлено:</span>
            </th>
            <td class="pb-50 text-capitalize">
              <b-badge
                pill
                :variant="getNotifyVariant()"
              >
                {{ getNotifyText() }}
              </b-badge>
            </td>
          </tr>
          <tr v-if="order.typesOfPayments">
            <th class="pb-50">
              <feather-icon
                icon="CalendarIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Способ Оплаты:</span>
            </th>
            <td class="pb-50">
              {{ typesOfPayments() }}
            </td>
          </tr>
        </table>
      </b-col>
    </b-row>
  </b-card>
</template>

<script>
import {
  BCard, BButton, BAvatar, BBadge, BRow, BCol, BLink,
} from 'bootstrap-vue'
import { avatarText } from '@core/utils/filter'
import OrderButtons from '@/views/orders/components/OrderButtons.vue'
import NewOrderUpdate from '@/views/orders/components/NewOrderUpdate.vue'

export default {
  components: {
    BCard, BButton, BRow, BCol, BAvatar, BBadge, BLink, OrderButtons, NewOrderUpdate,
  },
  props: {
    order: {
      type: Object,
      required: true,
    },
    documents: {
      type: Array,
      required: true,
    },
    modelOptions: {
      type: Array,
      required: true,
    },
    typeOptions: {
      type: Array,
      required: true,
    },
    clientOptions: {
      type: Array,
      required: true,
    },
    discountOptions: {
      type: Array,
      required: true,
    },
  },
  setup() {
    return {
      avatarText,
    }
  },
  data: () => ({
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
  },
  methods: {
    addDocument(data) {
      this.$emit('addDocument', data)
    },
    deleteOrder() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(result => {
        if (result.value) {
          /* this.$swal({
            icon: 'success',
            title: 'Deleted!',
            text: 'Your file has been deleted.',
            customClass: {
              confirmButton: 'btn btn-success',
            },
          }) */
          this.$emit('deleteOrder')
        }
      })
    },
    orderDone() {
      this.$emit('orderDone')
    },
    notify() {
      this.$emit('notify')
    },
    waitPayment() {
      this.$emit('waitPayment')
    },
    updateOrder(orderData) {
      this.$emit('updateOrder', orderData)
    },
    getName() {
      if (this.order.client) {
        return `${this.order.client.surname} ${this.order.client.name}`
      }
      return this.order.clientName
    },
    getNumber() {
      if (this.order.client) {
        return `${this.order.client.phoneNumber}`
      }
      return this.order.phoneNumber
    },
    updateMessage(messageData) {
      this.$emit('updateMessage', messageData)
    },
    getType() {
      return `${this.order.type.name} ${this.order.model.name} ${this.order.modelCompany}`
    },
    getNotifyText() {
      if (this.order.notified) {
        return 'Да'
      }
      return 'Нет'
    },
    getNotifyVariant() {
      if (this.order.notified) {
        return 'success'
      }
      return 'danger'
    },
    getStatusVariant() {
      switch (this.order.status.toString()) {
        case 'DONE':
          return 'warning'
        case 'NOTDONE':
          return 'danger'
        case 'WENTCASHIER':
          return 'primary'
        default:
          return 'success'
      }
    },
    accepted() {
      return `${this.order.acceptedUser.surname} ${this.order.acceptedUser.name}`
    },
    getStatusText() {
      switch (this.order.status.toString()) {
        case 'DONE':
          return 'Сделано'
        case 'NOTDONE':
          return 'Не сделано'
        case 'WENTCASHIER':
          return 'Ожидается платеж'
        default:
          return 'Выдано'
      }
    },
    typesOfPayments() {
      switch (this.order.status.toString()) {
        case 'cash':
          return 'Наличными'
        case 'contract':
          return 'По договору'
        case 'online':
          return 'Перевод'
        default:
          return 'Долг'
      }
    },
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = 'long'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
    print() {
      const WinPrint = window.open()
      WinPrint.document.write(`
<!DOCTYPE HTML>
<html>
<head>
    <title>QR code Заказа</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

<main role="main" class="row" style="border-bottom: 1px solid black; padding-bottom: 10px">
    <div class="col-4" style="text-align: center">
    <h1 style="font-size: small">QRCode заказа №${this.order.id}</h1>
    <h1 style="font-size: small">Тел. Номер Клиента: ${this.getNumber()}</h1>
    <img src='https://api.qrserver.com/v1/create-qr-code/?data=http://nanoservice.kz/orders/${this.order.id}&size=100x100'>
    </div>
    <div class="col-8 row" style="border-left: 1px solid black;">
        <div class="w-100" style="text-align: center">
        <h1 style="font-size: small">QRCode заказа № ${this.order.id} <h1/>
        </div>
        <div class="col-8">
            <h1 style="font-size: small">Дата приема: ${this.getDateByFormat(this.order.acceptedDate, 'datetime')} <h1/>
            <h1 style="font-size: small">Тип устройства: ${this.getType()} <h1/>
            <h1 style="font-size: small">Принял: ${this.accepted()} <h1/>
            <h1 style="font-size: small">Тел. Номер мастера: ${this.order.acceptedUser.phoneNumber} <h1/>
        </div>
            <div class="col-4">
                <img src='https://api.qrserver.com/v1/create-qr-code/?data=http://nanoservice.kz/client/order/${this.order.id}/${this.order.token}&size=100x100'>
            </div>

    </div>
</main>
</body>
</html>`)
      setTimeout(() => {
        WinPrint.print()
        WinPrint.close()
      }, 3000)
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
