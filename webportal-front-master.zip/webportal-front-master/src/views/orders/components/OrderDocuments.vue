<template>
  <div>
    <b-card-actions
      ref="cardAction"
      title="Документы 📄"
      action-refresh
      @refresh="refreshStop('cardAction')"
    >
      <b-row>
        <b-col
          md="2"
          sm="4"
          class="my-1"
        >
          <b-form-group
            class="mb-0"
          >
            <label class="d-inline-block text-sm-left mr-50">На страницу</label>
            <b-form-select
              id="perPageSelect"
              v-model="perPage"
              size="sm"
              :options="pageOptions"
              class="w-50"
            />
          </b-form-group>
        </b-col>
        <b-col
          md="4"
          sm="8"
          class="my-1"
        >
          <b-form-group
            label="Сортировать"
            label-cols-sm="3"
            label-align-sm="right"
            label-size="sm"
            label-for="sortBySelect"
            class="mb-0"
          >
            <b-input-group size="sm">
              <b-form-select
                id="sortBySelect"
                v-model="sortBy"
                :options="sortOptions"
                class="w-75"
              >
                <template v-slot:first>
                  <option value="">
                    -- ничто --
                  </option>
                </template>
              </b-form-select>
              <b-form-select
                v-model="sortDesc"
                size="sm"
                :disabled="!sortBy"
                class="w-25"
              >
                <option :value="false">
                  По возрастанию
                </option>
                <option :value="true">
                  По убыванию
                </option>
              </b-form-select>
            </b-input-group>
          </b-form-group>
        </b-col>
        <b-col
          md="6"
          class="my-1"
        >
          <b-form-group
            label="Фильтр"
            label-cols-sm="3"
            label-align-sm="right"
            label-size="sm"
            label-for="filterInput"
            class="mb-0"
          >
            <b-input-group size="sm">
              <b-form-input
                id="filterInput"
                v-model="filter"
                type="search"
                placeholder="Введите для поиска"
              />
            </b-input-group>
          </b-form-group>
        </b-col>

        <b-col cols="12">
          <b-table
            class="position-relative"
            striped
            hover
            responsive
            :per-page="perPage"
            :current-page="currentPage"
            :items="documents"
            :fields="fields"
            :sort-by.sync="sortBy"
            :sort-desc.sync="sortDesc"
            :sort-direction="sortDirection"
            :filter="filter"
            :filter-included-fields="filterOn"
            foot-clone
            no-footer-sorting
            @filtered="onFiltered"
            @row-clicked="rowClick"
          >
            <template #cell(id)="data">
              <b-link
                active
                :to="'/documents/'+data.item.id"
              >
                {{ data.item.id }}
              </b-link>
            </template>
            <template #cell(documentType)="data">
              <h6>{{ getDocumentType(data.item.documentType) }}</h6>
            </template>
            <template #cell(documentStatus)="data">
              <b-badge
                pill
                :variant="getDocumentStatusVariant(data.item.documentStatus)"
              >
                {{ getDocumentStatus(data.item.documentStatus) }}
              </b-badge>
            </template>
            <template #cell(open)="data">
              <b-button
                :key="data.item.id"
                variant="primary"
                class="btn-icon"
                @click="certificateGenerator(data.item.documentType, 'open')"
              >
                <feather-icon
                  icon="ExternalLinkIcon"
                  class="mr-15"
                />
              </b-button>
            </template>
            <template #cell(download)="data">
              <b-button
                :key="data.item.id"
                variant="success"
                class="btn-icon"
                @click="certificateGenerator(data.item.documentType, 'download')"
              >
                <feather-icon
                  icon="DownloadIcon"
                  class="mr-15"
                />
              </b-button>
            </template>
            <template #foot()="">
              <span>{{ }}</span>
            </template>
          </b-table>

        </b-col>

        <b-col
          cols="12"
        >
          <h5>Всего: <b>{{ lengthComputed }}</b></h5>
          <b-pagination
            v-model="currentPage"
            :total-rows="documents.length"
            :per-page="perPage"
            align="center"
            size="sm"
            class="my-0"
          />
        </b-col>
      </b-row>
    </b-card-actions>
  </div>
</template>

<script>
import {
  BTable, BButton, BBadge, BRow, BCol, BFormGroup, BFormSelect, BPagination, BInputGroup, BFormInput, BLink,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
// eslint-disable-next-line import/extensions
import BCardActions from '@core/components/b-card-actions/BCardActions'
import OrderAddItem from '@/views/orders/components/OrderAddItem.vue'
import fonts from '@/utils/fonts'
import jsPDF from 'jspdf'
import 'jspdf-autotable'

export default {
  components: {
    BLink,
    BButton,
    BBadge,
    BCardActions,
    BTable,
    BRow,
    BCol,
    BFormGroup,
    BFormSelect,
    BPagination,
    BInputGroup,
    BFormInput,
    // eslint-disable-next-line vue/no-unused-components
    OrderAddItem,
  },
  props: {
    // eslint-disable-next-line vue/require-default-prop
    documents: {
      type: Array,
      required: true,
    },
    order: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      perPage: 10,
      pageOptions: [1, 10, 20, 50],
      totalRows: 1,
      currentPage: 1,
      sortBy: 'id',
      sortDesc: true,
      sortDirection: 'asc',
      filter: null,
      length: 0,
      filterOn: ['id', 'documentType', 'documentStatus'],
      infoModal: {
        id: 'info-modal',
        title: '',
        content: '',
      },
      fields: [
        {
          key: 'id', label: 'Id', sortable: true,
        },
        {
          key: 'documentType', label: 'Тип Документа', sortable: true,
        },
        {
          key: 'documentStatus', label: 'Статус', sortable: true,
        },
        { key: 'open', label: 'Открыть' },
        {
          key: 'download', label: 'Скачать',
        },
      ],
    }
  },
  computed: {
    sortOptions() {
      // Create an options list from our fields
      return this.fields
        .filter(f => f.sortable)
        .map(f => ({ text: f.label, value: f.key }))
    },
    user() {
      return this.$store.getters.user
    },
    lengthComputed() {
      return this.documents.length
    },
  },
  // eslint-disable-next-line no-empty-function
  async mounted() {
  },
  methods: {
    certificateGenerator(documentType, type) {
      if (documentType === 'ACCEPTANCE_CERTIFICATE') {
        this.acceptanceCertificateGenerator(type)
      }
      if (documentType === 'CERTIFICATE_OF_COMPLETION') {
        this.certificateOfCompletionGenerator(type)
      }
    },
    info(item, index, button) {
      this.infoModal.title = `Row index: ${index}`
      this.infoModal.content = JSON.stringify(item, null, 2)
      this.$root.$emit('bv::show::modal', this.infoModal.id, button)
    },
    // eslint-disable-next-line consistent-return
    getDocumentType(data) {
      if (data === 'ACCEPTANCE_CERTIFICATE') return 'Акт приемки передачи'
      if (data === 'CERTIFICATE_OF_COMPLETION') return 'Акт выполненных работ'
    },
    // eslint-disable-next-line consistent-return
    getDocumentStatus(data) {
      if (data === 'CREATED') return 'Создан'
      if (data === 'PRINTED') return 'Распечатан'
      if (data === 'SIGNED') return 'Подписан'
    },
    // eslint-disable-next-line consistent-return
    getDocumentStatusVariant(data) {
      if (data === 'CREATED') return 'danger'
      if (data === 'PRINTED') return 'warning'
      if (data === 'SIGNED') return 'success'
    },
    resetInfoModal() {
      this.infoModal.title = ''
      this.infoModal.content = ''
    },
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length
      this.length = filteredItems.length
      this.currentPage = 1
    },
    rowClick(record) {
      this.$router.push(`/documents/${record.id}`)
    },
    refreshStop(cardName) {
      setTimeout(() => {
        this.$emit('refresh')
        this.$refs[cardName].showLoading = false
      }, 1000)
    },
    setFontToJsPdf(doc) {
      doc.addFileToVFS('Roboto-Black.ttf', fonts['Roboto-Black'])
      doc.addFont('Roboto-Black.ttf', 'roboto-black', 'normal')
      doc.addFileToVFS('Roboto-Italic.ttf', fonts['Roboto-Italic'])
      doc.addFont('Roboto-Italic.ttf', 'roboto-italic', 'normal')
      doc.addFileToVFS('Roboto-Light.ttf', fonts['Roboto-Light'])
      doc.addFont('Roboto-Light.ttf', 'roboto-light', 'normal')
      doc.addFileToVFS('Roboto-BlackItalic.ttf', fonts['Roboto-BlackItalic'])
      doc.addFont('Roboto-BlackItalic.ttf', 'roboto-black-italic', 'normal')
    },
    setHeaderToJsPdf(doc) {
      // Service Center Name
      doc.setFont('roboto-black')
        .setFontSize(12)
        .text(14, 12, `Сервисный центр "${this.order.serviceCenter.name}"`)

      // Address
      doc.setFont('roboto-light')
        .setFontSize(10)
        .text(14, 18, `Адрес: ${this.order.serviceCenter.address}, тел: ${this.order.serviceCenter.phoneNumber}`)

      // Email
      doc.setFont('roboto-light')
        .setFontSize(10)
        .text(14, 24, `Email: ${this.order.serviceCenter.email}`)

      // Line
      doc.setLineWidth(0.01).line(14, 30, 196, 30)
    },
    acceptanceCertificateGenerator(type) {
      // eslint-disable-next-line new-cap
      // eslint-disable-next-line new-cap
      const doc = new jsPDF()
      // Adding fonts
      this.setFontToJsPdf(doc)
      // set Header
      this.setHeaderToJsPdf(doc)
      // Номер квитанций
      doc.setFont('roboto-black')
        .setFontSize(11)
        .text(14, 36, `Квитанция о приемке № ${this.order.id} от ${this.getDateByFormat(this.order.acceptedDate, 'date')}`)
      // Table
      doc.autoTable({
        startY: 42,
        theme: 'grid',
        // Border color Black
        // bodyStyles: { lineColor: [0, 0, 0] },
        body: [
          ['Клиент: ', this.getName()],
          ['Тел: ', this.getNumber()],
          ['Адрес: ', ''],
          ['Устройство: ', this.getType()],
          ['Сер.№(IMEI): ', this.order.serialNumber || ''],
          ['Комплектность: ', ''],
          ['Дата приемки: ', this.getDateByFormat(this.order.acceptedDate, 'date')],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })

      let lastY = doc.autoTable.previous.finalY + 5

      const width = doc.internal.pageSize.getWidth()

      doc.setFont('roboto-black').setFontSize(11).text('Заявленные неисправности', width / 2, lastY, { align: 'center' })
      lastY += 3
      doc.autoTable({
        startY: lastY,
        theme: 'grid',
        body: [
          [this.order.problem],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      lastY = doc.autoTable.previous.finalY + 5
      doc.setFont('roboto-black').setFontSize(11).text('Примечания', width / 2, lastY, { align: 'center' })
      lastY += 3
      doc.autoTable({
        startY: lastY,
        theme: 'grid',
        body: [
          [''],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      lastY = doc.autoTable.previous.finalY + 5
      doc.setFont('roboto-black').setFontSize(11).text('Условия ремонта', width / 2, lastY, { align: 'center' })
      lastY += 3
      doc.autoTable({
        startY: lastY,
        theme: 'grid',
        body: [
          ['1. Ремонт техники со спедами влаги, коррозии, ударов, падений - выполняется без гарантийных обязательств (БЕЗ ГАРАНТИИ навыполненый ремонт)\n'
          + '2. Ремонт производится только на заявленые неисправности клиентом\n'
          + '3. Исполнитель не несет ответственность за сохранность информации на аппарате и его носителях памяти\n'
          + '4. Аппарат с сотпасия клиента принят без разборки и проверки внутренних повреждений. Клиент понимает, что все неисправности и внутр. повреждения, которые могут быть обнаружены в аппарате при его техническом обслуживании, возникли до приема аппарата в ремонт.\n'
          + '5. Клиент принимает на себя риск возможной полной или частичной утраты работоспособности аппарата в процессе ремонта в случае грубых нарушений пользователем условий эксллуатации,наличия следов коррозии, попадания влаги, либо механических воздействий'],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      doc.setDrawColor('black')

      lastY = doc.autoTable.previous.finalY + 10
      doc.setFont('roboto-black').setFontSize(10.5).text('Подпись клиента', 14, lastY)

      lastY += 3
      doc.setLineWidth(0.01).line(14, lastY, 196, lastY)

      lastY += 7
      doc.setFont('roboto-black').setFontSize(10.5).text('Подпись исполнителя', 14, lastY)

      lastY += 3
      doc.setLineWidth(0.01).line(14, lastY, 196, lastY)
      doc.setProperties({ title: `Акт Приемки Перадачи заказа №${this.order.id}` })
      if (type.includes('open')) { doc.output('dataurlnewwindow') }
      if (type.includes('download')) doc.save(`Акт Приемки Перадачи заказа №${this.order.id}.pdf`)
    },
    certificateOfCompletionGenerator(type) {
      // eslint-disable-next-line new-cap
      // eslint-disable-next-line new-cap
      const doc = new jsPDF()
      // Ширина
      const width = doc.internal.pageSize.getWidth()
      // Adding fonts
      this.setFontToJsPdf(doc)
      // set Header
      this.setHeaderToJsPdf(doc)
      // Акт выполненных работ номер текст
      // Номер квитанций
      doc.setFont('roboto-black')
        .setFontSize(11)
        .text(`Акт выполненных работ № ${this.order.id} от ${this.getDateByFormat(this.order.acceptedDate, 'date')}`, width / 2, 36, { align: 'center' })
      // Table
      // Table
      doc.autoTable({
        startY: 42,
        theme: 'grid',
        // Border color Black
        // bodyStyles: { lineColor: [0, 0, 0] },
        body: [
          ['Клиент: ', this.getName()],
          ['Тел: ', this.getNumber()],
          ['Адрес: ', ''],
          ['Устройство: ', this.getType()],
          ['Сер.№(IMEI): ', this.order.serialNumber || ''],
          ['Комплектность: ', ''],
          ['Дата выдачи: ', this.getDateByFormat(this.order.gaveDate, 'datetime')],
          // ...
        ],
        styles: {
          font: 'roboto-light',
          textColor: 'black',
        },
      })
      let lastY = doc.autoTable.previous.finalY + 5

      doc.setFont('roboto-black').setFontSize(11).text(14, lastY, 'Выполненные работы:')
      // Order Items
      const discount = this.order.discountPercent
      this.order.items.forEach(item => {
        lastY += 5
        if (item.service) {
          if (discount === 0) doc.setFont('roboto-italic').setFontSize(10.5).text(28, lastY, `${item.service.name} - ${Number.parseFloat(item.soldPrice).toFixed(2)} KZT * ${item.quantity} = ${Number.parseFloat(this.getItemTotal(item, discount)).toFixed(2)} KZT`)
          if (discount > 0) doc.setFont('roboto-italic').setFontSize(10.5).text(28, lastY, `${item.service.name} - (${Number.parseFloat(item.soldPrice).toFixed(2)} KZT * ${item.quantity}) - ${discount}% = ${Number.parseFloat(this.getItemTotal(item, discount)).toFixed(2)} KZT`)
        } else {
          doc.setFont('roboto-italic').setFontSize(10.5).text(28, lastY, `${item.product.name} - ${Number.parseFloat(item.soldPrice).toFixed(2)} KZT * ${item.quantity} = ${Number.parseFloat(this.getItemTotal(item, discount)).toFixed(2)} KZT`)
        }
      })
      // Total Amount
      lastY += 10
      doc.setFont('roboto-black-italic').setFontSize(11).text(14, lastY, `Итоговая стоимость ремонта: ${this.getTotalAmount(this.order.items, discount)} KZT`)
      // Текст не имею притензий
      lastY += 5
      doc.setFont('roboto-italic').setFontSize(10).text(14, lastY, 'Работа выполнена полностью и в срок, к качеству претензий не имею')
      // Линия подпися клиента
      doc.setDrawColor('black')
      doc.setLineWidth(0.02).line(150, lastY, 196, lastY)
      // Текст под линие подпися
      lastY += 4
      doc.setFont('roboto-italic').setFontSize(9).text('подпись клиента', 173, lastY, { align: 'center' })
      lastY += 7
      doc.setFont('roboto-black').setFontSize(11).text(14, lastY, 'Подпись исполнителя')
      doc.setProperties({ title: `Акт Выполненных Работ заказа №${this.order.id}.pdf` })
      if (type.includes('open')) { doc.output('dataurlnewwindow') }
      if (type.includes('download')) doc.save(`Акт Выполненных Работ заказа №${this.order.id}.pdf`)
    },
    getName() {
      if (this.order.client) {
        return `${this.order.client.surname} ${this.order.client.name}`
      }
      return this.order.clientName
    },
    getItemTotal(item, discountPercent) {
      let sum = 0
      if (item.service) {
        sum = item.soldPrice * item.quantity * ((100 - discountPercent) / 100)
      } else {
        sum = item.soldPrice * item.quantity
      }
      return sum
    },
    getTotalAmount(items, discountPercent) {
      let sum = 0
      items.forEach(item => {
        sum += this.getItemTotal(item, discountPercent)
      })
      return Number.parseFloat(sum).toFixed(2)
    },
    getNumber() {
      if (this.order.client) {
        return `${this.order.client.phoneNumber}`
      }
      return this.order.phoneNumber
    },
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = '2-digit'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
    getType() {
      return `${this.order.type.name} ${this.order.model.name} ${this.order.modelCompany}`
    },
  },
}
</script>

<style scoped>

</style>
