<template>
  <div>
    <b-card-actions
      ref="cardAction"
      title="Услуги и Товары 📦🔧"
      action-refresh
      @refresh="refreshStop('cardAction')"
    >
      <b-row>
        <new-order-add-item
          :id="id"
          ref="addItemModal"
          :products="products"
          :services="services"
          @addItem="addItem"
        />
        <b-col
          md="1"
          sm="2"
          class="my-1"
        >
          <b-form-group
            class="mb-0"
          >
            <b-input-group-append>
              <b-button
                v-if="isStatusNonGiven()"
                class="border-primary border-darken-3 bg-primary bg-darken-3"
                @click="showAddItemModal"
              >
                <span class="text-nowrap">Добавить</span>
              </b-button>
            </b-input-group-append>
          </b-form-group>
        </b-col>
        <b-col
          md="3"
          sm="6"
          class="my-1"
        >
          <b-form-group
            label="На страницу"
            label-cols-sm="6"
            label-align-sm="right"
            label-size="sm"
            label-for="sortBySelect"
            class="mb-0"
          >
            <b-form-select
              id="perPageSelect"
              v-model="perPage"
              size="sm"
              :options="pageOptions"
              class="w-50"
            />
          </b-form-group>
        </b-col>
        <b-col
          md="4"
          sm="8"
          class="my-1"
        >
          <b-form-group
            label="Сортировать"
            label-cols-sm="3"
            label-align-sm="right"
            label-size="sm"
            label-for="sortBySelect"
            class="mb-0"
          >
            <b-input-group size="sm">
              <b-form-select
                id="sortBySelect"
                v-model="sortBy"
                :options="sortOptions"
                class="w-75"
              >
                <template v-slot:first>
                  <option value="">
                    -- ничто --
                  </option>
                </template>
              </b-form-select>
              <b-form-select
                v-model="sortDesc"
                size="sm"
                :disabled="!sortBy"
                class="w-25"
              >
                <option :value="false">
                  По возрастанию
                </option>
                <option :value="true">
                  По убыванию
                </option>
              </b-form-select>
            </b-input-group>
          </b-form-group>
        </b-col>
        <b-col
          md="4"
          sm="8"
          class="my-1"
        >
          <b-form-group
            class="mb-0"
          >
            <b-input-group size="sm">
              <b-input-group-prepend is-text>
                <feather-icon icon="SearchIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="filterInput"
                v-model="filter"
                type="search"
                placeholder="Введите для поиска"
              />
            </b-input-group>
          </b-form-group>
        </b-col>

        <b-col cols="12">
          <b-table
            class="position-relative"
            striped
            hover
            responsive
            :per-page="perPage"
            :current-page="currentPage"
            :items="orderItems"
            :fields="computedFields"
            :sort-by.sync="sortBy"
            :sort-desc.sync="sortDesc"
            :sort-direction="sortDirection"
            :filter="filter"
            :filter-included-fields="filterOn"
            foot-clone
            no-footer-sorting
            @filtered="onFiltered"
            @row-clicked="rowClick"
          >
            <template #cell(id)="data">
              <b-link
                active
                :to="'/items/'+data.item.id"
              >
                {{ data.item.id }}
              </b-link>
            </template>
            <template #cell(whoDone)="data">
              <b-link
                v-if="hasAdminPermission"
                active
                :to="'/users/'+doneUserId(data.item)"
              >
                {{ doneUserName(data.item) }}
              </b-link>
            </template>
            <template #cell(type)="data">
              <template v-if="data.item.product">
                📦
              </template>
              <template v-else>
                🔧
              </template>
            </template>
            <template #cell(name)="data">
              <template v-if="data.item.product">
                <b-link
                  v-if="hasModeratorPermission"
                  active
                  :to="'/products/'+(data.item.product.id)"
                >
                  {{ data.item.product.name }}
                </b-link>
                <template v-else>
                  {{ data.item.product.name }}
                </template>
              </template>
              <template v-else>
                <b-link
                  v-if="hasModeratorPermission"
                  active
                  :to="'/services/'+(data.item.service.id)"
                >
                  {{ data.item.service.name }}
                </b-link>
                <template v-else>
                  {{ data.item.service.name }}
                </template>
              </template>
            </template>
            <template #foot()="">
              <span>{{ }}</span>
            </template>
            <template #foot(id)="">
              <span>Итого со скидкой: </span>
            </template>
            <template
              v-if="order.status === 'GIVEN'"
              #foot(whoDone)=""
            >
              <h5>{{ sumWithDiscount }}</h5>
            </template>
            <template
              v-else
              #foot(delete)=""
            >
              <h5>{{ sumWithDiscount }}</h5>
            </template>

            <template #cell(priceFor1)="data">
              {{ data.item.soldPrice }}
            </template>
            <template #cell(count)="data">
              {{ data.item.quantity }}
            </template>
            <template #cell(overall)="data">
              {{ data.item.quantity * data.item.soldPrice }}
            </template>
            <template #cell(delete)="data">
              <b-button
                :key="data.item.id"
                variant="danger"
                class="btn-icon border-danger border-darken-3 bg-danger bg-darken-3"
                @click="removeItem(data.item.id)"
              >
                <feather-icon
                  icon="Trash2Icon"
                  class="mr-15"
                />
              </b-button>
            </template>
          </b-table>

        </b-col>

        <b-col
          cols="12"
        >
          <h5>Всего: <b>{{ lengthComputed }}</b></h5>
          <h5>Скидка: <b>{{ discountPercent }}%</b></h5>
          <b-pagination
            v-model="currentPage"
            :total-rows="orderItems.length"
            :per-page="perPage"
            align="center"
            size="sm"
            class="my-0"
          />
        </b-col>
      </b-row>
    </b-card-actions>
  </div>
</template>

<script>
import {
  BTable, BInputGroupPrepend, BButton, BRow, BCol, BFormGroup, BFormSelect, BPagination, BInputGroup, BFormInput, BInputGroupAppend, BLink,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
// eslint-disable-next-line import/extensions
import BCardActions from '@core/components/b-card-actions/BCardActions'
import NewOrderAddItem from '@/views/orders/components/NewOrderAddItem.vue'

export default {
  components: {
    BLink,
    BCardActions,
    BTable,
    BRow,
    BButton,
    BCol,
    BFormGroup,
    BFormSelect,
    BPagination,
    BInputGroup,
    BFormInput,
    BInputGroupAppend,
    BInputGroupPrepend,
    // eslint-disable-next-line vue/no-unused-components
    NewOrderAddItem,
  },
  props: {
    // eslint-disable-next-line vue/require-default-prop
    orderItems: {
      type: Array,
    },
    id: {
      type: Number,
      required: true,
    },
    // eslint-disable-next-line vue/require-default-prop
    discountPercent: {
      type: Number,
    },
    products: {
      type: Array,
      required: true,
    },
    services: {
      type: Array,
      required: true,
    },
    order: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      isAddNewItemSidebarActive: false,
      perPage: 10,
      pageOptions: [1, 10, 20, 50],
      totalRows: 1,
      currentPage: 1,
      sortBy: 'id',
      sortDesc: true,
      sortDirection: 'asc',
      filter: null,
      length: 0,
      filterOn: ['id', 'name', 'priceFor1', 'count', 'overall', 'whoDone'],
      infoModal: {
        id: 'info-modal',
        title: '',
        content: '',
      },
      fields: [
        {
          key: 'id', label: 'Id', sortable: true,
        },
        {
          key: 'type', label: 'Тип', sortable: true,
        },
        {
          key: 'name', label: 'Название услуги / продукта', sortable: true,
        },
        { key: 'priceFor1', label: 'Цена услуги / продукта', sortable: true },
        {
          key: 'count', label: 'Количество', sortable: true,
        },
        {
          key: 'overall', label: 'Общий', sortable: true,
        },
        {
          key: 'whoDone', label: 'Сделал', sortable: true, requiresAdmin: true,
        },
        {
          key: 'delete', label: 'Удалить', requiresStatusGiven: true,
        },
      ],
    }
  },
  computed: {
    sortOptions() {
      // Create an options list from our fields
      return this.fields
        .filter(f => f.sortable)
        .map(f => ({ text: f.label, value: f.key }))
    },
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
    hasModeratorPermission() {
      if (this.user.roles.includes('MODERATOR')) {
        return true
      }
      return false
    },
    computedFields() {
      let { fields } = this
      if (!this.user.roles.includes('ADMIN')) {
        fields = fields.filter(field => !field.requiresAdmin)
      }
      if (!this.isStatusNonGiven()) {
        fields = fields.filter(field => !field.requiresStatusGiven)
      }
      return fields
    },
    lengthComputed() {
      return this.orderItems.length
    },
    sumWithDiscount() {
      let sum = 0.0
      // eslint-disable-next-line no-plusplus
      this.orderItems.forEach(item => {
        if (item.service) {
          sum += (item.soldPrice.toFixed(2) * item.quantity.toFixed(2)) * ((100 - this.discountPercent).toFixed(2) / 100)
        } else {
          sum += item.soldPrice * item.quantity
        }
      })
      return sum
    },
  },
  async mounted() {
    await this.fetchAllData()
    console.log('items', this.orderItems)
    console.log('Mounted', this.isStatusNonGiven())
  },
  methods: {
    info(item, index, button) {
      this.infoModal.title = `Row index: ${index}`
      this.infoModal.content = JSON.stringify(item, null, 2)
      this.$root.$emit('bv::show::modal', this.infoModal.id, button)
    },
    isStatusNonGiven() {
      if (this.order.status.toString() === 'GIVEN') {
        return false
      }
      return true
    },
    resetInfoModal() {
      this.infoModal.title = ''
      this.infoModal.content = ''
    },
    async fetchAllData() {
      this.totalRows = this.orderItems.length
    },
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length
      this.length = filteredItems.length
      this.currentPage = 1
    },
    doneUserName(data) {
      return `${data.doneUser.surname} ${data.doneUser.name}`
    },
    doneUserId(data) {
      return data.doneUser.id
    },
    addItem(data) {
      this.$emit('addItem', data)
    },
    rowClick(record) {
      this.$message('Вы нажали на Пользователя', `${record.fname} ${record.id}`, 'CheckSquareIcon', 'success')
    },
    async removeItem(itemId) {
      console.log('REMOVEITEM', itemId)
      this.$emit('removeItem', itemId)
    },
    refreshStop(cardName) {
      setTimeout(() => {
        this.$emit('refresh')
        this.$refs[cardName].showLoading = false
      }, 1000)
    },
    showAddItemModal() {
      this.$refs.addItemModal.show()
    },
  },
}
</script>

<style scoped>

</style>
