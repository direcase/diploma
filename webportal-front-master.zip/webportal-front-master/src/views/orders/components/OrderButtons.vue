<template>
  <div class="demo-inline-spacing">
    <order-message
      :id="order.id"
      :is-add-new-message-sidebar-active.sync="isAddNewMessageSidebarActive"
      :message="order.comment"
      @updateMessage="updateMessage"
    />
    <b-button
      v-if="order.status === 'NOTDONE'"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="warning"
      @click="orderDone"
    >
      <feather-icon
        icon="CheckIcon"
        class="mr-50"
      />
      <span class="align-middle">Исполнено</span>
    </b-button>
    <b-button
      v-if="!order.comment"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="primary"
      @click="isAddNewMessageSidebarActive = true"
    >
      <feather-icon
        icon="MessageCircleIcon"
        class="mr-50"
      />
      <span class="align-middle">Добавить Комментарии</span>
    </b-button>
    <b-button
      v-else
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="info"
      @click="isAddNewMessageSidebarActive = true"
    >
      <feather-icon
        icon="MessageCircleIcon"
        class="mr-50"
      />
      <span class="align-middle">Изменить Комментарии</span>
    </b-button>
    <b-button
      v-if="order.status === 'DONE' && order.notified == false"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="success"
      @click="notify"
    >
      <feather-icon
        icon="SmartphoneIcon"
        class="mr-50"
      />
      <span class="align-middle">Оповестить</span>
    </b-button>
    <b-button
      v-if="!(hasAcceptanceCertificate())"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="danger"
      @click="createAcceptanceCertificate"
    >
      <feather-icon
        icon="ClipboardIcon"
        class="mr-50"
      />
      <span class="align-middle">Создать АПП</span>
    </b-button>
    <b-button
      v-if="this.order.status == 'GIVEN' && !hasCertificateOfCompletion()"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="warning"
      @click="createCertificateOfCompletion"
    >
      <feather-icon
        icon="ClipboardIcon"
        class="mr-50"
      />
      <span class="align-middle">Создать АВР</span>
    </b-button>
    <b-button
      v-if="order.status === 'DONE'"
      v-ripple.400="'rgba(255, 255, 255, 0.15)'"
      variant="dark"
      @click="waitPayment"
    >
      <feather-icon
        icon="DollarSignIcon"
        class="mr-50"
      />
      <span class="align-middle">Ожидается Платеж</span>
    </b-button>
  </div>
</template>

<script>
import { BButton } from 'bootstrap-vue'
import Ripple from 'vue-ripple-directive'
import OrderMessage from '@/views/orders/components/messageComponent/OrderMessage.vue'

export default {
  components: {
    BButton,
    OrderMessage,
  },
  directives: {
    Ripple,
  },
  props: {
    order: {
      type: Object,
    },
    documents: {
      type: Array,
    },
  },
  data: () => ({
    isAddNewMessageSidebarActive: false,
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
  },
  methods: {
    success() {
      this.$swal({
        title: 'Good job!',
        text: 'You clicked the button!',
        icon: 'success',
        customClass: {
          confirmButton: 'btn btn-primary',
        },
        buttonsStyling: false,
      })
    },
    hasAcceptanceCertificate() {
      // eslint-disable-next-line consistent-return
      let boolean = false
      this.documents.forEach(document => {
        if (document.documentType === 'ACCEPTANCE_CERTIFICATE') {
          boolean = true
        }
      })
      return boolean
    },
    hasCertificateOfCompletion() {
      // eslint-disable-next-line consistent-return
      let boolean = false
      this.documents.forEach(document => {
        if (document.documentType === 'CERTIFICATE_OF_COMPLETION') {
          boolean = true
        }
      })
      return boolean
    },
    orderDone() {
      this.$emit('orderDone')
    },
    updateMessage(messageData) {
      this.$emit('updateMessage', messageData)
    },
    notify() {
      this.$emit('notify')
    },
    waitPayment() {
      this.$emit('waitPayment')
    },
    async createAcceptanceCertificate() {
      try {
        const data = {}
        data.orderId = this.order.id
        data.documentType = 'ACCEPTANCE_CERTIFICATE'
        const document = await this.$store.dispatch('createDocument', data)
        this.$message('Акт Приемки передачи успешно создан', 'Акт Приемки передачи успешно создан', 'ClipboardIcon', 'success')
        this.$emit('addDocument', document)
      } catch (e) {
        console.log(e)
      }
    },
    async createCertificateOfCompletion() {
      try {
        const data = {}
        data.orderId = this.order.id
        data.documentType = 'CERTIFICATE_OF_COMPLETION'
        const document = await this.$store.dispatch('createDocument', data)
        this.$message('Акт выполненных работ успешно создан', 'Акт выполненных работ успешно создан', 'ClipboardIcon', 'success')
        this.$emit('addDocument', document)
      } catch (e) {
        console.log(e)
      }
    },
  },
}
</script>
