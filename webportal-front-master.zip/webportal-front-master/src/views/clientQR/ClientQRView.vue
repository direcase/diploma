<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="order === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного заказа с этим идентификатором заказа.
        </div>
      </b-alert>

      <template v-if="order">
        <!-- First Row -->
        <b-row>
          <b-col
            cols="12"
            xl="8"
            lg="8"
            md="7"
          >
            <client-order-info-card
              :order="order"
            />
          </b-col>
          <b-col
            cols="12"
            md="5"
            xl="4"
            lg="4"
          >
            <client-order-time-line :order="order" />
          </b-col>
        </b-row>
        <client-order-items
          :order="order"
        />
        <!--      <invoice-list />-->
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BCol, BRow,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import ClientOrderInfoCard from '@/views/clientQR/components/ClientOrderInfoCard.vue'
import ClientOrderTimeLine from '@/views/clientQR/components/ClientOrderTimeLine.vue'
import Loader from '@/layouts/components/Loader.vue'
import ClientOrderItems from '@/views/clientQR/components/ClientOrderItems.vue'

export default {
  components: {
    Loader,
    BAlert,
    BCol,
    BRow,
    ClientOrderInfoCard,
    ClientOrderItems,
    ClientOrderTimeLine,
  },
  data: () => ({
    order: {},
    products: [],
    services: [],
    discountOptions: [],
    typeOptions: [],
    modelOptions: [],
    clientOptions: [],
    loader: true,
  }),
  computed: {
  },
  async mounted() {
    await this.fetchAllData()
    this.loader = false
  },
  methods: {
    async fetchAllData() {
      try {
        this.loader = true
        this.order = await this.$store.dispatch('fetchOrderByIdAndToken', { id: this.$route.params.id, token: this.$route.params.token })
        this.loader = false
      } catch (e) {
        if (e.response.data.code === 'order/not-found') {
          this.order = undefined
          this.loader = false
        }
      }
    },
    async refresh() {
      this.loader = true
      this.order = await this.$store.dispatch('fetchOrderByIdAndToken', { id: this.$route.params.id, token: this.$route.params.token })
      this.loader = false
    },
  },
}
</script>

<style>

</style>
