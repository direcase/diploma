<template>
  <div>
    <b-card-actions
      ref="cardAction"
      title="Услуги и Товары 📦🔧"
      action-refresh
      @refresh="refreshStop('cardAction')"
    >
      <b-row>
        <b-col
          md="2"
          sm="4"
          class="my-1"
        >
          <b-form-group
            class="mb-0"
          >
            <label class="d-inline-block text-sm-left mr-50">На страницу</label>
            <b-form-select
              id="perPageSelect"
              v-model="perPage"
              size="sm"
              :options="pageOptions"
              class="w-50"
            />
          </b-form-group>
        </b-col>
        <b-col
          md="4"
          sm="8"
          class="my-1"
        >
          <b-form-group
            label="Сортировать"
            label-cols-sm="3"
            label-align-sm="right"
            label-size="sm"
            label-for="sortBySelect"
            class="mb-0"
          >
            <b-input-group size="sm">
              <b-form-select
                id="sortBySelect"
                v-model="sortBy"
                :options="sortOptions"
                class="w-75"
              >
                <template v-slot:first>
                  <option value="">
                    -- ничто --
                  </option>
                </template>
              </b-form-select>
              <b-form-select
                v-model="sortDesc"
                size="sm"
                :disabled="!sortBy"
                class="w-25"
              >
                <option :value="false">
                  По возрастанию
                </option>
                <option :value="true">
                  По убыванию
                </option>
              </b-form-select>
            </b-input-group>
          </b-form-group>
        </b-col>
        <b-col
          md="6"
          class="my-1"
        >
          <b-form-group
            label="Фильтр"
            label-cols-sm="3"
            label-align-sm="right"
            label-size="sm"
            label-for="filterInput"
            class="mb-0"
          >
            <b-input-group size="sm">
              <b-form-input
                id="filterInput"
                v-model="filter"
                type="search"
                placeholder="Введите для поиска"
              />
            </b-input-group>
          </b-form-group>
        </b-col>

        <b-col cols="12">
          <b-table
            class="position-relative"
            striped
            hover
            responsive
            :per-page="perPage"
            :current-page="currentPage"
            :items="order.items"
            :fields="fields"
            :sort-by.sync="sortBy"
            :sort-desc.sync="sortDesc"
            :sort-direction="sortDirection"
            :filter="filter"
            :filter-included-fields="filterOn"
            foot-clone
            no-footer-sorting
            @filtered="onFiltered"
            @row-clicked="rowClick"
          >
            <template #cell(status)="data">
              <b-badge
                pill
                :variant="getStatusVariant(data.item.status.toString())"
              >
                {{ getStatusText(data.item.status.toString()) }}
              </b-badge>
            </template>
            <template #cell(accepted)="data">
              {{ getDateByFormat(data.item.accepted, 'datetime') }}
            </template>
            <template #cell(id)="data">
              <b-link
                active
                :to="'/items/'+data.item.id"
              >
                {{ data.item.id }}
              </b-link>
            </template>
            <template #cell(type)="data">
              <template v-if="data.item.product">
                📦
              </template>
              <template v-else>
                🔧
              </template>
            </template>
            <template #cell(name)="data">
              <template v-if="data.item.product">
                {{ data.item.product.name }}
              </template>
              <template v-else>
                {{ data.item.service.name }}
              </template>
            </template>
            <template #foot()="">
              <span>{{ }}</span>
            </template>
            <template #foot(id)="">
              <span>Итого со скидкой: </span>
            </template>
            <template
              #foot(overall)=""
            >
              <h5>{{ sumWithDiscount }}</h5>
            </template>

            <template #cell(priceFor1)="data">
              {{ data.item.soldPrice }}
            </template>
            <template #cell(count)="data">
              {{ data.item.quantity }}
            </template>
            <template #cell(overall)="data">
              {{ data.item.quantity * data.item.soldPrice }}
            </template>
          </b-table>

        </b-col>

        <b-col
          cols="12"
        >
          <h5>Всего: <b>{{ lengthComputed }}</b></h5>
          <h5>Скидка: <b>{{ order.discountPercent }}%</b></h5>
          <b-pagination
            v-model="currentPage"
            :total-rows="order.items.length"
            :per-page="perPage"
            align="center"
            size="sm"
            class="my-0"
          />
        </b-col>
      </b-row>
    </b-card-actions>
  </div>
</template>

<script>
import {
  BTable, BBadge, BRow, BCol, BFormGroup, BFormSelect, BPagination, BInputGroup, BFormInput, BLink,
} from 'bootstrap-vue'
import Ripple from 'vue-ripple-directive'
// eslint-disable-next-line import/extensions
// eslint-disable-next-line import/extensions
import BCardActions from '@core/components/b-card-actions/BCardActions'

export default {
  directives: {
    Ripple,
  },
  components: {
    BLink,
    BCardActions,
    BTable,
    BBadge,
    BRow,
    BCol,
    BFormGroup,
    BFormSelect,
    BPagination,
    BInputGroup,
    BFormInput,
    // eslint-disable-next-line vue/no-unused-components
  },
  props: {
    order: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      isAddNewItemSidebarActive: false,
      perPage: 10,
      pageOptions: [1, 10, 20, 50],
      totalRows: 1,
      currentPage: 1,
      sortBy: 'id',
      sortDesc: true,
      sortDirection: 'asc',
      filter: null,
      length: 0,
      filterOn: ['name', 'number'],
      infoModal: {
        id: 'info-modal',
        title: '',
        content: '',
      },
      fields: [
        {
          key: 'id', label: 'Id', sortable: true,
        },
        {
          key: 'type', label: 'Тип', sortable: true,
        },
        {
          key: 'name', label: 'Название услуги / продукта', sortable: true,
        },
        { key: 'priceFor1', label: 'Цена услуги / продукта', sortable: true },
        {
          key: 'count', label: 'Количество', sortable: true,
        },
        {
          key: 'overall', label: 'Общий', sortable: true,
        },
      ],
    }
  },
  computed: {
    sortOptions() {
      // Create an options list from our fields
      return this.fields
        .filter(f => f.sortable)
        .map(f => ({ text: f.label, value: f.key }))
    },
    user() {
      return this.$store.getters.user
    },
    lengthComputed() {
      return this.order.items.length
    },
    sumWithDiscount() {
      let sum = 0.0
      // eslint-disable-next-line no-plusplus
      this.order.items.forEach(item => {
        if (item.service) {
          sum += (item.soldPrice.toFixed(2) * item.quantity.toFixed(2)) * ((100 - this.order.discountPercent).toFixed(2) / 100)
        } else {
          sum += item.soldPrice * item.quantity
        }
      })
      console.log('SUM', sum)
      return sum
    },
  },
  async mounted() {
    console.log(this.order)
    await this.fetchAllData()
    console.log('Mounted', this.isStatusNonGiven())
  },
  methods: {
    info(item, index, button) {
      this.infoModal.title = `Row index: ${index}`
      this.infoModal.content = JSON.stringify(item, null, 2)
      this.$root.$emit('bv::show::modal', this.infoModal.id, button)
    },
    isStatusNonGiven() {
      if (this.order.status.toString() === 'GIVEN') {
        return false
      }
      return true
    },
    resetInfoModal() {
      this.infoModal.title = ''
      this.infoModal.content = ''
    },
    async fetchAllData() {
      this.totalRows = this.order.items.length
    },
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length
      this.length = filteredItems.length
      this.currentPage = 1
    },
    refreshStop(cardName) {
      setTimeout(() => {
        this.$emit('refresh')
        this.$refs[cardName].showLoading = false
      }, 1000)
    },
  },
}
</script>

<style scoped>

</style>
