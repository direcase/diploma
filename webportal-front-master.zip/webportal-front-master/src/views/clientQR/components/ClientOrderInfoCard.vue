<template>
  <b-card>

    <b-row>
      <!-- User Info: Left col -->
      <b-col
        cols="21"
        xl="6"
        class="d-flex justify-content-between flex-column"
      >
        <!-- User Avatar & Action Buttons -->
        <div class="d-flex justify-content-start">
          <b-avatar
            :text="'ES'"
            :variant="'light-success'"
            size="104px"
            rounded
          />
          <div class="d-flex flex-column ml-1">
            <div class="mb-1">
              <h4 class="mb-0">
                {{ getName() }}
              </h4>
              <span class="card-text">{{ getNumber() }}</span>
            </div>
          </div>
        </div>
        <!-- Order Buttons -->
      </b-col>

      <!-- Right Col: Table -->
      <b-col
        cols="12"
        xl="6"
      >
        <table class="mt-2 mt-xl-0 w-100">
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="HardDriveIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Тип устройства {{ order.items.length }}</span>
            </th>
            <td class="pb-50">
              {{ getType() }}
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="CheckIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Статус</span>
            </th>
            <td class="pb-50 text-capitalize">
              <b-badge
                pill
                :variant="getStatusVariant()"
              >
                {{ getStatusText() }}
              </b-badge>
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="UserIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Принял</span>
            </th>
            <td class="pb-50 text-capitalize">
              {{ accepted() }}
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="CalendarIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Дата приема</span>
            </th>
            <td class="pb-50">
              {{ acceptedDate() }}
            </td>
          </tr>
          <tr>
            <th>
              <feather-icon
                icon="InfoIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Проблема</span>
            </th>
            <td>
              {{ order.problem }}
            </td>
          </tr>
          <tr v-if="order.comment">
            <th>
              <feather-icon
                icon="MessageSquareIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Комментарии</span>
            </th>
            <td>
              {{ order.comment }}
            </td>
          </tr>
          <tr v-if="order.doneUser">
            <th class="pb-50">
              <feather-icon
                icon="UserIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Сделал</span>
            </th>
            <td class="pb-50 text-capitalize">
              {{ done() }}
            </td>
          </tr>
          <tr v-if="order.doneDate">
            <th class="pb-50">
              <feather-icon
                icon="CalendarIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Выполнено</span>
            </th>
            <td class="pb-50">
              {{ doneDate() }}
            </td>
          </tr>
          <tr>
            <th class="pb-50">
              <feather-icon
                icon="MailIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Уведомлено</span>
            </th>
            <td class="pb-50 text-capitalize">
              <b-badge
                pill
                :variant="getNotifyVariant()"
              >
                {{ getNotifyText() }}
              </b-badge>
            </td>
          </tr>
          <tr v-if="order.giveUser">
            <th class="pb-50">
              <feather-icon
                icon="UserIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Выдал</span>
            </th>
            <td class="pb-50 text-capitalize">
              {{ give() }}
            </td>
          </tr>
          <tr v-if="order.gaveDate">
            <th class="pb-50">
              <feather-icon
                icon="CalendarIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Выдано</span>
            </th>
            <td class="pb-50">
              {{ gaveDate() }}
            </td>
          </tr>
          <tr v-if="order.typesOfPayments">
            <th class="pb-50">
              <feather-icon
                icon="CalendarIcon"
                class="mr-75"
              />
              <span class="font-weight-bold">Способ Оплаты</span>
            </th>
            <td class="pb-50">
              {{ typesOfPayments() }}
            </td>
          </tr>
        </table>
      </b-col>
    </b-row>
  </b-card>
</template>

<script>
import {
  BCard, BAvatar, BBadge, BRow, BCol,
} from 'bootstrap-vue'

export default {
  components: {
    BCard, BRow, BCol, BAvatar, BBadge,
  },
  props: {
    order: {
      type: Object,
      required: true,
    },
  },
  data: () => ({
    isUpdateOrderSidebarActive: false,
  }),
  methods: {
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = 'long'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
    getName() {
      console.log('OrderInfo', this.order)
      if (this.order.client) {
        return `${this.order.client.surname} ${this.order.client.name}`
      }
      return this.order.clientName
    },
    getNumber() {
      if (this.order.client) {
        return `${this.order.client.phoneNumber}`
      }
      return this.order.phoneNumber
    },
    getType() {
      return `${this.order.type.name} ${this.order.model.name} ${this.order.modelCompany}`
    },
    getNotifyText() {
      if (this.order.notified) {
        return 'Да'
      }
      return 'Нет'
    },
    getNotifyVariant() {
      if (this.order.notified) {
        return 'success'
      }
      return 'danger'
    },
    getStatusVariant() {
      switch (this.order.status.toString()) {
        case 'DONE':
          return 'warning'
        case 'NOTDONE':
          return 'danger'
        case 'WENTCASHIER':
          return 'primary'
        default:
          return 'success'
      }
    },
    getStatusText() {
      switch (this.order.status.toString()) {
        case 'DONE':
          return 'Сделано'
        case 'NOTDONE':
          return 'Не сделано'
        case 'WENTCASHIER':
          return 'Ожидается платеж'
        default:
          return 'Выдано'
      }
    },
    accepted() {
      return `${this.order.acceptedUser.surname} ${this.order.acceptedUser.name}`
    },
    done() {
      return `${this.order.doneUser.surname} ${this.order.doneUser.name}`
    },
    give() {
      return `${this.order.giveUser.surname} ${this.order.giveUser.name}`
    },
    acceptedDate() {
      return this.getDateByFormat(this.order.acceptedDate, 'datetime')
    },
    doneDate() {
      return this.getDateByFormat(this.order.doneDate, 'datetime')
    },
    gaveDate() {
      return this.getDateByFormat(this.order.gaveDate, 'datetime')
    },
    typesOfPayments() {
      console.log('type', this.order.typesOfPayments.toString())
      switch (this.order.typesOfPayments.toString()) {
        case 'cash':
          return 'Наличными'
        case 'contract':
          return 'По договору'
        case 'online':
          return 'Перевод'
        default:
          return 'Долг'
      }
    },
  },
}
</script>

<style>

</style>
