<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="user === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного пользователя с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/users'"
          >
            Список пользователей
          </b-link>
        </div>
      </b-alert>

      <template v-if="user">
        <new-user-update
          ref="updateModal"
          :user="user"
          :experience-options="experienceOptions"
          :role-options="roleOptions"
          @updateUser="updateUser"
        />
        <hr>
        <h3>{{ user.surname + ' ' +user.name }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3"
            @click="showUpdateModal"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteModel"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="success"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <user-info-card
          :user="user"
          :users-all-profit="usersAllProfit"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import NewUserUpdate from '@/views/users/components/NewUserUpdate.vue'
import UserInfoCard from '@/views/users/components/UserInfoCard.vue'

export default {
  components: {
    // eslint-disable-next-line vue/no-unused-components
    NewUserUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    UserInfoCard,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    user: {},
    usersAllProfit: {},
    loader: true,
    roleOptions: [],
    experienceOptions: [],
  }),
  async mounted() {
    try {
      await this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    updateUser(data) {
      if (data) {
        this.user = data
      }
    },
    deleteModel() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteUser', this.user.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Ползователь удален с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/users')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    async fetchAllData() {
      try {
        this.loader = true
        this.user = await this.$store.dispatch('fetchUserById', this.$route.params.id)
        this.roleOptions = await this.$store.dispatch('fetchAllRoles')
        this.experienceOptions = await this.$store.dispatch('fetchAllExperiences', this.$route.params.id)
        /* this.usersAllProfit = await this.$store.dispatch('fetchMastersAllProfit', this.$route.params.id)
        */
        this.loader = false
      } catch (e) {
        this.user = undefined
        this.loader = false
      }
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
