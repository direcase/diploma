<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="TagIcon"
          :statistic="user.username"
          statistic-title="Логин"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="UserIcon"
          :statistic="user.surname+' '+user.name"
          statistic-title="ФИО"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="UserCheckIcon"
          :statistic="getRoles(user)"
          statistic-title="Роли"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="SmileIcon"
          :statistic="user.experienceModel.name"
          statistic-title="Опыт"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <b-link :href="'tel:'+user.phoneNumber">
          <statistic-card-vertical
            color="success"
            icon="SmileIcon"
            :statistic="user.phoneNumber"
            statistic-title="Тел. Номер"
          />
        </b-link>
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <!--        <statistic-card-vertical
          color="success"
          icon="SmileIcon"
          :statistic="usersAllProfit.profit+'₸'"
          statistic-title="Заработано за весь период"
        />-->
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="primary"
          icon="UserCheckIcon"
          :statistic="user.enabled ? 'Да':'Нет'"
          statistic-title="Активен"
        />
      </b-col>
    </b-row>
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol, BLink,
} from 'bootstrap-vue'

export default {
  components: {
    BRow,
    BLink,
    BCol,
    StatisticCardVertical,
  },
  props: {
    user: {
      type: Object,
      required: true,
    },
    usersAllProfit: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  methods: {
    getRoles(user) {
      let text = ''
      user.roles.forEach(role => {
        text += `${this.getRoleText(role)} ${'\n'}`
      })
      return text
    },
    getRoleText(role) {
      if (role === 'ADMIN') {
        return 'Админ'
      }
      if (role === 'MODERATOR') {
        return 'Модератор'
      }
      if (role === 'USER') {
        return 'Мастер'
      }
      if (role === 'CASHIER') {
        return 'Кассир'
      }
      return 'Неизвестный'
    },
  },
}
</script>

<style>

</style>
