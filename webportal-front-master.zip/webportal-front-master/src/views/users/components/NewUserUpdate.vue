<template>
  <b-modal
    id="modal-tall"
    ref="modal"
    centered
    title="Изменить пользователя 💁"
    cancel-title="Отменить"
    ok-title="Изменить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <validation-provider
          #default="validationContext"
          name="Имя"
          rules="required"
        >
          <b-form-group
            label="Имя"
            label-for="nameUser"
          >
            <b-form-input
              id="nameUser"
              v-model="userData.name"
              autofocus
              :state="getValidationState(validationContext)"
              trim
              placeholder="Имя"
            />
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Last Name -->
        <validation-provider
          #default="validationContext"
          name="Фамилия"
          rules="required"
        >
          <b-form-group
            label="Фамилия"
            label-for="surnameUser"
          >
            <b-form-input
              id="surnameUser"
              v-model="userData.surname"
              autofocus
              :state="getValidationState(validationContext)"
              trim
              placeholder="Фамилия"
            />
            <p
              v-if="validation.surname"
              class="text-danger"
            >
              {{ validation.surname }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Username -->
        <validation-provider
          #default="validationContext"
          name="Username"
          rules="required"
        >
          <b-form-group
            label="Логин"
            label-for="username"
          >
            <b-form-input
              id="username"
              v-model="userData.username"
              :state="getValidationState(validationContext)"
              trim
            />
            <p
              v-if="validation.username"
              class="text-danger"
            >
              {{ validation.username }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- password -->
        <validation-provider
          #default="{ errors }"
          name="Пароль"
          rules="required"
        >
          <b-form-group
            label="Пароль"
            label-for="login-password"
          >
            <b-input-group
              class="input-group-merge"
              :class="errors.length > 0 ? 'is-invalid':null"
            >
              <b-form-input
                id="login-password"
                v-model="userData.password"
                :state="errors.length > 0 ? false:null"
                class="form-control-merge"
                :type="passwordFieldType"
                name="login-password"
                placeholder="············"
              />
              <b-input-group-append is-text>
                <feather-icon
                  class="cursor-pointer"
                  :icon="passwordToggleIcon"
                  @click="togglePasswordVisibility"
                />
              </b-input-group-append>
            </b-input-group>
            <p
              v-if="validation.password"
              class="text-danger"
            >
              {{ validation.password }}
            </p>
          </b-form-group>
          <small class="text-danger">{{ errors[0] }}</small>
        </validation-provider>
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Тел номер"
          rules="required"
        >
          <b-form-group
            label="Телефон Номер"
            label-for="phoneNumber"
          >
            <b-form-input
              id="phoneNumber"
              v-model="userData.phoneNumber"
              :state="getValidationState(validationContext)"
              trim
            />
            <p
              v-if="validation.phoneNumber"
              class="text-danger"
            >
              {{ validation.phoneNumber }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- User Role -->
        <validation-provider
          #default="validationContext"
          name="User Role"
          rules="required"
        >
          <b-form-group
            label="Роли"
            label-for="user-role"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="userData.roles"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="roleOptions"
              :reduce="val => val.value"
              :clearable="false"
              input-id="user-role"
              multiple=""
            />
            <p
              v-if="validation.roles"
              class="text-danger"
            >
              {{ validation.roles }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Plan -->
        <validation-provider
          #default="validationContext"
          name="Plan"
          rules="required"
        >
          <b-form-group
            label="Опыт"
            label-for="experienceModel"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="userData.experienceModelId"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="experienceOptions"
              :reduce="val => val.value"
              :clearable="false"
              input-id="experienceModel"
            />
            <p
              v-if="validation.experienceModelId"
              class="text-danger"
            >
              {{ validation.experienceModelId }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <validation-provider
          #default="validationContext"
          name="Активен"
          rules="required"
        >
          <b-form-group
            label="Активен"
            label-for="active"
          >
            <b-input-group>
              <b-form-checkbox
                id="active"
                v-model="userData.enabled"
                checked="true"
                class="custom-control-success"
                name="check-button"
                switch
              />
            </b-input-group>
            <p
              v-if="validation.enabled"
              class="text-danger"
            >
              {{ validation.enabled }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>
  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupAppend, BFormCheckbox, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import vSelect from 'vue-select'
import { togglePasswordVisibility } from '@core/mixins/ui/forms'

export default {
  name: 'UpdateTypeModal',
  components: {
    BInputGroup,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BInputGroupAppend,
    BFormCheckbox,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
    vSelect,
  },
  directives: {
    Ripple,
  },
  mixins: [togglePasswordVisibility],
  props: {
    user: {
      type: Object,
      required: true,
    },
    roleOptions: {
      type: Array,
      required: true,
    },
    experienceOptions: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  computed: {
    passwordToggleIcon() {
      return this.passwordFieldType === 'password' ? 'EyeIcon' : 'EyeOffIcon'
    },
  },
  mounted() {
    if (this.user) {
      this.setData(this.user)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankUserData = {
      id: null,
      name: '',
      surname: '',
      username: '',
      password: '',
      roles: [],
      phoneNumber: '',
      experienceModelId: null,
      enabled: null,
    }
    const userData = ref(JSON.parse(JSON.stringify(blankUserData)))
    const resetOrderData = () => {
      userData.value = JSON.parse(JSON.stringify(blankUserData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)
    return {
      userData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    setData(data) {
      this.userData.id = data.id
      this.userData.name = data.name
      this.userData.surname = data.surname
      this.userData.username = data.username
      this.userData.password = data.password
      this.userData.roles = data.roles
      this.userData.phoneNumber = data.phoneNumber
      this.userData.experienceModelId = data.experienceModel.id
      this.userData.enabled = data.enabled
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    reset() {
      this.setData(this.user)
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateUser', this.userData)
        this.$message('Пользователь успешно обновлен', `${data.surname} ${data.name} успешно обновлен`, 'DatabaseIcon', 'success')
        this.validation = {}
        this.$emit('updateUser', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
