<template>
  <b-card
    class="card-transaction"
    no-body
  >
    <b-card-header>
      <b-card-title>{{ title }}</b-card-title>
      <feather-icon
        icon="MoreVerticalIcon"
        size="18"
        class="cursor-pointer"
      />
    </b-card-header>

    <b-card-body>
      <div
        v-for="(item, index) in topProfitItems"
        :key="item.id"
        class="transaction-item"
      >
        <b-media no-body>
          <b-media-aside>
            <b-avatar
              rounded
              size="42"
              :variant="styles[index]"
            >
              <feather-icon
                v-if="isProduct"
                size="18"
                icon="PackageIcon"
              />
              <feather-icon
                v-else
                size="18"
                icon="SettingsIcon"
              />
            </b-avatar>
          </b-media-aside>
          <b-media-body>
            <h6 class="transaction-title">
              {{ item.name }}
            </h6>
            <template v-if="isProduct">
              <b-link :to="'/products/'+item.id">
                <small>Ссылка на страницу товара</small>
              </b-link>
            </template>
            <template v-else>
              <b-link :to="'/services/'+item.id">
                <small>Ссылка на страницу услуги</small>
              </b-link>
            </template>
          </b-media-body>
        </b-media>
        <div
          class="font-weight-bolder"
          :class="'text-success'"
        >
          {{ item.profit }} ₸
        </div>
      </div>
    </b-card-body>
  </b-card>
</template>

<script>
import {
  BCard, BCardHeader, BCardTitle, BCardBody, BMediaBody, BMedia, BMediaAside, BAvatar, BLink,
} from 'bootstrap-vue'

export default {
  components: {
    BCard,
    BCardHeader,
    BCardTitle,
    BCardBody,
    BMediaBody,
    BMedia,
    BMediaAside,
    BAvatar,
    BLink,
  },
  props: {
    topProfitItems: {
      type: Array,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    isProduct: {
      type: Boolean,
      required: true,
    },
  },
  data() {
    return {
      styles: [
        'success',
        'primary',
        'info',
        'warning',
        'danger',
      ],
    }
  },
}
</script>
