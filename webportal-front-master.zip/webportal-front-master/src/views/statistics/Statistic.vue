<template>
  <div>
    <Loader v-if="loader" />
    <section
      v-else
      id="dashboard-ecommerce"
    >
      <b-row class="match-height">
        <b-col
          v-if="topSaleProduct"
          xl="2"
          md="4"
          sm="6"
        >
          <b-link :to="'/products/'+topSaleProduct.id">
            <statistic-card-vertical
              icon="PackageIcon"
              :statistic="topSaleProduct.name"
              :second-title="topSaleProduct.count.toString()"
              statistic-title="Лидер продаж среди товаров"
              color="info"
            />
          </b-link>
        </b-col>
        <b-col
          v-if="topSaleService"
          xl="2"
          md="4"
          sm="6"
        >
          <b-link :to="'/services/'+topSaleService.id">
            <statistic-card-vertical
              color="warning"
              icon="SettingsIcon"
              :statistic="topSaleService.name"
              :second-title="topSaleService.count.toString()"
              statistic-title="Лидер продаж среди услуг"
            />
          </b-link>
        </b-col>
        <b-col
          xl="8"
          md="6"
        >
          <ecommerce-statistics :data="dataStatistic" />
        </b-col>
      </b-row>

      <b-row class="match-height">
        <b-col lg="4">
          <b-row class="match-height">
          <!-- Bar Chart - Orders -->
          <!--/ Bar Chart - Orders -->
          </b-row>
        </b-col>
      </b-row>

      <b-row>
        <b-col lg="12">
          <b-row class="match-height">
            <b-col md="6">
              <top-profit-items
                :is-product="true"
                title="Топ 5 товаров по доходности"
                :top-profit-items="topProfitProducts"
              />
            </b-col>
            <b-col md="6">
              <top-profit-items
                :is-product="false"
                title="Топ 5 услуг по доходности"
                :top-profit-items="topProfitServices"
              />
            </b-col>
          </b-row>
        </b-col>
      </b-row>
      <b-row class="match-height">
      <!--/ Transaction Card -->
      </b-row>
    </section>
  </div>
</template>

<script>
import { BRow, BCol, BLink } from 'bootstrap-vue'
import Loader from '@/layouts/components/Loader.vue'
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'
import EcommerceStatistics from '@/views/statistics/components/EcommerceStatistics.vue'
import TopProfitItems from '@/views/statistics/components/TopProfitItems.vue'

export default {
  components: {
    BRow,
    BCol,
    BLink,
    EcommerceStatistics,
    StatisticCardVertical,
    Loader,
    TopProfitItems,
  },
  data() {
    return {
      loader: true,
      topSaleProduct: {},
      topProfitProducts: [],
      topProfitServices: [],
      productSold: {},
      serviceSold: {},
      topSaleService: {},
      ordersCount: {},
      netProfit: {},
      dataMedal: { name: 'Eldar', saleToday: 45000 },
      dataStatistic: [
        {
          color: 'light-primary', customClass: 'mb-2 mb-xl-0', icon: 'SettingsIcon', subtitle: 'услуг продано', title: '230k',
        },
        {
          color: 'light-info', customClass: 'mb-2 mb-xl-0', icon: 'PackageIcon', subtitle: 'товаров продано', title: '430k',
        },
        {
          color: 'light-danger', customClass: 'mb-2 mb-xl-0', icon: 'ShoppingCartIcon', subtitle: 'заказов принято', title: '130k',
        },
        {
          color: 'light-success', customClass: 'mb-2 mb-xl-0', icon: 'DollarSignIcon', subtitle: 'заработано', title: '130k',
        },
      ],
    }
  },
  async mounted() {
    await this.fetchAllData()
  },
  methods: {
    async fetchAllData() {
      this.loader = true
      this.topSaleProduct = await this.$store.dispatch('fetchTopSaleProduct')
      this.topSaleService = await this.$store.dispatch('fetchTopSaleService')
      this.productSold = await this.$store.dispatch('fetchSoldProductCount')
      this.serviceSold = await this.$store.dispatch('fetchSoldServiceCount')
      this.ordersCount = await this.$store.dispatch('fetchOrdersCount')
      this.netProfit = await this.$store.dispatch('fetchNetProfit')
      this.topProfitProducts = await this.$store.dispatch('fetchTopProfitProducts')
      this.topProfitServices = await this.$store.dispatch('fetchTopProfitServices')
      this.dataStatistic[0].title = `${this.serviceSold.count ? `${this.serviceSold.count} шт` : 'Еще не продано'}`
      this.dataStatistic[1].title = `${this.productSold.count ? `${this.productSold.count} шт` : 'Еще не продано'}`
      this.dataStatistic[2].title = `${this.ordersCount.count} шт`
      this.dataStatistic[3].title = `${this.netProfit.profit ? `${this.netProfit.profit} ₸` : 'Еще не продано'}`
      this.loader = false
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/pages/dashboard-ecommerce.scss';
@import '@core/scss/vue/libs/chart-apex.scss';
</style>
