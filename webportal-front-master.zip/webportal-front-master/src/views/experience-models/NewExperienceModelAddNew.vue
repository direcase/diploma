<template>
  <b-modal
    id="modal-scrollable"
    ref="modal"
    scrollable
    centered
    title="Добавить новый опыт 🆙"
    cancel-title="Отменить"
    ok-title="Добавить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >
    <!-- BODY -->
    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Название Сервисного Центра"
          rules="required"
        >
          <b-form-group
            label="Название Опыта"
            label-for="experienceModelName"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="TagIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="experienceModelName"
                v-model="experienceModelData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <validation-provider
          #default="validationContext"
          name="Коэффициент"
          rules="required"
        >
          <b-form-group
            label="Коэффициент"
            label-for="experienceModelCoefficient"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PercentIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="experienceModelCoefficient"
                v-model.number="experienceModelData.coefficient"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.coefficient"
              class="text-danger"
            >
              {{ validation.coefficient }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'ExperienceModelAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankExperienceModelCenterData = {
      name: '',
      coefficient: 0,
    }
    const experienceModelData = ref(JSON.parse(JSON.stringify(blankExperienceModelCenterData)))
    const resetOrderData = () => {
      experienceModelData.value = JSON.parse(JSON.stringify(blankExperienceModelCenterData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      experienceModelData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    resetExperienceModelData() {
      this.experienceModelData.name = ''
      this.experienceModelData.coefficient = 0
    },
    reset() {
      this.resetExperienceModelData()
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('addExperienceModel', this.experienceModelData)
        this.$message(`Опыт ${data.name} успешно добавлен в базу`, `${data.name} успешно добавлен в базу`, 'DatabaseIcon', 'success')
        this.validation = {}
        this.$emit('addExperienceModel', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
