<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isUpdateExperienceModelSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="reset"
    @change="(val) => $emit('update:is-update-experience-model-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
        <h5 class="mb-0">
          Изменить скидку 💯
        </h5>

        <feather-icon
          class="ml-1 cursor-pointer"
          icon="XIcon"
          size="16"
          @click="hide"
        />

      </div>

      <!-- BODY -->
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandler"
          @reset.prevent="reset"
        >
          <!-- Phone Number -->
          <validation-provider
            #default="validationContext"
            name="Наименование Опыта"
            rules="required"
          >
            <b-form-group
              label="Наименование Опыта"
              label-for="name"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="TagIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="name"
                  v-model="experienceModelData.name"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.name"
                class="text-danger"
              >
                {{ validation.name }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!--          Product Name-->
          <validation-provider
            #default="validationContext"
            name="Коэффициент"
            rules="required"
          >
            <b-form-group
              label="Коэффициент"
              label-for="coefficient"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="PercentIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="coefficient"
                  v-model.number="experienceModelData.coefficient"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.coefficient"
                class="text-danger"
              >
                {{ validation.coefficient }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Изменить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>
      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'OrdersAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  model: {
    prop: 'isUpdateExperienceModelSidebarActive',
    event: 'update:is-update-experience-model-sidebar-active',
  },
  props: {
    isUpdateExperienceModelSidebarActive: {
      type: Boolean,
      required: true,
    },
    experienceModel: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.experienceModel) {
      this.setData(this.experienceModel)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankExperienceModelData = {
      id: null,
      name: '',
      coefficient: null,
    }
    const experienceModelData = ref(JSON.parse(JSON.stringify(blankExperienceModelData)))
    const resetOrderData = () => {
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      experienceModelData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    reset() {
      this.validation = {}
    },
    setData(data) {
      this.experienceModelData.id = data.id
      this.experienceModelData.name = data.name
      this.experienceModelData.coefficient = data.coefficient
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateExperienceModel', this.experienceModelData)
        this.$message(`Опыт ${data.name} успешно обновлен`, `Опыт ${data.name} успешно обновлен`, 'PercentIcon', 'success')
        this.validation = {}
        this.$emit('updateExperienceModel', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
