<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="TagIcon"
          :statistic="experienceModel.name"
          statistic-title="Наименование Опыта"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="PercentIcon"
          :statistic="experienceModel.coefficient"
          statistic-title="Коэффициент"
        />
      </b-col>
    </b-row>
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol,
} from 'bootstrap-vue'

export default {
  components: {
    BRow,
    BCol,
    StatisticCardVertical,
  },
  props: {
    experienceModel: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
}
</script>

<style>

</style>
