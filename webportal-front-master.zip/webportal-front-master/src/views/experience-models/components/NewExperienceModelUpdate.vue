<template>
  <b-modal
    id="modal-scrollable"
    ref="modal"
    scrollable
    centered
    title="Изменить опыт 🆙"
    cancel-title="Отменить"
    ok-title="Изменить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Наименование Опыта"
          rules="required"
        >
          <b-form-group
            label="Наименование Опыта"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="TagIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="experienceModelData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--          Product Name-->
        <validation-provider
          #default="validationContext"
          name="Коэффициент"
          rules="required"
        >
          <b-form-group
            label="Коэффициент"
            label-for="coefficient"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PercentIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="coefficient"
                v-model.number="experienceModelData.coefficient"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.coefficient"
              class="text-danger"
            >
              {{ validation.coefficient }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'UpdateTypeModal',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  props: {
    experienceModel: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.experienceModel) {
      this.setData(this.experienceModel)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankExperienceModelData = {
      id: null,
      name: '',
      coefficient: null,
    }
    const experienceModelData = ref(JSON.parse(JSON.stringify(blankExperienceModelData)))
    const resetOrderData = () => {
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      experienceModelData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    setData(data) {
      this.experienceModelData.id = data.id
      this.experienceModelData.name = data.name
      this.experienceModelData.coefficient = data.coefficient
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    reset() {
      this.setData(this.experienceModel)
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateExperienceModel', this.experienceModelData)
        this.$message(`Опыт ${data.name} успешно обновлен`, `Опыт ${data.name} успешно обновлен`, 'PercentIcon', 'success')
        this.validation = {}
        this.$emit('updateExperienceModel', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
