<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <b-card-actions
        ref="cardAction"
        title="Опыт работы 💯"
        action-refresh
        @refresh="refreshStop('cardAction')"
      >
        <b-row>
          <new-experience-model-add-new
            ref="addModal"
            @addExperienceModel="addExperienceModel"
          />
          <b-col
            md="1"
            sm="2"
            class="my-1"
          >
            <b-form-group
              class="mb-0"
            >
              <b-input-group-append>
                <b-button
                  class="border-primary border-darken-3 bg-primary bg-darken-3"
                  @click="showModal"
                >
                  <span class="text-nowrap">Добавить</span>
                </b-button>
              </b-input-group-append>
            </b-form-group>
          </b-col>
          <b-col
            md="3"
            sm="6"
            class="my-1"
          >
            <b-form-group
              label="На страницу"
              label-cols-sm="6"
              label-align-sm="right"
              label-size="sm"
              label-for="sortBySelect"
              class="mb-0"
            >
              <b-form-select
                id="perPageSelect"
                v-model="perPage"
                size="sm"
                :options="pageOptions"
                class="w-50"
                @change="handlePerPageChange"
              />
            </b-form-group>
          </b-col>
          <b-col
            md="4"
            sm="8"
            class="my-1"
          >
            <b-form-group
              label="Сортировать"
              label-cols-sm="3"
              label-align-sm="right"
              label-size="sm"
              label-for="sortBySelect"
              class="mb-0"
            >
              <b-input-group size="sm">
                <b-form-select
                  id="sortBySelect"
                  v-model="sortBy"
                  :options="sortOptions"
                  class="w-75"
                  @change="handleSortByChange"
                >
                  <template v-slot:first>
                    <option value="">
                      -- ничто --
                    </option>
                  </template>
                </b-form-select>
                <b-form-select
                  v-model="sortDirection"
                  size="sm"
                  :disabled="!sortBy"
                  class="w-25"
                  @change="handleSortDescChange"
                >
                  <option :value="'asc'">
                    По возрастанию
                  </option>
                  <option :value="'desc'">
                    По убыванию
                  </option>
                </b-form-select>
              </b-input-group>
            </b-form-group>
          </b-col>
          <b-col
            md="4"
            sm="8"
            class="my-1"
          >
            <b-form-group
              class="mb-0"
            >
              <b-input-group size="sm">
                <b-input-group-prepend is-text>
                  <feather-icon icon="SearchIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="filterInput"
                  v-model="filter"
                  type="search"
                  placeholder="Введите для поиска"
                  @input="handleFilterChange"
                />
              </b-input-group>
            </b-form-group>
          </b-col>

          <b-col cols="12">
            <b-table
              class="position-relative"
              striped
              hover
              responsive
              :items="items"
              :fields="fields"
              :current-page="currentPage"
              :per-page="0"
              @row-clicked="rowClick"
            >
              <template #cell(id)="data">
                <b-link
                  active
                  :to="'/experience-models/'+data.item.value"
                >
                  {{ data.item.id }}
                </b-link>
              </template>
            </b-table>
          </b-col>

          <b-col
            cols="12"
          >
            <h5>Всего: <b>{{ length }}</b></h5>
            <b-pagination
              v-model="currentPage"
              :total-rows="length"
              :per-page="perPage"
              align="center"
              size="sm"
              class="my-0"
              @change="handlePageChange"
            />
          </b-col>
        </b-row>
      </b-card-actions>
    </div>
  </div>
</template>

<script>
import {
  BTable, BLink, BInputGroupPrepend, BButton, BRow, BCol, BFormGroup, BFormSelect, BPagination, BInputGroup, BFormInput, BInputGroupAppend,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import NewExperienceModelAddNew from '@/views/experience-models/NewExperienceModelAddNew.vue'
import Loader from '@/layouts/components/Loader.vue'
// eslint-disable-next-line import/extensions
import BCardActions from '@core/components/b-card-actions/BCardActions'

export default {
  components: {
    BCardActions,
    BInputGroupPrepend,
    BTable,
    BRow,
    Loader,
    BButton,
    BCol,
    BFormGroup,
    BFormSelect,
    BPagination,
    BInputGroup,
    BFormInput,
    BInputGroupAppend,
    // eslint-disable-next-line vue/no-unused-components
    NewExperienceModelAddNew,
    BLink,
  },
  data() {
    return {
      items: [],
      loader: true,
      perPage: 10,
      pageOptions: [1, 5, 10, 20, 50],
      totalRows: 1,
      currentPage: 1,
      sortBy: 'id',
      sortDesc: true,
      sortDirection: 'desc',
      filter: '',
      length: 0,
      infoModal: {
        id: 'info-modal',
        title: '',
        content: '',
      },
      fields: [
        {
          key: 'id', label: 'Id',
        },
        {
          key: 'name', label: 'Наименование опыта',
        },
        {
          key: 'coefficient', label: 'Коэффициент',
        },
      ],
    }
  },
  computed: {
    sortOptions() {
      // Create an options list from our fields
      return this.fields
        .map(f => ({ text: f.label, value: f.key }))
    },
  },
  async mounted() {
    this.loader = true
    await this.fetchAllData()
    this.loader = false
  },
  methods: {
    info(item, index, button) {
      this.infoModal.title = `Row index: ${index}`
      this.infoModal.content = JSON.stringify(item, null, 2)
      console.log(item)
      this.$root.$emit('bv::show::modal', this.infoModal.id, button)
    },
    resetInfoModal() {
      this.infoModal.title = ''
      this.infoModal.content = ''
    },
    async fetchAllData() {
      const response = await this.$store.dispatch('fetchAllExperienceModelsPagination', this.getPaginationData())
      this.items = response.data
      this.length = response.totalItems
      this.currentPage = response.currentPage
    },
    getPaginationData() {
      const data = {}
      data.sortBy = this.sortBy
      data.currentPage = this.currentPage
      data.sortDirection = this.sortDirection
      data.perPage = this.perPage
      data.filter = this.filter
      return data
    },
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length
      this.length = filteredItems.length
      this.currentPage = 1
    },
    addExperienceModel(data) {
      if (data) {
        this.loadData()
      }
    },
    async loadData() {
      this.$refs.cardAction.showLoading = true
      await this.fetchAllData()
      this.$refs.cardAction.showLoading = false
    },
    rowClick(record) {
      this.$router.push(`/experience-models/${record.id}`)
    },
    async refreshStop(cardName) {
      await this.fetchAllData()
      this.$refs[cardName].showLoading = false
    },
    async handlePageChange(value) {
      this.currentPage = value
      await this.loadData()
    },
    async handlePerPageChange(value) {
      this.perPage = value
      await this.loadData()
    },
    async handleSortByChange(value) {
      this.sortBy = value
      await this.loadData()
    },
    async handleSortDescChange(value) {
      this.sortDirection = value
      await this.loadData()
    },
    async handleFilterChange(value) {
      this.filter = value
      await this.loadData()
    },
    showModal() {
      this.$refs.addModal.show()
    },
  },
}
</script>

<style scoped>

</style>
