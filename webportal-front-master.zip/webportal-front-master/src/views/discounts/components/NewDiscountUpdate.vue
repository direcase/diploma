<template>
  <b-modal
    id="modal-scrollable"
    ref="modal"
    scrollable
    centered
    title="Изменить скидку 💯"
    cancel-title="Отменить"
    ok-title="Изменить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Наименование Скидки"
          rules="required"
        >
          <b-form-group
            label="Наименование Скидки"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="TagIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="discountData.discountName"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.discountName"
              class="text-danger"
            >
              {{ validation.discountName }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--          Product Name-->
        <validation-provider
          #default="validationContext"
          name="Скидка"
          rules="required"
        >
          <b-form-group
            label="Скидка"
            label-for="discount"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PercentIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="discount"
                v-model.number="discountData.percentage"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.percentage"
              class="text-danger"
            >
              {{ validation.percentage }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form></validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'UpdateTypeModal',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  props: {
    discount: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.discount) {
      this.setData(this.discount)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankDiscountData = {
      id: null,
      discountName: '',
      percentage: null,
    }
    const discountData = ref(JSON.parse(JSON.stringify(blankDiscountData)))
    const resetOrderData = () => {
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      discountData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    setData(data) {
      this.discountData.id = data.id
      this.discountData.discountName = data.discountName
      this.discountData.percentage = data.percentage
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    reset() {
      this.setData(this.discount)
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateDiscount', this.discountData)
        this.$message(`Скидка ${data.discountName} успешно обновлен`, `Скидка ${data.discountName} успешно обновлен`, 'PercentIcon', 'success')
        this.validation = {}
        this.$emit('updateDiscount', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
