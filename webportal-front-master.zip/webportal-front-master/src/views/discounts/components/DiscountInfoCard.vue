<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="TagIcon"
          :statistic="discount.discountName"
          statistic-title="Наименование Скидки"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="PercentIcon"
          :statistic="discount.percentage"
          statistic-title="Скидка"
        />
      </b-col>
    </b-row>
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol,
} from 'bootstrap-vue'

export default {
  components: {
    BRow,
    BCol,
    StatisticCardVertical,
  },
  props: {
    discount: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  methods: {
  },
}
</script>

<style>

</style>
