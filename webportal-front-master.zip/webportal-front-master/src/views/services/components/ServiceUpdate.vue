<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isUpdateServiceSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="reset"
    @change="(val) => $emit('update:is-update-service-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
        <h5 class="mb-0">
          Изменить услугу 📦
        </h5>

        <feather-icon
          class="ml-1 cursor-pointer"
          icon="XIcon"
          size="16"
          @click="hide"
        />

      </div>

      <!-- BODY -->
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandler"
          @reset.prevent="reset"
        >
          <!-- Phone Number -->
          <validation-provider
            #default="validationContext"
            name="Наименование Услуги"
            rules="required"
          >
            <b-form-group
              label="Наименование Услуги"
              label-for="name"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="SettingsIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="name"
                  v-model="serviceData.name"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.name"
                class="text-danger"
              >
                {{ validation.name }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!--          Product Name-->
          <validation-provider
            #default="validationContext"
            name="Описание Услуги"
            rules="required"
          >
            <b-form-group
              label="Описание Услуги"
              label-for="description"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="InfoIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="description"
                  v-model="serviceData.description"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.description"
                class="text-danger"
              >
                {{ validation.description }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <validation-provider
            #default="validationContext"
            name="Цена"
            rules="required"
          >
            <b-form-group
              label="Цена"
              label-for="price"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="DollarSignIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="price"
                  v-model.number="serviceData.price"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.price"
                class="text-danger"
              >
                {{ validation.price }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!--Percentage-->
          <validation-provider
            v-if="hasAdminPermission"
            #default="validationContext"
            name="Процент"
            rules="required"
          >
            <b-form-group
              label="Процент"
              label-for="percentage"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="PercentIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="percentage"
                  v-model.number="serviceData.percentage"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.percentage"
                class="text-danger"
              >
                {{ validation.percentage }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Изменить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>
      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'OrdersAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  model: {
    prop: 'isUpdateServiceSidebarActive',
    event: 'update:is-update-service-sidebar-active',
  },
  props: {
    isUpdateServiceSidebarActive: {
      type: Boolean,
      required: true,
    },
    service: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      return this.user.roles.includes('ADMIN')
    },
  },
  mounted() {
    if (this.service) {
      this.setData(this.service)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankServiceData = {
      id: null,
      name: '',
      description: '',
      percentage: null,
      price: null,
    }
    const serviceData = ref(JSON.parse(JSON.stringify(blankServiceData)))
    const resetOrderData = () => {
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      serviceData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    reset() {
      this.validation = {}
    },
    setData(data) {
      this.serviceData.id = data.id
      this.serviceData.name = data.name
      this.serviceData.description = data.description
      this.serviceData.price = data.price
      this.serviceData.percentage = data.percentage
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateService', this.serviceData)
        this.$message(`Услуга ${data.name} успешно обновлен`, `Услуга ${data.name} ${data.description} успешно обновлен`, 'SettingsIcon', 'success')
        this.$emit('updateService', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
