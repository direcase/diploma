<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="DollarSignIcon"
          :statistic="service.price+' ₸'"
          statistic-title="Цена за 1 шт."
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="ShoppingBagIcon"
          :statistic="sold ? sold+' шт.': 'Еще не продано'"
          statistic-title="Продано"
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="primary"
          icon="DivideIcon"
          :statistic="monthlySales.avg+' шт.'"
          statistic-title="Продаётся в среднем за месяц"
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="danger"
          icon="PercentIcon"
          :statistic="service.percentage+' %'"
          statistic-title="Процент"
        />
      </b-col>
    </b-row>
    <product-month-sales-chart
      v-if="hasAdminPermission"
      :service="service"
      :monthly-sales="monthlySales"
    />
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol,
} from 'bootstrap-vue'
import ProductMonthSalesChart from '@/views/products/components/ProductMonthSalesChart.vue'

export default {
  components: {
    ProductMonthSalesChart,
    BRow,
    BCol,
    StatisticCardVertical,
  },
  props: {
    service: {
      type: Object,
      required: true,
    },
    sold: {
      type: Number,
      required: true,
    },
    monthlySales: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  methods: {
  },
}
</script>

<style>

</style>
