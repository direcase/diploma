<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="service === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одной услуги с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/services'"
          >
            Список услуг
          </b-link>
          для других Услуг.
        </div>
      </b-alert>

      <template v-if="service">
        <new-service-update
          ref="updateModal"
          :service="service"
          @updateService="updateService"
        />
        <hr>
        <h3>{{ service.name }} || {{ service.description }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3"
            @click="showUpdateModal"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteService"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="success"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <service-info-card
          :service="service"
          :sold="sold"
          :monthly-sales="monthlySales"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import NewServiceUpdate from '@/views/services/components/NewServiceUpdate.vue'
import ServiceInfoCard from '@/views/services/components/ServiceInfoCard.vue'

export default {
  components: {
    NewServiceUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    ServiceInfoCard,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    product: {},
    service: {},
    monthlySales: {},
    sold: 0,
    loader: true,
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  async mounted() {
    try {
      this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    updateService(data) {
      this.service = data
    },
    deleteService() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteService', this.service.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Услуга удалена с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/services')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    async fetchAllData() {
      try {
        this.loader = true
        this.service = await this.$store.dispatch('fetchServiceById', this.$route.params.id)
        if (this.hasAdminPermission) {
          this.monthlySales = await this.$store.dispatch('getMonthlySalesService', this.$route.params.id)
          this.sold = await this.$store.dispatch('getSoldServiceCount', this.$route.params.id)
        }
        this.loader = false
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.code === 'service/not-found') {
          this.service = undefined
          this.loader = false
        }
      }
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
