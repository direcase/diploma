<template>
  <b-modal
    id="modal-scrollable"
    ref="modal"
    scrollable
    centered
    title="Добавить новую услугу 👨‍🔧"
    cancel-title="Отменить"
    ok-title="Добавить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Наименование Услуги"
          rules="required"
        >
          <b-form-group
            label="Наименование Услуги"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="SettingsIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="serviceData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--          Product Name-->
        <validation-provider
          #default="validationContext"
          name="Описание Услуги"
          rules="required"
        >
          <b-form-group
            label="Описание Услуги"
            label-for="description"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="InfoIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="description"
                v-model="serviceData.description"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.description"
              class="text-danger"
            >
              {{ validation.description }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <validation-provider
          #default="validationContext"
          name="Цена"
          rules="required"
        >
          <b-form-group
            label="Цена"
            label-for="price"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="DollarSignIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="price"
                v-model.number="serviceData.price"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.price"
              class="text-danger"
            >
              {{ validation.price }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--Percentage-->
        <validation-provider
          v-if="hasAdminPermission"
          #default="validationContext"
          name="Процент"
          rules="required"
        >
          <b-form-group
            label="Процент"
            label-for="percentage"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PercentIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="percentage"
                v-model.number="serviceData.percentage"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.percentage"
              class="text-danger"
            >
              {{ validation.percentage }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'DiscountAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      return this.user.roles.includes('ADMIN')
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankServiceData = {
      name: '',
      description: '',
      percentage: 1,
      price: 0,
    }
    const serviceData = ref(JSON.parse(JSON.stringify(blankServiceData)))
    const resetOrderData = () => {
      serviceData.value = JSON.parse(JSON.stringify(blankServiceData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      serviceData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs
        .modal.show()
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    resetServiceData() {
      this.serviceData.name = ''
      this.serviceData.description = ''
      this.serviceData.percentage = 1
      this.serviceData.price = 0
    },
    reset() {
      this.resetServiceData()
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('addService', this.serviceData)
        this.$message('Услуга успешно добавлен в базу', `Услуга ${data.name} успешно добавлен в базу`, 'SettingsIcon', 'success')
        this.validation = {}
        this.$emit('addService', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
