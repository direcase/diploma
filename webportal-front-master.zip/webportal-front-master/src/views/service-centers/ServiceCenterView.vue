<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="serviceCenter === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного сервисного центра с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/service-centers'"
          >
            Список сервисных центров
          </b-link>
          для других Сервисных Центров.
        </div>
      </b-alert>

      <template v-if="serviceCenter">
        <service-center-update
          :is-update-service-center-sidebar-active.sync="isUpdateServiceCenterSidebarActive"
          :service-center="serviceCenter"
          @updateServiceCenter="updateServiceCenter"
        />
        <hr>
        <h3>{{ serviceCenter.name }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="warning"
            @click="isUpdateServiceCenterSidebarActive = true"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteServiceCenter"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="primary"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <service-center-info-card
          :service-center="serviceCenter"
        />
        <service-center-users
          ref="users"
          :service-center="serviceCenter"
        />
        <service-center-experience-models
          :service-center="serviceCenter"
          @addExperienceModel="addExperienceModel"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import ServiceCenterUpdate from '@/views/service-centers/components/ServiceCenterUpdate.vue'
import ServiceCenterInfoCard from '@/views/service-centers/components/ServiceCenterInfoCard.vue'
import ServiceCenterUsers from '@/views/service-centers/components/ServiceCenterUsers.vue'
import ServiceCenterExperienceModels from '@/views/service-centers/components/ServiceCenterExperienceModels.vue'

export default {
  components: {
    // eslint-disable-next-line vue/no-unused-components
    ServiceCenterUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    ServiceCenterInfoCard,
    ServiceCenterUsers,
    ServiceCenterExperienceModels,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    isUpdateServiceCenterSidebarActive: false,
    serviceCenter: {},
    loader: true,
  }),
  async mounted() {
    try {
      await this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    deleteServiceCenter() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            // eslint-disable-next-line no-unused-vars
            const response = await this.$store.dispatch('deleteServiceCenterById', this.serviceCenter.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Сервисный центр удалена с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/service-centers')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    async addExperienceModel(data) {
      if (data) {
        await this.$refs.users.fetchExperienceModels()
      }
    },
    async fetchAllData() {
      this.loader = true
      this.serviceCenter = await this.$store.dispatch('fetchServiceCenterById', this.$route.params.id)
      this.loader = false
    },
    updateServiceCenter(data) {
      this.serviceCenter = data
    },
  },
}
</script>

<style>

</style>
