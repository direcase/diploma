<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="HomeIcon"
          :statistic="serviceCenter.name"
          statistic-title="Название Сервисного Центра"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="MapPinIcon"
          :statistic="serviceCenter.address"
          statistic-title="Адрес Сервисного центра"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <b-link :href="'tel:'+serviceCenter.phoneNumber">
          <statistic-card-vertical
            color="primary"
            icon="PhoneIcon"
            :statistic="serviceCenter.phoneNumber"
            statistic-title="Телефон Сервисного Центра"
          />
        </b-link>
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="danger"
          icon="MailIcon"
          :statistic="serviceCenter.email"
          statistic-title="Email"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="KeyIcon"
          :statistic="serviceCenter.isEnabled ? 'Да':'Нет'"
          statistic-title="Активен"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="MessageSquareIcon"
          :statistic="serviceCenter.comment"
          statistic-title="Комментарии"
        />
      </b-col>
    </b-row>
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol, BLink,
} from 'bootstrap-vue'

export default {
  components: {
    BRow,
    BCol,
    BLink,
    StatisticCardVertical,
  },
  props: {
    serviceCenter: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  computed: {
  },
  methods: {
  },
}
</script>

<style>

</style>
