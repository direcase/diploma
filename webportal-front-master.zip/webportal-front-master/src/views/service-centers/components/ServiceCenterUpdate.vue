<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isUpdateServiceCenterSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="reset"
    @change="(val) => $emit('update:is-update-service-center-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
        <h5 class="mb-0">
          Изменить Сервисный Центр 🏪
        </h5>

        <feather-icon
          class="ml-1 cursor-pointer"
          icon="XIcon"
          size="16"
          @click="hide"
        />

      </div>

      <!-- BODY -->
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandler"
          @reset.prevent="reset"
        >
          <!-- Phone Number -->
          <validation-provider
            #default="validationContext"
            name="Название Сервисного Центра"
            rules="required"
          >
            <b-form-group
              label="Название Сервисного Центра"
              label-for="name"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="TagIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="name"
                  v-model="serviceCenterData.name"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.name"
                class="text-danger"
              >
                {{ validation.name }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!--          Product Name-->
          <validation-provider
            #default="validationContext"
            name="Адрес Сервисного Центра"
            rules="required"
          >
            <b-form-group
              label="Адрес Сервисного Центра"
              label-for="address"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="MapPinIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="address"
                  v-model="serviceCenterData.address"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.address"
                class="text-danger"
              >
                {{ validation.address }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <validation-provider
            #default="validationContext"
            name="Телефон Сервисного Центра"
            rules="required"
          >
            <b-form-group
              label="Телефон Сервисного Центра"
              label-for="phone"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="PhoneIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="phone"
                  v-model="serviceCenterData.phoneNumber"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.phoneNumber"
                class="text-danger"
              >
                {{ validation.phoneNumber }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <validation-provider
            #default="validationContext"
            name="Email"
            rules="required"
          >
            <b-form-group
              label="Email"
              label-for="email"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="MailIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="email"
                  v-model="serviceCenterData.email"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.email"
                class="text-danger"
              >
                {{ validation.email }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <validation-provider
            #default="validationContext"
            name="Комментарий"
            rules="required"
          >
            <b-form-group
              label="Комментарий"
              label-for="comment"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="MessageSquareIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="comment"
                  v-model="serviceCenterData.comment"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.comment"
                class="text-danger"
              >
                {{ validation.comment }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <validation-provider
            #default="validationContext"
            name="Активен"
            rules="required"
          >
            <b-form-group
              label="Активен"
              label-for="active"
            >
              <b-input-group>
                <b-form-checkbox
                  id="active"
                  v-model="serviceCenterData.isEnabled"
                  checked="true"
                  class="custom-control-success"
                  name="check-button"
                  switch
                />
              </b-input-group>
              <p
                v-if="validation.isEnabled"
                class="text-danger"
              >
                {{ validation.isEnabled }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Изменить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>
      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BFormCheckbox, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import { togglePasswordVisibility } from '@core/mixins/ui/forms'

export default {
  name: 'OrdersAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    BFormCheckbox,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  mixins: [togglePasswordVisibility],
  model: {
    prop: 'isUpdateServiceCenterSidebarActive',
    event: 'update:is-update-service-center-sidebar-active',
  },
  props: {
    isUpdateServiceCenterSidebarActive: {
      type: Boolean,
      required: true,
    },
    serviceCenter: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.serviceCenter) {
      this.setData(this.serviceCenter)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankServiceCenterData = {
      name: '',
      address: '',
      phoneNumber: '',
      isEnabled: false,
      comment: '',
      email: '',
    }
    const serviceCenterData = ref(JSON.parse(JSON.stringify(blankServiceCenterData)))
    const resetOrderData = () => {
      serviceCenterData.value = JSON.parse(JSON.stringify(blankServiceCenterData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      serviceCenterData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    reset() {
      this.validation = {}
    },
    setData(data) {
      this.serviceCenterData.id = data.id
      this.serviceCenterData.name = data.name
      this.serviceCenterData.address = data.address
      this.serviceCenterData.phoneNumber = data.phoneNumber
      this.serviceCenterData.isEnabled = data.isEnabled
      this.serviceCenterData.comment = data.comment
      this.serviceCenterData.email = data.email
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateServiceCenter', this.serviceCenterData)
        this.reset()
        this.$message(`Сервисный центр ${data.name} успешно обновлен`, `${data.name} успешно обновлен`, 'DatabaseIcon', 'success')
        this.$emit('updateServiceCenter', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
