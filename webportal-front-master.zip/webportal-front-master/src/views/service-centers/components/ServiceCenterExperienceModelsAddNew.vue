<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isAddNewExperienceModelsSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="reset"
    @change="(val) => $emit('update:is-add-new-experience-models-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
        <h5 class="mb-0">
          Добавить новый Сервисный Центр 🏪
        </h5>

        <feather-icon
          class="ml-1 cursor-pointer"
          icon="XIcon"
          size="16"
          @click="hide"
        />

      </div>

      <!-- BODY -->
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandler"
          @reset.prevent="reset"
        >
          <!-- Phone Number -->
          <validation-provider
            #default="validationContext"
            name="Название Сервисного Центра"
            rules="required"
          >
            <b-form-group
              label="Название Опыта"
              label-for="experienceModelName"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="TagIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="experienceModelName"
                  v-model="experienceModelData.name"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.name"
                class="text-danger"
              >
                {{ validation.name }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <validation-provider
            #default="validationContext"
            name="Коэффициент"
            rules="required"
          >
            <b-form-group
              label="Коэффициент"
              label-for="experienceModelCoefficient"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="PercentIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="experienceModelCoefficient"
                  v-model.number="experienceModelData.coefficient"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.coefficient"
                class="text-danger"
              >
                {{ validation.coefficient }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Добавить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>
      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import { togglePasswordVisibility } from '@core/mixins/ui/forms'

export default {
  name: 'OrdersAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  mixins: [togglePasswordVisibility],
  model: {
    prop: 'isAddNewExperienceModelsSidebarActive',
    event: 'update:is-add-new-experience-models-sidebar-active',
  },
  props: {
    isAddNewExperienceModelsSidebarActive: {
      type: Boolean,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  computed: {
    passwordToggleIcon() {
      return this.passwordFieldType === 'password' ? 'EyeIcon' : 'EyeOffIcon'
    },
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      return this.user.roles.includes('ADMIN')
    },
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankExperienceModelCenterData = {
      name: '',
      coefficient: 0,
    }
    const experienceModelData = ref(JSON.parse(JSON.stringify(blankExperienceModelCenterData)))
    const resetOrderData = () => {
      experienceModelData.value = JSON.parse(JSON.stringify(blankExperienceModelCenterData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      experienceModelData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    reset() {
      this.resetForm()
      this.validation = {}
    },
    async submitHandler() {
      try {
        this.experienceModelData.serviceCenterId = this.$route.params.id
        const data = await this.$store.dispatch('addServiceCenterExperienceModel', this.experienceModelData)
        this.$message(`Опыт ${data.name} успешно добавлен в базу`, `${data.name} успешно добавлен в базу`, 'DatabaseIcon', 'success')
        this.validation = {}
        this.$emit('addExperienceModel', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
