<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="product === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного товара с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/products'"
          >
            Список товаров
          </b-link>
          для других Товаров.
        </div>
      </b-alert>

      <template v-if="product">
        <new-product-update
          ref="updateModal"
          :product="product"
          :providers="providers"
          @updateProduct="updateProduct"
          @addStorage="addStorage"
        />
        <hr>
        <h3>{{ product.name }} || {{ product.description }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3"
            @click="showUpdateModal"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteProduct"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="success"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <product-info-card
          :product="product"
          :sold="sold"
          :monthly-sales="monthlySales"
          :last-purchase-price="lastPurchasePrice"
        />
        <product-incoming-history-table
          v-if="hasAdminPermission"
          ref="incomingHistory"
          :product="product"
          @deleteIncomingHistory="fetchAllData"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import ProductInfoCard from '@/views/products/components/ProductInfoCard.vue'
import Ripple from 'vue-ripple-directive'
import NewProductUpdate from '@/views/products/components/NewProductUpdate.vue'
import ProductIncomingHistoryTable from '@/views/products/components/ProductIncomingHistoryTable.vue'

export default {
  components: {
    NewProductUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    ProductInfoCard,
    ProductIncomingHistoryTable,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    isUpdateProductSidebarActive: false,
    product: {},
    providers: [],
    monthlySales: {},
    sold: 0,
    lastPurchasePrice: 0,
    loader: true,
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  async mounted() {
    try {
      this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    updateProduct(data) {
      if (data) {
        this.product = data
      }
    },
    deleteProduct() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteProduct', this.product.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Товар удален.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/products')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    async fetchAllData() {
      try {
        this.loader = true
        this.product = await this.$store.dispatch('fetchProductById', this.$route.params.id)
        if (this.hasAdminPermission) {
          this.monthlySales = await this.$store.dispatch('getMonthlySalesProduct', this.$route.params.id)
          this.sold = await this.$store.dispatch('getSoldProductCount', this.$route.params.id)
          this.lastPurchasePrice = await this.$store.dispatch('fetchLastPurchasePrice', this.$route.params.id)
        }
        this.providers = await this.$store.dispatch('fetchAllProviders')
        this.loader = false
      } catch (e) {
        if (e.response.data.code === 'product/not-found') {
          this.product = undefined
          this.loader = false
        }
      }
    },
    addStorage(data) {
      console.log('I call him')
      // eslint-disable-next-line operator-assignment
      this.product.storage = this.product.storage + data.quantity
      this.lastPurchasePrice = data.incomePrice
      this.$refs.incomingHistory.loadData()
    },
    async deleteIncomingHistory(historyId) {
      try {
        const data = {}
        data.historyId = historyId
        data.productId = this.product.id
        await this.$store.dispatch('deleteIncomingHistory', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
      }
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
