<template>
  <b-modal
    id="modal-tall"
    ref="modal"
    centered
    title="Добавить новый товар 📦"
    :hide-footer="true"
    cancel-title="Отменить"
    ok-title="Добавить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >
    <!-- BODY -->
    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <div class="d-flex justify-content-center align-items-center">
          <h5 class="mb-0">
            Добавить товар
          </h5>
        </div>
        <hr>
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Наименование Товара"
          rules="required"
        >
          <b-form-group
            label="Наименование Товара"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="BoxIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="productData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--          Product Name-->
        <validation-provider
          #default="validationContext"
          name="Описание товара"
          rules="required"
        >
          <b-form-group
            label="Описание товара"
            label-for="description"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="InfoIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="description"
                v-model="productData.description"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.description"
              class="text-danger"
            >
              {{ validation.description }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <validation-provider
          #default="validationContext"
          name="Цена"
          rules="required"
        >
          <b-form-group
            label="Цена"
            label-for="price"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="DollarSignIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="price"
                v-model.number="productData.price"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.price"
              class="text-danger"
            >
              {{ validation.price }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!-- Form Actions -->
        <div class="d-flex mt-2">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3 mr-2"
            type="submit"
          >
            Добавить
          </b-button>
          <b-button
            v-ripple.400="'rgba(186, 191, 199, 0.15)'"
            type="button"
            variant="outline-secondary"
            @click="hide"
          >
            Отменить
          </b-button>
        </div>

      </b-form>

      <b-form
        class="p-2"
        @submit.prevent="submitHandlerAddProductStorage"
        @reset.prevent="reset"
      >
        <div class="d-flex justify-content-center align-items-center">
          <h5 class="mb-0">
            Добавить в склад
          </h5>
        </div>
        <hr>
        <!--Product-->
        <validation-provider
          #default="validationContext"
          name="Товар"
          rules="required"
        >
          <b-form-group
            label="Товар"
            label-for="product"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="addStorageData.productId"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="products"
              :reduce="val => val.value"
              :clearable="false"
              input-id="product"
            >
              <template
                slot="option"
                slot-scope="option"
              >
                {{ option.name }} || {{ option.storage }}
              </template>
              <template
                slot="selected-option"
                slot-scope="option"
              >
                {{ option.name }}
              </template>
            </v-select>
            <p
              v-if="validation.productId"
              class="text-danger"
            >
              {{ validation.productId }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--Provider-->
        <validation-provider
          #default="validationContext"
          name="Поставщик"
          rules="required"
        >
          <b-form-group
            label="Поставщик"
            label-for="provider"
            :state="getValidationState(validationContext)"
          >
            <v-select
              v-model="addStorageData.providerId"
              :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
              :options="providers"
              :reduce="val => val.value"
              :clearable="false"
              input-id="provider"
            >
              <template
                slot="option"
                slot-scope="option"
              >
                {{ option.label }} || {{ option.address }} || {{ option.phoneNumber }}
              </template>
              <template
                slot="selected-option"
                slot-scope="option"
              >
                {{ option.label }}
              </template>
            </v-select>
            <p
              v-if="validation.providerId"
              class="text-danger"
            >
              {{ validation.providerId }}
            </p>
            <b-form-invalid-feedback :state="getValidationState(validationContext)">
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--Price for Count-->
        <validation-provider
          #default="validationContext"
          name="Цена за единицу"
          rules="required"
        >
          <b-form-group
            label="Цена за единицу"
            label-for="priceForCount"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="BoxIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="priceForCount"
                v-model.number="addStorageData.price"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.price"
              class="text-danger"
            >
              {{ validation.price }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!--Quantity-->
        <validation-provider
          #default="validationContext"
          name="Количество"
          rules="required"
        >
          <b-form-group
            label="Количество"
            label-for="quantity"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="BoxIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="quantity"
                v-model.number="addStorageData.quantity"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.quantity"
              class="text-danger"
            >
              {{ validation.quantity }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>

        <!-- Form Actions -->
        <div class="d-flex mt-2">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3 mr-2"
            type="submit"
          >
            Добавить
          </b-button>
          <b-button
            v-ripple.400="'rgba(186, 191, 199, 0.15)'"
            type="button"
            variant="outline-secondary"
            @click="hide"
          >
            Отменить
          </b-button>
        </div>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BButton, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import vSelect from 'vue-select'

export default {
  name: 'ProductAdd',
  components: {
    BInputGroup,
    BButton,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
    vSelect,
  },
  directives: {
    Ripple,
  },
  props: {
    providers: {
      type: Array,
      required: true,
    },
    products: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankProductData = {
      name: '',
      description: '',
      price: 0,
    }

    const blankAddStorageData = {
      providerId: null,
      productId: null,
      price: 0,
      quantity: 0,
    }
    const addStorageData = ref(JSON.parse(JSON.stringify(blankAddStorageData)))
    const productData = ref(JSON.parse(JSON.stringify(blankProductData)))
    const resetOrderData = () => {
      productData.value = JSON.parse(JSON.stringify(blankProductData))
      addStorageData.value = JSON.parse(JSON.stringify(blankAddStorageData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      addStorageData,
      productData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    hide() {
      this.$refs.modal.hide()
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    resetProductData() {
      this.productData.name = ''
      this.productData.description = ''
      this.productData.price = 0
    },
    resetAddStorageData() {
      this.addStorageData.providerId = null
      this.addStorageData.productId = null
      this.addStorageData.price = 0
      this.addStorageData.quantity = 0
    },
    reset() {
      this.resetProductData()
      this.resetAddStorageData()
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('addProduct', this.productData)
        this.$message(`${data.name} успешно добавлен в склад`, `${data.name} ${data.description} успешно добавлен`, 'BoxIcon', 'success')
        this.validation = {}
        this.$emit('addProduct', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
    async submitHandlerAddProductStorage() {
      try {
        const data = await this.$store.dispatch('addProductToStorage', this.addStorageData)
        this.$message('Товар успешно добавлен в склад', 'Товар успешно добавлен', 'BoxIcon', 'success')
        this.validation = {}

        this.$emit('addStorage', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
