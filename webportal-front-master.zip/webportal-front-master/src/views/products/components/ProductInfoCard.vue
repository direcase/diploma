<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          icon="ArchiveIcon"
          :statistic="product.storage+' шт.'"
          statistic-title="На складе"
          color="info"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="DollarSignIcon"
          :statistic="product.price+' ₸'"
          statistic-title="Цена за 1 шт."
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="ShoppingBagIcon"
          :statistic="sold ? sold+' шт.': 'Еще не продано'"
          statistic-title="Продано"
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="primary"
          icon="DivideIcon"
          :statistic="monthlySales.avg+' шт.'"
          statistic-title="Продаётся в среднем за месяц"
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="BoxIcon"
          :statistic="lastPurchasePrice+' ₸'"
          statistic-title="Последняя цена закупки"
        />
      </b-col>
      <b-col
        v-if="hasAdminPermission"
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          hide-chart
          color="danger"
          icon="DollarSignIcon"
          :statistic="(product.price-lastPurchasePrice)+' ₸'"
          statistic-title="Доход за продажу одного товара"
        />
      </b-col>
    </b-row>
    <product-month-sales-chart
      v-if="hasAdminPermission"
      :product="product"
      :monthly-sales="monthlySales"
    />
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'
import ProductMonthSalesChart from '@/views/products/components/ProductMonthSalesChart.vue'
import {
  BRow, BCol,
} from 'bootstrap-vue'

export default {
  components: {
    BRow, BCol, StatisticCardVertical, ProductMonthSalesChart,
  },
  props: {
    product: {
      type: Object,
      required: true,
    },
    sold: {
      type: Number,
      required: true,
    },
    lastPurchasePrice: {
      type: Number,
      required: true,
    },
    monthlySales: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  methods: {
  },
}
</script>

<style>

</style>
