<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isUpdateProductSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="reset"
    @change="(val) => $emit('update:is-update-product-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form Product -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandlerProductUpdate"
          @reset.prevent="reset"
        >
          <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
            <h5 class="mb-0">
              Изменить Товар
            </h5>

            <feather-icon
              class="ml-1 cursor-pointer"
              icon="XIcon"
              size="16"
              @click="hide"
            />

          </div>
          <!--          ProductName-->
          <validation-provider
            #default="validationContext"
            name="Наименование товара"
            rules="required"
          >
            <b-form-group
              label="Наименование товара"
              label-for="name"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="BoxIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="name"
                  v-model="productData.name"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.name"
                class="text-danger"
              >
                {{ validation.name }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!--          Product Description-->
          <validation-provider
            #default="validationContext"
            name="Описание товара"
            rules="required"
          >
            <b-form-group
              label="Описание товара"
              label-for="description"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="BoxIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="description"
                  v-model="productData.description"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.description"
                class="text-danger"
              >
                {{ validation.comment }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!--          Product Price-->
          <validation-provider
            #default="validationContext"
            name="Цена товара"
            rules="required"
          >
            <b-form-group
              label="Цена товара"
              label-for="price"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="BoxIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="price"
                  v-model.number="productData.price"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.price"
                class="text-danger"
              >
                {{ validation.price }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Изменить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>

        <b-form
          class="p-2"
          @submit.prevent="submitHandlerAddProductStorage"
          @reset.prevent="resetForm"
        >
          <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
            <h5 class="mb-0">
              Добавить в склад
            </h5>

            <feather-icon
              class="ml-1 cursor-pointer"
              icon="XIcon"
              size="16"
              @click="hide"
            />

          </div>
          <!--Provider-->
          <validation-provider
            #default="validationContext"
            name="Поставщик"
            rules="required"
          >
            <b-form-group
              label="Поставщик"
              label-for="provider"
              :state="getValidationState(validationContext)"
            >
              <v-select
                v-model="addStorageData.providerId"
                :dir="$store.state.appConfig.isRTL ? 'rtl' : 'ltr'"
                :options="providers"
                :reduce="val => val.value"
                :clearable="false"
                input-id="provider"
              >
                <template
                  slot="option"
                  slot-scope="option"
                >
                  {{ option.label }} || {{ option.address }} || {{ option.phoneNumber }}
                </template>
                <template
                  slot="selected-option"
                  slot-scope="option"
                >
                  {{ option.label }}
                </template>
              </v-select>
              <b-form-invalid-feedback :state="getValidationState(validationContext)">
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <p
            v-if="validation.providerId"
            class="text-danger"
          >
            {{ validation.providerId }}
          </p>
          <!--Price for Count-->
          <validation-provider
            #default="validationContext"
            name="Цена за единицу"
            rules="required"
          >
            <b-form-group
              label="Цена за единицу"
              label-for="priceForCount"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="BoxIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="priceForCount"
                  v-model.number="addStorageData.price"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.price"
                class="text-danger"
              >
                {{ validation.price }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!--Quantity-->
          <validation-provider
            #default="validationContext"
            name="Количество"
            rules="required"
          >
            <b-form-group
              label="Количество"
              label-for="quantity"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="BoxIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="quantity"
                  v-model.number="addStorageData.quantity"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.quantity"
                class="text-danger"
              >
                {{ validation.quantity }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Добавить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>

      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'
import vSelect from 'vue-select'

export default {
  name: 'ItemsAdd',
  components: {
    vSelect,
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  model: {
    prop: 'isAddNewItemSidebarActive',
    event: 'update:is-add-new-item-sidebar-active',
  },
  props: {
    isUpdateProductSidebarActive: {
      type: Boolean,
      required: true,
    },
    product: {
      type: Object,
      required: true,
    },
    providers: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.product) {
      this.setData(this.product)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankProductData = {
      id: null,
      name: '',
      description: '',
      price: 0,
    }

    const blankAddStorageData = {
      providerId: 0,
      price: 0,
      quantity: 0,
    }
    const addStorageData = ref(JSON.parse(JSON.stringify(blankAddStorageData)))
    const productData = ref(JSON.parse(JSON.stringify(blankProductData)))
    const resetItemData = () => {
      addStorageData.value = JSON.parse(JSON.stringify(blankAddStorageData))
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetItemData)

    return {
      addStorageData,
      productData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    reset() {
      this.resetForm()
      this.validation = {}
    },
    setData(data) {
      this.productData.id = data.id
      this.productData.name = data.name
      this.productData.description = data.description
      this.productData.price = data.price
      this.addStorageData.productId = data.id
    },
    async submitHandlerProductUpdate() {
      try {
        const data = await this.$store.dispatch('updateProduct', this.productData)
        console.log(this.productData)
        this.$message('Товар успешно обновлен', `Товар № ${data.id} успешно обновлен`, 'CheckSquareIcon', 'success')
        this.$emit('updateProduct', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
    async submitHandlerAddProductStorage() {
      try {
        console.log(this.addStorageData)
        const data = await this.$store.dispatch('addProductToStorage', this.addStorageData)
        this.$message('Товар успешно добавлен в склад', `Товар № ${this.product.id} успешно обновлен`, 'CheckSquareIcon', 'success')
        // eslint-disable-next-line operator-assignment
        this.$emit('addStorage', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
