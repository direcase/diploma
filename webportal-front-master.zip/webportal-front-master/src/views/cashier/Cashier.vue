<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <b-card-actions
        ref="cardAction"
        title="Касса 🛒"
        action-refresh
        @refresh="refreshStop('cardAction')"
      >
        <b-row>
          <b-col
            md="2"
            sm="4"
            class="my-1"
          >
            <b-form-group
              class="mb-0"
            >
              <label class="d-inline-block text-sm-left mr-50">На страницу</label>
              <b-form-select
                id="perPageSelect"
                v-model="perPage"
                size="sm"
                :options="pageOptions"
                class="w-50"
                @change="handlePerPageChange"
              />
            </b-form-group>
          </b-col>
          <b-col
            md="4"
            sm="8"
            class="my-1"
          >
            <b-form-group
              label="Сортировать"
              label-cols-sm="3"
              label-align-sm="right"
              label-size="sm"
              label-for="sortBySelect"
              class="mb-0"
            >
              <b-input-group size="sm">
                <b-form-select
                  id="sortBySelect"
                  v-model="sortBy"
                  :options="sortOptions"
                  class="w-75"
                  @change="handleSortByChange"
                >
                  <template v-slot:first>
                    <option value="">
                      -- ничто --
                    </option>
                  </template>
                </b-form-select>
                <b-form-select
                  v-model="sortDirection"
                  size="sm"
                  :disabled="!sortBy"
                  class="w-25"
                  @change="handleSortDescChange"
                >
                  <option :value="'asc'">
                    По возрастанию
                  </option>
                  <option :value="'desc'">
                    По убыванию
                  </option>
                </b-form-select>
              </b-input-group>
            </b-form-group>
          </b-col>
          <b-col
            md="6"
            class="my-1"
          >
            <b-form-group
              label="Фильтр"
              label-cols-sm="3"
              label-align-sm="right"
              label-size="sm"
              label-for="filterInput"
              class="mb-0"
            >
              <b-input-group size="sm">
                <b-form-input
                  id="filterInput"
                  v-model="filter"
                  type="search"
                  placeholder="Введите для поиска"
                  @input="handleFilterChange"
                />
                <b-input-group-append />
              </b-input-group>
            </b-form-group>
          </b-col>

          <b-col cols="12">
            <b-table
              class="position-relative"
              striped
              hover
              responsive
              :items="items"
              :fields="fields"
              :current-page="currentPage"
              :per-page="0"
              @row-clicked="rowClick"
            >
              <template #cell(status)="data">
                <b-badge
                  pill
                  :variant="getStatusVariant(data.item.status.toString())"
                >
                  {{ getStatusText(data.item.status.toString()) }}
                </b-badge>
              </template>
              <template #cell(acceptedDate)="data">
                {{ getDateByFormat(data.item.accepted, 'datetime') }}
              </template>
              <template #cell(id)="data">
                <b-link
                  active
                  :to="'/cashier/'+data.item.id"
                >
                  {{ data.item.id }}
                </b-link>
              </template>
              <template #cell(clientName)="data">
                {{ data.item.clientName }}
              </template>
              <template #cell(model)="data">
                {{ data.item.type + ' ' + data.item.model }}
              </template>
              <template #cell(model)="data">
                {{ data.item.type + ' ' + data.item.model }}
              </template>
            </b-table>
          </b-col>

          <b-col
            cols="12"
          >
            <h5>Всего: <b>{{ length }}</b></h5>
            <b-pagination
              v-model="currentPage"
              :total-rows="length"
              :per-page="perPage"
              align="center"
              size="sm"
              class="my-0"
              @change="handlePageChange"
            />
          </b-col>
        </b-row>
      </b-card-actions>
    </div>
  </div>
</template>

<script>
import {
  BTable, BBadge, BRow, BCol, BFormGroup, BFormSelect, BPagination, BInputGroup, BFormInput, BInputGroupAppend, BLink,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
// eslint-disable-next-line import/extensions
import BCardActions from '@core/components/b-card-actions/BCardActions'
import Loader from '@/layouts/components/Loader.vue'

export default {
  components: {
    BLink,
    BCardActions,
    BTable,
    BBadge,
    BRow,
    BCol,
    Loader,
    BFormGroup,
    BFormSelect,
    BPagination,
    BInputGroup,
    BFormInput,
    BInputGroupAppend,
    // eslint-disable-next-line vue/no-unused-components
  },
  data() {
    return {
      items: [],
      loader: true,
      isAddNewOrderSidebarActive: false,
      status: 'WENTCASHIER',
      perPage: 10,
      pageOptions: [1, 5, 10, 20, 50],
      totalRows: 1,
      currentPage: 1,
      sortBy: 'id',
      sortDesc: true,
      sortDirection: 'desc',
      filter: '',
      length: 0,
      infoModal: {
        id: 'info-modal',
        title: '',
        content: '',
      },
      fields: [
        {
          key: 'id', label: 'Id', sortableField: true,
        },
        {
          key: 'acceptedDate', label: 'Дата приемки', sortableField: true,
        },
        {
          key: 'clientName', label: 'ФИО', sortableField: true,
        },
        { key: 'phoneNumber', label: 'Телефон Номер', sortableField: true },
        {
          key: 'status', label: 'Статус', sortableField: true,
        },
        {
          key: 'model', label: 'Устройство', sortableField: true,
        },
      ],
    }
  },
  computed: {
    sortOptions() {
      // Create an options list from our fields
      return this.fields
        .filter(f => f.sortableField)
        .map(f => ({ text: f.label, value: f.key }))
    },
  },
  async mounted() {
    try {
      this.loader = true
      await this.fetchOrderPagination()
      this.loader = false
      // eslint-disable-next-line no-empty
    } catch (e) {
    }
  },
  methods: {
    info(item, index, button) {
      this.infoModal.title = `Row index: ${index}`
      this.infoModal.content = JSON.stringify(item, null, 2)
      console.log(item)
      this.$root.$emit('bv::show::modal', this.infoModal.id, button)
    },
    resetInfoModal() {
      this.infoModal.title = ''
      this.infoModal.content = ''
    },
    getPaginationData() {
      const data = {}
      data.status = this.status
      data.sortBy = this.sortBy
      data.currentPage = this.currentPage
      data.sortDirection = this.sortDirection
      data.perPage = this.perPage
      data.filter = this.filter
      return data
    },
    async fetchOrderPagination() {
      const response = await this.$store.dispatch('fetchAllOrdersByStatusPagination', this.getPaginationData())
      this.items = response.data
      this.length = response.totalItems
      this.currentPage = response.currentPage
    },
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length
      this.length = filteredItems.length
      this.currentPage = 1
    },
    avatarText(value) {
      if (!value) return ''
      const nameArray = value.split(' ')
      return nameArray.map(word => word.charAt(0).toUpperCase()).join('')
    },
    getDateByFormat(date, format) {
      const options = {}
      if (format.includes('date')) {
        options.day = '2-digit'
        options.month = 'long'
        options.year = 'numeric'
      }
      if (format.includes('time')) {
        options.hour = '2-digit'
        options.minute = '2-digit'
        options.second = '2-digit'
      }
      const locale = 'ru-RU'
      return new Intl.DateTimeFormat(locale, options).format(new Date(date))
    },
    addOrder(data) {
      if (data) {
        this.loadData()
      }
    },
    rowClick(record) {
      this.$router.push(`/cashier/${record.id}`)
    },
    getStatusVariant(status) {
      switch (status) {
        case 'DONE':
          return 'warning'
        case 'NOTDONE':
          return 'danger'
        case 'WENTCASHIER':
          return 'primary'
        default:
          return 'success'
      }
    },
    getStatusText(status) {
      switch (status) {
        case 'DONE':
          return 'Сделано'
        case 'NOTDONE':
          return 'Не сделано'
        case 'WENTCASHIER':
          return 'Ожидается платеж'
        default:
          return 'Выдано'
      }
    },
    async loadData() {
      this.$refs.cardAction.showLoading = true
      await this.fetchOrderPagination()
      this.$refs.cardAction.showLoading = false
    },
    async refreshStop(cardName) {
      await this.fetchOrderPagination()
      this.$refs[cardName].showLoading = false
    },
    async handlePageChange(value) {
      this.currentPage = value
      await this.loadData()
    },
    async handlePerPageChange(value) {
      this.perPage = value
      await this.loadData()
    },
    async handleSortByChange(value) {
      this.sortBy = value
      await this.loadData()
    },
    async handleSortDescChange(value) {
      this.sortDirection = value
      await this.loadData()
    },
    async handleFilterChange(value) {
      this.filter = value
      await this.loadData()
    },
  },
}
</script>

<style scoped>

</style>
