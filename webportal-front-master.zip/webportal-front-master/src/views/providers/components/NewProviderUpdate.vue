<template>
  <b-modal
    id="modal-scrollable"
    ref="modal"
    scrollable
    centered
    title="Изменить данные поставщика 📦"
    cancel-title="Отменить"
    ok-title="Изменить"
    @ok="handleOk"
    @hidden="reset"
    @reset="reset"
  >

    <validation-observer
      ref="refFormObserver"
    >
      <!-- Form -->
      <b-form
        class="p-2"
        @submit.prevent="submitHandler"
        @reset.prevent="reset"
      >
        <!-- Phone Number -->
        <validation-provider
          #default="validationContext"
          name="Имя поставщика"
          rules="required"
        >
          <b-form-group
            label="Имя поставщика"
            label-for="name"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="TagIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="name"
                v-model="providerData.name"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.name"
              class="text-danger"
            >
              {{ validation.name }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <!--          Product Name-->
        <validation-provider
          #default="validationContext"
          name="Адрес поставщика"
          rules="required"
        >
          <b-form-group
            label="Адрес поставщика"
            label-for="address"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="MapPinIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="address"
                v-model="providerData.address"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.address"
              class="text-danger"
            >
              {{ validation.address }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
        <validation-provider
          #default="validationContext"
          name="Цена"
          rules="required"
        >
          <b-form-group
            label="Номер поставщика"
            label-for="number"
          >
            <b-input-group>
              <b-input-group-prepend is-text>
                <feather-icon icon="PhoneIcon" />
              </b-input-group-prepend>
              <b-form-input
                id="price"
                v-model.number="providerData.phoneNumber"
                type="number"
                :state="getValidationState(validationContext)"
              />
            </b-input-group>
            <p
              v-if="validation.phoneNumber"
              class="text-danger"
            >
              {{ validation.phoneNumber }}
            </p>
            <b-form-invalid-feedback>
              {{ validationContext.errors[0] }}
            </b-form-invalid-feedback>
          </b-form-group>
        </validation-provider>
      </b-form>
    </validation-observer>

  </b-modal>
</template>

<script>
import {
  BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'UpdateProviderModal',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  props: {
    provider: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.provider) {
      this.setData(this.provider)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankProviderData = {
      id: null,
      name: '',
      address: '',
      phoneNumber: '',
    }
    const providerData = ref(JSON.parse(JSON.stringify(blankProviderData)))
    const resetOrderData = () => {
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      providerData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    show() {
      this.$refs.modal.show()
    },
    setData(data) {
      this.providerData.id = data.id
      this.providerData.name = data.name
      this.providerData.address = data.address
      this.providerData.phoneNumber = data.phoneNumber
    },
    handleOk(bvModalEvt) {
      // Prevent modal from closing
      bvModalEvt.preventDefault()
      // Trigger submit handler
      this.submitHandler()
    },
    reset() {
      this.setData(this.provider)
      this.validation = {}
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateProvider', this.providerData)
        this.$message(`Поставщик ${data.name} успешно обновлен`, `Поставщик ${data.name} успешно обновлен`, 'TruckIcon', 'success')
        this.validation = {}
        this.$emit('updateProvider', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
