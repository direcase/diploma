<template>
  <div>
    <b-row class="match-height">
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="warning"
          icon="UsersIcon"
          :statistic="provider.name"
          statistic-title="Имя поставщика"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <statistic-card-vertical
          color="success"
          icon="MapPinIcon"
          :statistic="provider.address"
          statistic-title="Адрес Поставщика"
        />
      </b-col>
      <b-col
        xl="2"
        md="4"
        sm="6"
      >
        <b-link :href="'tel:'+provider.phoneNumber">
          <statistic-card-vertical
            color="primary"
            icon="PhoneIcon"
            :statistic="provider.phoneNumber"
            statistic-title="Телефон Поставщика"
          />
        </b-link>
      </b-col>
    </b-row>
  </div>
</template>

<script>
import StatisticCardVertical from '@core/components/statistics-cards/StatisticCardVertical.vue'

import {
  BRow, BCol, BLink,
} from 'bootstrap-vue'

export default {
  components: {
    BRow,
    BCol,
    BLink,
    StatisticCardVertical,
  },
  props: {
    provider: {
      type: Object,
      required: true,
    },
  },
  setup() {
  },
  data: () => ({
  }),
  computed: {
    user() {
      return this.$store.getters.user
    },
    hasAdminPermission() {
      if (this.user.roles.includes('ADMIN')) {
        return true
      }
      return false
    },
  },
  methods: {
  },
}
</script>

<style>

</style>
