<template>
  <b-sidebar
    id="add-new-order-sidebar"
    :visible="isUpdateProviderSidebarActive"
    bg-variant="white"
    sidebar-class="sidebar-lg"
    shadow
    backdrop
    no-header
    right
    @hidden="reset"
    @change="(val) => $emit('update:is-update-provider-sidebar-active', val)"
  >
    <template #default="{ hide }">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center content-sidebar-header px-2 py-1">
        <h5 class="mb-0">
          Изменить услугу 📦
        </h5>

        <feather-icon
          class="ml-1 cursor-pointer"
          icon="XIcon"
          size="16"
          @click="hide"
        />

      </div>

      <!-- BODY -->
      <validation-observer
        ref="refFormObserver"
      >
        <!-- Form -->
        <b-form
          class="p-2"
          @submit.prevent="submitHandler"
          @reset.prevent="reset"
        >
          <!-- Phone Number -->
          <validation-provider
            #default="validationContext"
            name="Имя поставщика"
            rules="required"
          >
            <b-form-group
              label="Имя поставщика"
              label-for="name"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="TagIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="name"
                  v-model="providerData.name"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.name"
                class="text-danger"
              >
                {{ validation.name }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <!--          Product Name-->
          <validation-provider
            #default="validationContext"
            name="Адрес поставщика"
            rules="required"
          >
            <b-form-group
              label="Адрес поставщика"
              label-for="address"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="MapPinIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="address"
                  v-model="providerData.address"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.address"
                class="text-danger"
              >
                {{ validation.address }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>
          <validation-provider
            #default="validationContext"
            name="Цена"
            rules="required"
          >
            <b-form-group
              label="Номер поставщика"
              label-for="number"
            >
              <b-input-group>
                <b-input-group-prepend is-text>
                  <feather-icon icon="PhoneIcon" />
                </b-input-group-prepend>
                <b-form-input
                  id="price"
                  v-model.number="providerData.phoneNumber"
                  type="number"
                  :state="getValidationState(validationContext)"
                />
              </b-input-group>
              <p
                v-if="validation.phoneNumber"
                class="text-danger"
              >
                {{ validation.phoneNumber }}
              </p>
              <b-form-invalid-feedback>
                {{ validationContext.errors[0] }}
              </b-form-invalid-feedback>
            </b-form-group>
          </validation-provider>

          <!-- Form Actions -->
          <div class="d-flex mt-2">
            <b-button
              v-ripple.400="'rgba(255, 255, 255, 0.15)'"
              variant="primary"
              class="mr-2"
              type="submit"
            >
              Изменить
            </b-button>
            <b-button
              v-ripple.400="'rgba(186, 191, 199, 0.15)'"
              type="button"
              variant="outline-secondary"
              @click="hide"
            >
              Отменить
            </b-button>
          </div>
        </b-form>
      </validation-observer>
    </template>
  </b-sidebar>
</template>

<script>
import {
  BSidebar, BForm, BInputGroupPrepend, BFormGroup, BFormInput, BInputGroup, BFormInvalidFeedback, BButton,
} from 'bootstrap-vue'
import { ValidationProvider, ValidationObserver } from 'vee-validate'
import { ref } from '@vue/composition-api'
import { required, alphaNum } from '@validations'
import formValidation from '@core/comp-functions/forms/form-validation'
import Ripple from 'vue-ripple-directive'

export default {
  name: 'OrdersAdd',
  components: {
    BInputGroup,
    BInputGroupPrepend,
    BSidebar,
    BForm,
    BFormGroup,
    BFormInput,
    BFormInvalidFeedback,
    BButton,
    // Form Validation
    ValidationProvider,
    ValidationObserver,
  },
  directives: {
    Ripple,
  },
  model: {
    prop: 'isUpdateProviderSidebarActive',
    event: 'update:is-update-provider-sidebar-active',
  },
  props: {
    isUpdateProviderSidebarActive: {
      type: Boolean,
      required: true,
    },
    provider: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      required,
      alphaNum,
      validation: {},
    }
  },
  mounted() {
    if (this.provider) {
      this.setData(this.provider)
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup() {
    const blankProviderData = {
      id: null,
      name: '',
      address: '',
      phoneNumber: '',
    }
    const providerData = ref(JSON.parse(JSON.stringify(blankProviderData)))
    const resetOrderData = () => {
    }
    const {
      refFormObserver,
      getValidationState,
      resetForm,
    } = formValidation(resetOrderData)

    return {
      providerData,
      refFormObserver,
      getValidationState,
      resetForm,
    }
  },
  methods: {
    reset() {
      this.validation = {}
    },
    setData(data) {
      this.providerData.id = data.id
      this.providerData.name = data.name
      this.providerData.address = data.address
      this.providerData.phoneNumber = data.phoneNumber
    },
    async submitHandler() {
      try {
        const data = await this.$store.dispatch('updateProvider', this.providerData)
        this.$message(`Поставщик ${data.name} успешно обновлен`, `Поставщик ${data.name} успешно обновлен`, 'TruckIcon', 'success')
        this.validation = {}
        this.$emit('updateProvider', data)
        // eslint-disable-next-line no-empty
      } catch (e) {
        if (e.response.data.validation) {
          this.validation = e.response.data.validation
        }
      }
    },
  },
}
</script>

<style lang="scss">
@import '@core/scss/vue/libs/vue-select.scss';

#add-new-order-sidebar {
  .vs__dropdown-menu {
    max-height: 200px !important;
  }
}
</style>
