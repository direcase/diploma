<template>
  <div>
    <Loader v-if="loader" />
    <div v-else>
      <!-- Alert: No item found -->
      <b-alert
        variant="danger"
        :show="provider === undefined"
      >
        <h4 class="alert-heading">
          Ошибка при получении данных
        </h4>
        <div class="alert-body">
          Не найдено ни одного поставщика с этим идентификатором. Проверить
          <b-link
            class="alert-link"
            :to="'/providers'"
          >
            Список поставщиков
          </b-link>
          для других Поставщиков.
        </div>
      </b-alert>

      <template v-if="provider">
        <new-provider-update
          ref="updateModal"
          :provider="provider"
          @updateProvider="updateProvider"
        />
        <hr>
        <h3>{{ provider.name }}</h3>
        <hr>
        <div class="demo-inline-spacing mb-1">
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            class="border-primary border-darken-3 bg-primary bg-darken-3"
            @click="showUpdateModal"
          >
            <feather-icon
              icon="EditIcon"
              class="mr-50"
            />
            <span class="align-middle">Изменить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="danger"
            @click="deleteProvider"
          >
            <feather-icon
              icon="Trash2Icon"
              class="mr-50"
            />
            <span class="align-middle">Удалить</span>
          </b-button>
          <b-button
            v-ripple.400="'rgba(255, 255, 255, 0.15)'"
            variant="success"
            @click="fetchAllData"
          >
            <feather-icon
              icon="RefreshCwIcon"
              class="mr-50"
            />
            <span class="align-middle" />
          </b-button>
        </div>
        <provider-info-card
          :provider="provider"
        />
      </template>
    </div>
  </div>
</template>

<script>
import {
  BAlert, BLink, BButton,
} from 'bootstrap-vue'
// eslint-disable-next-line import/extensions
import Loader from '@/layouts/components/Loader.vue'
import Ripple from 'vue-ripple-directive'
import NewProviderUpdate from '@/views/providers/components/NewProviderUpdate.vue'
import ProviderInfoCard from '@/views/providers/components/ProviderInfoCard.vue'

export default {
  components: {
    // eslint-disable-next-line vue/no-unused-components
    NewProviderUpdate,
    Loader,
    BAlert,
    BLink,
    BButton,
    ProviderInfoCard,
  },
  directives: {
    Ripple,
  },
  data: () => ({
    provider: {},
    loader: true,
  }),
  async mounted() {
    try {
      await this.fetchAllData()
      // eslint-disable-next-line no-empty
    } catch (e) {}
  },
  methods: {
    deleteProvider() {
      this.$swal({
        title: 'Вы уверены?',
        text: 'Вы не сможете отменить это!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Да, удалить!',
        cancelButtonText: 'Отменить',
        customClass: {
          confirmButton: 'btn btn-primary',
          cancelButton: 'btn btn-outline-danger ml-1',
        },
        buttonsStyling: false,
      }).then(async result => {
        if (result.value) {
          try {
            await this.$store.dispatch('deleteProvider', this.provider.id)
            this.$swal({
              icon: 'success',
              title: 'Удалено!',
              text: 'Услуга удалена с базы.',
              customClass: {
                confirmButton: 'btn btn-success',
              },
            })
            await this.$router.push('/providers')
            // eslint-disable-next-line no-empty
          } catch (e) {}
        }
      })
    },
    updateProvider(data) {
      if (data) {
        this.provider = data
      }
    },
    async fetchAllData() {
      this.loader = true
      this.provider = await this.$store.dispatch('fetchProviderById', this.$route.params.id)
      this.loader = false
    },
    showUpdateModal() {
      this.$refs.updateModal.show()
    },
  },
}
</script>

<style>

</style>
