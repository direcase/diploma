<template>
  <div>
    <b-card title="NanoService 🚀">
      <b-card-text>Если у вас возникли вопросы, свяжитесь со службой поддержки</b-card-text>
      <b-card-text>
        <b-list-group>
          <b-list-group-item variant="info">
            <b-link
              :href="'tel:87013406863'"
            >
              +7-(701)-340-6863
            </b-link>
          </b-list-group-item>
          <b-list-group-item variant="info">
            <b-link
              :href="'tel:87079065954'"
            >
              +7-(707)-906-5954
            </b-link>
          </b-list-group-item>
        </b-list-group>
      </b-card-text>
    </b-card>

    <!--    <b-card title="Want to integrate JWT? 🔒">
      <b-card-text>We carefully crafted JWT flow so you can implement JWT with ease and with minimum efforts.</b-card-text>
      <b-card-text>Please read our  JWT Documentation to get more out of JWT authentication.</b-card-text>
    </b-card>-->
  </div>
</template>

<script>
import {
  BCard, BCardText, BLink, BListGroupItem, BListGroup,
} from 'bootstrap-vue'

export default {
  components: {
    BCard,
    BCardText,
    BLink,
    BListGroupItem,
    BListGroup,
  },
}
</script>

<style>

</style>
