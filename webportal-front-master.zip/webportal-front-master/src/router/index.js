import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '@/store'

Vue.use(VueRouter)

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  scrollBehavior() {
    return { x: 0, y: 0 }
  },
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('@/views/Home.vue'),
      meta: {
        pageTitle: 'Home',
        auth: true,
        breadcrumb: [
          {
            text: 'Home',
            active: true,
          },
        ],
      },
    },
    {
      path: '/client/order/:id/:token',
      name: 'clientOrderView',
      component: () => import('@/views/clientQR/ClientQRView'),
      meta: {
        pageTitle: 'QR код Заказа №',
        breadcrumb: [
          {
            text: 'QR',
            active: true,
          },
        ],
      },
    },
    {
      path: '/service-centers',
      name: 'service-centers',
      component: () => import('@/views/service-centers/ServiceCenter.vue'),
      meta: {
        pageTitle: 'Сервисные Центры',
        auth: true,
        breadcrumb: [
          {
            text: 'Сервисные Центры',
            active: true,
          },
        ],
      },
    },
    {
      path: '/experience-models',
      name: 'experience-models',
      component: () => import('@/views/experience-models/ExperienceModels.vue'),
      meta: {
        pageTitle: 'Опыт работы',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Опыт работы',
            active: true,
          },
        ],
      },
    },
    {
      path: '/statistic',
      name: 'statistic',
      component: () => import('@/views/statistics/Statistic.vue'),
      meta: {
        pageTitle: 'Статистика',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Статистика',
            active: true,
          },
        ],
      },
    },
    {
      path: '/users',
      name: 'users',
      component: () => import('@/views/users/Users.vue'),
      meta: {
        pageTitle: 'Пользователи',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Пользователи',
            active: true,
          },
        ],
      },
    },
    {
      path: '/orders',
      name: 'orders',
      component: () => import('@/views/orders/Orders.vue'),
      meta: {
        pageTitle: 'Заказы',
        auth: true,
        role: 'USER',
        breadcrumb: [
          {
            text: 'Заказы',
            active: true,
          },
        ],
      },
    },
    {
      path: '/products',
      name: 'products',
      component: () => import('@/views/products/Product.vue'),
      meta: {
        pageTitle: 'Товары',
        auth: true,
        role: 'USER',
        breadcrumb: [
          {
            text: 'Товары',
            active: true,
          },
        ],
      },
    },
    {
      path: '/models',
      name: 'models',
      component: () => import('@/views/models/Model.vue'),
      meta: {
        pageTitle: 'Модели',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Модели',
            active: true,
          },
        ],
      },
    },
    {
      path: '/providers',
      name: 'providers',
      component: () => import('@/views/providers/Provider.vue'),
      meta: {
        pageTitle: 'Поставщики',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Поставщики',
            active: true,
          },
        ],
      },
    },
    {
      path: '/discounts',
      name: 'discounts',
      component: () => import('@/views/discounts/Discount.vue'),
      meta: {
        pageTitle: 'Скидки',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Скидки',
            active: true,
          },
        ],
      },
    },
    {
      path: '/clients',
      name: 'clients',
      component: () => import('@/views/clients/Client.vue'),
      meta: {
        pageTitle: 'Клиенты',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Клиенты',
            active: true,
          },
        ],
      },
    },
    {
      path: '/report',
      name: 'report',
      component: () => import('@/views/reports/Report.vue'),
      meta: {
        pageTitle: 'Отчет',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Отчет',
            active: true,
          },
        ],
      },
    },
    {
      path: '/types',
      name: 'types',
      component: () => import('@/views/types/Types.vue'),
      meta: {
        pageTitle: 'Устройства',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Устройства',
            active: true,
          },
        ],
      },
    },
    {
      path: '/users/:id',
      name: 'usersId',
      component: () => import('@/views/users/UserView.vue'),
      meta: {
        pageTitle: 'Пользователь №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Пользователи',
            active: true,
          },
        ],
      },
    },
    {
      path: '/report-salary',
      name: 'report-salary',
      component: () => import('@/views/reports/salary/ReportSalary.vue'),
      props: route => ({ date1: route.query.date1, date2: route.query.date2, userId: route.query.userId }),
      meta: {
        pageTitle: 'Рассчет зарплаты',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Рассчет зарплаты',
            active: true,
          },
        ],
      },
    },
    {
      path: '/report-accepted',
      name: 'report-accepted',
      component: () => import('@/views/reports/salary/ReportAcceptedOrder.vue'),
      props: route => ({
        date1: route.query.date1, date2: route.query.date2, size: route.query.size || 10, page: route.query.page || 1, sortBy: route.query.sortBy || 'orderId', sortDirection: route.query.sortDirection || 'desc',
      }),
      meta: {
        pageTitle: 'Отчет принятых заказов',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Отчет принятых заказов',
            active: true,
          },
        ],
      },
    },
    {
      path: '/report-done',
      name: 'report-done',
      component: () => import('@/views/reports/salary/ReportDoneOrder.vue'),
      props: route => ({
        date1: route.query.date1, date2: route.query.date2, size: route.query.size || 10, page: route.query.page || 1, sortBy: route.query.sortBy || 'orderId', sortDirection: route.query.sortDirection || 'desc',
      }),
      meta: {
        pageTitle: 'Отчет выполненных заказов',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Отчет выполненных заказов',
            active: true,
          },
        ],
      },
    },
    {
      path: '/report-given',
      name: 'report-given',
      component: () => import('@/views/reports/salary/ReportGivenOrder.vue'),
      props: route => ({
        date1: route.query.date1, date2: route.query.date2, size: route.query.size || 10, page: route.query.page || 1, sortBy: route.query.sortBy || 'orderId', sortDirection: route.query.sortDirection || 'desc',
      }),
      meta: {
        pageTitle: 'Отчет given заказов',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Отчет given заказов',
            active: true,
          },
        ],
      },
    },
    {
      path: '/documents/:id',
      name: 'documentsId',
      component: () => import('@/views/documents/DocumentView.vue'),
      meta: {
        pageTitle: 'Документ №',
        auth: true,
        role: 'USER',
        breadcrumb: [
          {
            text: 'Документы',
            active: true,
          },
        ],
      },
    },
    {
      path: '/discounts/:id',
      name: 'discountsId',
      component: () => import('@/views/discounts/DiscountView.vue'),
      meta: {
        pageTitle: 'Скидка №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Скидки',
            active: true,
          },
        ],
      },
    },
    {
      path: '/experience-models/:id',
      name: 'experience-models-id',
      component: () => import('@/views/experience-models/ExperienceModelView.vue'),
      meta: {
        pageTitle: 'Опыт работы №',
        auth: true,
        role: 'ADMIN',
        breadcrumb: [
          {
            text: 'Опыт работы',
            active: true,
          },
        ],
      },
    },
    {
      path: '/models/:id',
      name: 'modelsId',
      component: () => import('@/views/models/ModelView.vue'),
      meta: {
        pageTitle: 'Модель №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Модели',
            active: true,
          },
        ],
      },
    },
    {
      path: '/clients/:id',
      name: 'clientsId',
      component: () => import('@/views/clients/ClientView.vue'),
      meta: {
        pageTitle: 'Скидка №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Скидки',
            active: true,
          },
        ],
      },
    },
    {
      path: '/orders/:id',
      name: 'ordersId',
      component: () => import('@/views/orders/OrderView.vue'),
      meta: {
        pageTitle: 'Заказ №',
        auth: true,
        role: 'USER',
        breadcrumb: [
          {
            text: 'Заказы',
            active: true,
          },
        ],
      },
    },
    {
      path: '/providers/:id',
      name: 'providersId',
      component: () => import('@/views/providers/ProviderView.vue'),
      meta: {
        pageTitle: 'Поставщик №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Поставщики',
            active: true,
          },
        ],
      },
    },
    {
      path: '/service-centers/:id',
      name: 'service-centers-id',
      component: () => import('@/views/service-centers/ServiceCenterView.vue'),
      meta: {
        pageTitle: 'Сервисный центр №',
        auth: true,
        role: 'OWNER',
        breadcrumb: [
          {
            text: 'Сервисные Центры',
            active: true,
          },
        ],
      },
    },
    {
      path: '/products/:id',
      name: 'productsId',
      component: () => import('@/views/products/ProductView.vue'),
      meta: {
        pageTitle: 'Товар №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Товары',
            active: true,
          },
        ],
      },
    },
    {
      path: '/services/:id',
      name: 'servicesId',
      component: () => import('@/views/services/ServiceView.vue'),
      meta: {
        pageTitle: 'Услуга №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Услуга',
            active: true,
          },
        ],
      },
    },
    {
      path: '/types/:id',
      name: 'typesId',
      component: () => import('@/views/types/TypeView.vue'),
      meta: {
        pageTitle: 'Услуга №',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Услуга',
            active: true,
          },
        ],
      },
    },
    {
      path: '/cashier/:id',
      name: 'cashierId',
      component: () => import('@/views/cashier/CashierView.vue'),
      meta: {
        pageTitle: 'Заказ №',
        auth: true,
        role: 'CASHIER',
        breadcrumb: [
          {
            text: 'Заказ',
            active: true,
          },
        ],
      },
    },
    {
      path: '/services',
      name: 'services',
      component: () => import('@/views/services/Service.vue'),
      meta: {
        pageTitle: 'Услуги',
        auth: true,
        role: 'MODERATOR',
        breadcrumb: [
          {
            text: 'Услуги',
            active: true,
          },
        ],
      },
    },
    {
      path: '/cashier',
      name: 'cashier',
      component: () => import('@/views/cashier/Cashier.vue'),
      meta: {
        pageTitle: 'Касса',
        auth: true,
        role: 'CASHIER',
        breadcrumb: [
          {
            text: 'Касса',
            active: true,
          },
        ],
      },
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/Login.vue'),
      meta: {
        layout: 'full',
      },
      auth: false,
    },
    {
      path: '/error-404',
      name: 'error-404',
      component: () => import('@/views/error/Error404.vue'),
      meta: {
        layout: 'full',
      },
    },
    {
      path: '*',
      redirect: 'error-404',
    },
  ],
})

// ? For splash screen
// Remove afterEach hook if you are not using splash screen
router.afterEach(() => {
  // Remove initial loading
  const appLoading = document.getElementById('loading-bg')
  if (appLoading) {
    appLoading.style.display = 'none'
  }
})

router.beforeEach((to, from, next) => {
  const currentToken = localStorage.getItem('token')
  const requireAuth = to.matched.some(record => record.meta.auth)
  if (requireAuth && !currentToken) {
    next('/login?message=login')
  } else if (!requireAuth) {
    next()
  } else if (!to.meta.role) {
    next()
  } else if (to.meta.role) {
    const currentUser = store.getters.user
    if (!currentUser.roles.includes(to.meta.role)) {
      next(`${from.path}?message=notpermitted`)
    } else {
      next()
    }
  }
})
export default router
