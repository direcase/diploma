/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllClientsPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`clients?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllClients({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('clients/select', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem.surname+' '+elem.name, value: elem.id, discount_id: elem.discount.id, discountName: elem.discount.discountName, number: elem.phoneNumber})
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async addClient({ commit }, {name, surname, phoneNumber, discountId}) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('clients', {
          name,
          surname,
          phoneNumber,
          discountId,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async updateClient({ commit }, { id, name, surname, phoneNumber, discountId} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('clients/'+id, {
          id,
          name,
          surname,
          phoneNumber,
          discountId,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteClient({ commit }, clientId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('clients/'+clientId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchClientById({ commit }, clientId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('clients/'+clientId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
