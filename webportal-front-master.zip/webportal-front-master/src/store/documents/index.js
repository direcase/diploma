import axios from 'axios'

export default {
  actions: {
    async fetchOrderDocuments({ commit }, orderId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`documents/orders/${orderId}`, {})
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async createDocument({ commit }, {
      orderId,
      documentType,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.put('documents', {
          orderId,
          documentType,
        }))
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchDocumentById({ commit }, documentId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`documents/${documentId}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async changeDocumentStatus({ commit }, { orderId, documentId, documentStatus }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('documents/status', {
          orderId,
          documentId,
          documentStatus,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteDocument({ commit }, documentId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete(`documents/${documentId}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
  },
}
