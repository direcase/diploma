/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllProductsPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`products?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchAllProducts({ commit }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/select', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async deleteProduct({ commit }, productId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('products/'+productId, {
        })
        const { data } = response
        console.log('deleteData', data)
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteIncomingHistory({ commit }, { historyId, productId }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('products/'+productId+'/history/incoming/'+historyId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchProductById({ commit }, productId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/'+productId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchTopSaleProduct({ commit },) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/top-sale', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchSoldProductCount({ commit },) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/sold-count', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async getSoldProductCount({ commit }, productId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/'+productId+'/sold', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchTopProfitProducts({ commit }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/top-profit-products', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchLastPurchasePrice({ commit }, productId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/'+productId+'/last/purchase', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async updateProduct({ commit }, { name, description, price, id } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('products/'+id, {
          id,
          name,
          description,
          price,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async addProductToStorage({ commit }, { providerId, price, quantity, productId} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('products/'+productId+'/add', {
          providerId,
          price,
          quantity,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async addProduct({ commit }, { name, description, price} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('products', {
          name,
          description,
          price,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchIncomingHistory({ commit }, {
      productId, sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`products/${productId}/history/incoming?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        console.log('Service Centers', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async getMonthlySalesProduct({ commit }, productId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('products/'+productId+'/monthly/sold', {
        })
        const { data } = response
        const months = [
          'Январь', 'Февраль', 'Март',
          'Апрель', 'Май', 'Июнь',
          'Июль', 'Август', 'Сентябрь',
          'Октябрь', 'Ноябрь', 'Декабрь',
        ]
        let sum = 0
        let month = []
        let count = []
        data.forEach(data=>{
          sum += data.count
          month.push(months[data.month-1])
          count.push(data.count)
        })
        let object = {}
        object.avg = sum / data[data.length - 1].month
        object.month = month
        object.count = count
        return object
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
