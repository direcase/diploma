import Vue from 'vue'
import Vuex from 'vuex'

// Modules
import auth from '@/store/auth/auth'
import users from '@/store/users/users'
import createPersistedState from 'vuex-persistedstate'
import app from './app'
import appConfig from './app-config'
import verticalMenu from './vertical-menu'
import orders from './orders'
import models from './models'
import types from './types'
import discounts from './discounts'
import clients from './clients'
import products from './products'
import services from './services'
import providers from './providers'
import serviceCenters from './serviceCenters'
import experienceModels from './experience-models'
import documents from './documents'
import reports from './reports'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    error: null,
  },
  mutations: {
    setError(state, error) {
      state.error = error
    },
    clearError(state) {
      state.error = null
    },
  },
  getters: {
    error: s => s.error,
  },
  modules: {
    app,
    appConfig,
    verticalMenu,
    auth,
    users,
    orders,
    models,
    types,
    discounts,
    clients,
    products,
    services,
    providers,
    serviceCenters,
    experienceModels,
    documents,
    reports,
  },
  plugins: [createPersistedState()],
  strict: process.env.DEV,
})
