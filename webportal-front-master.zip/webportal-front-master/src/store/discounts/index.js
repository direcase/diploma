/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllDiscountsPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`discounts?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllDiscounts({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('discounts/select', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem.discountName, value: elem.id, percentage: elem.percentage})
        })
        console.log(newDate)
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async addDiscount({ commit }, {discountName, percentage}) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('discounts', {
          discountName,
          percentage,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async updateDiscount({ commit }, { id, discountName, percentage} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('discounts/'+id, {
          id,
          discountName,
          percentage,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteDiscount({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('discounts/'+id, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchDiscountById({ commit }, discountId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('discounts/'+discountId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
