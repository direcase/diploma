/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    async fetchAllTypesPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`types?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        console.log('Types', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllTypes({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('types/select', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem.name, value: elem.id})
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async addType({ commit }, { name }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('types', {
          name
        })
        const { data } = response
        let newDate = {label: data.name, value: data.id,}
        return newDate
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async updateType({ commit }, { id, name} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('types/'+id, {
          id,
          name,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteType({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('types/'+id, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchTypeById({ commit }, typeId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('types/'+typeId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
