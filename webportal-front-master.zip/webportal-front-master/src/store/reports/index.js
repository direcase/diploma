/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchCalculateMasterSalary({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, date1, date2, userId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`orders/calculate-salary?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}&date1=${date1}&date2=${date2}&userId=${userId}`, {
        })
        const { data } = response
        console.log('DATA', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchReportAcceptedOrder({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, date1, date2,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`orders/report-accepted?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}&date1=${date1}&date2=${date2}`, {
        })
        const { data } = response
        console.log('DATA', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchReportDoneOrder({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, date1, date2,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`orders/report-done?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}&date1=${date1}&date2=${date2}`, {
        })
        const { data } = response
        console.log('DATA', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchReportGivenOrder({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, date1, date2,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        console.log(perPage)
        const response = await axios.get(`orders/report-given?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}&date1=${date1}&date2=${date2}`, {
        })
        const { data } = response
        console.log('DATA', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    /*async getSoldServiceCount({ commit }, serviceId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('services/'+serviceId+'/sold', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },*/
  },
}
