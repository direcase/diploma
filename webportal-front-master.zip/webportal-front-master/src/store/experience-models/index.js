/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllExperienceModelsPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`experience-models?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async addExperienceModel({ commit }, {name, coefficient}) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('experience-models', {
          name,
          coefficient,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async updateExperienceModel({ commit }, { id, name, coefficient} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('experience-models/'+id, {
          id,
          name,
          coefficient,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteExperienceModel({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('experience-models/'+id, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchExperienceModelById({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('experience-models/'+id, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
