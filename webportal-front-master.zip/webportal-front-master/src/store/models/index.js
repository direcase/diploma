/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllModelsPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`models?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        console.log('Service Centers', data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllModels({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('models/select', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem.name, value: elem.id})
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async addModel({ commit }, { name }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('models', {
          name
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async updateModel({ commit }, { id, name} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('models/'+id, {
          id,
          name,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteModel({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('models/'+id, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchModelById({ commit }, modelId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('models/'+modelId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
