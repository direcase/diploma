import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllServiceCenters({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`service-centers?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchAllServiceCentersUsers({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, serviceCenterId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`service-centers/${serviceCenterId}/users?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchAllServiceCentersExperienceModels({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, serviceCenterId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`service-centers/${serviceCenterId}/experience-models?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async addServiceCenter({ commit }, {
      name, address, phoneNumber, comment, email,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('service-centers', {
          name,
          address,
          phoneNumber,
          comment,
          email,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line no-dupe-keys
    async addServiceCenterUser({ commit }, {
      name, surname, username, password, roles, phoneNumber, experienceModelId, serviceCenterId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put(`service-centers/${serviceCenterId}/users`, {
          name,
          surname,
          username,
          password,
          roles,
          phoneNumber,
          experienceModelId,
          serviceCenterId,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async addServiceCenterExperienceModel({ commit }, {
      name, coefficient, serviceCenterId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put(`service-centers/${serviceCenterId}/experience-models`, {
          name,
          coefficient,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchServiceCenterById({ commit }, serviceCenterId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`service-centers/${serviceCenterId}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchServiceCenterUserById({ commit }, { serviceCenterId, userId }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`service-centers/${serviceCenterId}/users/${userId}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async deleteServiceCenterById({ commit }, serviceCenterId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete(`service-centers/${serviceCenterId}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async updateServiceCenter({ commit }, {
      id, name, address, phoneNumber, isEnabled, comment, email,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post(`service-centers/${id}`, {
          id,
          name,
          address,
          phoneNumber,
          isEnabled,
          comment,
          email,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchAllExperienceModelServiceCenter({ commit }, serviceCenterId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`service-centers/${serviceCenterId}/experience-models/list`, {
        })
        const { data } = response
        const newDate = []
        data.forEach(elem => {
          newDate.push({ label: elem.name, value: elem })
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchAllRolesServiceCenter({ commit }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('service-centers/roles/all', {
        })
        const { data } = response
        const newDate = []
        data.forEach(elem => {
          newDate.push({ label: elem, value: elem })
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
