/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllOrdersPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`orders?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchAllOrdersByStatusPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, status,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`orders/status?status=${status}&sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async fetchAllClientOrdersPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, clientId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`clients/${clientId}/orders?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllOrdersByStatus({ commit }, status) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('orders/status?status='+status, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchOrderById({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('orders/'+id, {
        })
        const { data } = response
        console.log('ORDER', data)
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchOrderByIdAndToken({ commit }, {id, token}) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('client/order/'+id+'/'+token, {
        })
        const { data } = response
        console.log('ORDER', data)
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async addOrder({ commit }, { clientId, client_number, discount_id, model_id, type_id, problem, modelType, serialNumber } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.put('orders', {
          clientId,
          client_number,
          discount_id,
          model_id,
          type_id,
          problem,
          modelType,
          serialNumber
        }))
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async updateOrder({ commit }, { clientId, client_number, discount_id, model_id, type_id, problem, modelType, id, serialNumber } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.post('orders/'+id, {
          clientId,
          client_number,
          discount_id,
          model_id,
          type_id,
          problem,
          modelType,
          serialNumber,
        }))
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteOrder( { commit }, orderId) {
      try{
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.delete('orders/'+orderId, {}))
        const { data } = response
        console.log(data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async addOrderItemProduct({ commit }, { productId,quantity, id } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.post('orders/'+id+"/add/product", {
          product_id: productId,
          quantity,
        }))
        const { data } = response
        console.log(data)
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async addMessage({ commit }, { message, orderId } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.post('orders/'+orderId+"/comment", {
          comment: message
        }))
        const { data } = response
        console.log(data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async orderDone({ commit }, orderId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.get('orders/'+orderId+"/done"))
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchOrdersCount({ commit },) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('orders/count', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchNetProfit({ commit },) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('orders/net-profit', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    /*async fetchNetProfit({ commit },) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('orders/net-profit', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },*/
    async orderGiven({ commit }, { orderId, paymentType }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.get('orders/'+orderId+"/payment?type=" + paymentType))
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async waitPayment({ commit }, orderId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.get('orders/'+orderId+"/cashier"))
        const { data } = response
        console.log(data)
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async notify({ commit }, orderId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.get('orders/'+orderId+"/notify"))
        const { data } = response
        console.log(data)
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async addOrderItemService({ commit }, { serviceId,quantity, id } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.post('orders/'+id+"/add/service", {
          service_id: serviceId,
          quantity,
        }))
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async removeOrderItem({ commit }, { orderId, itemId} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = (await axios.delete('orders/' + orderId + '/' + itemId, {
        }))
        const { data } = response
        console.log(data)
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
  },
}
