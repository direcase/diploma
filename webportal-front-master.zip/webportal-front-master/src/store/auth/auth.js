import axios from 'axios'

export default {
  actions: {
    async login({
      // eslint-disable-next-line no-unused-vars
      dispatch,
      // eslint-disable-next-line no-unused-vars
      commit,
    }, {
      username,
      password,
    }) {
      try {
        // eslint-disable-next-line no-const-assign
        const response = await axios.post('auth', {
          username,
          password,
        })
        const { data } = response
        localStorage.setItem('token', data.token.token)
        commit('setUser', data.user)
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async logout({ commit }) {
      await commit('clearUser')
      await localStorage.removeItem('token')
    },
  },
}
