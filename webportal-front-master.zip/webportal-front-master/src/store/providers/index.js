/* eslint-disable */
import axios from 'axios'

export default {
  actions: {
    // eslint-disable-next-line consistent-return
    async fetchAllProviderPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`providers?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllProviders({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('providers/select', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem.name, value: elem.id, address: elem.address, phoneNumber: elem.phoneNumber})
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async updateProvider({ commit }, { id, name, address, phoneNumber } ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post('providers/'+id, {
          id,
          name,
          address,
          phoneNumber,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchProviderById({ commit }, providerId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('providers/'+providerId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async addProvider({ commit }, { provider_name, provider_address, provider_telephone} ) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put('providers', {
          name: provider_name,
          address: provider_address,
          phoneNumber: provider_telephone,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async deleteProvider({ commit }, id) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete('providers/'+id, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
  },
}
