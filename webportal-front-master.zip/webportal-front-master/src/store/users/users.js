/* eslint-disable */
import axios from 'axios'

export default {
  state: {
    user: {

    },
  },
  mutations: {
    setUser(state, user) {
      state.user = user
    },
    clearUser(state) {
      state.user = {}
    },
  },
  actions: {
    async fetchCurrentUser({ commit }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('users/current', {
        })
        const { data } = response
        commit('setUser', data)
      } catch (e) {
        commit('setError', e)
      }
    },
    // eslint-disable-next-line consistent-return
    async updateUser({ commit }, {
      id, name, surname, username, password, roles, phoneNumber, experienceModelId, enabled,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.post(`users/${id}`, {
          id,
          name,
          surname,
          username,
          password,
          roles,
          phoneNumber,
          experienceModelId,
          enabled,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    // eslint-disable-next-line consistent-return
    async deleteUser({ commit }, userId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.delete(`users/${userId}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchUserById({ commit }, userId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('users/'+userId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
    async fetchMastersAllProfit({ commit }, userId) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('orders/profit-users/'+userId, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllUsersPagination({ commit }, {
      sortBy, currentPage, sortDirection, perPage, filter, serviceCenterId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get(`users?sortBy=${sortBy}&page=${currentPage}&size=${perPage}&orderBy=${sortDirection}&title=${filter}`, {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllUsersForSelect({ commit }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('users/select', {
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllRoles({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('users/roles/all', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem, value: elem})
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async fetchAllExperiences({ commit },ctx, queryParams) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.get('experience-models/select', {
        })
        const { data } = response
        let newDate = []
        data.forEach(elem => {
          newDate.push({label: elem.name, value: elem.id})
        })
        return newDate
      } catch (e) {
        commit('setError', e)
      }
    },
    async addUser({ commit }, {
      name, surname, username, password, roles, phoneNumber, experienceModelId,
    }) {
      try {
        axios.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem('token')}`
        const response = await axios.put(`users`, {
          name,
          surname,
          username,
          password,
          roles,
          phoneNumber,
          experienceModelId,
        })
        const { data } = response
        return data
      } catch (e) {
        commit('setError', e)
        throw e
      }
    },
  },
  getters: {
    user: s => s.user,
  },
}
