<template>
  <div class="text-center d-flex justify-content-center align-items-center">
    <b-spinner
      :variant="color"
      type="grow"
    />
  </div>
</template>

<script>
import {
  BSpinner,
} from 'bootstrap-vue'

export default {
  name: 'LoaderVue',
  computed: {
    color() {
      const colors = ['primary', 'secondary', 'danger', 'warning', 'success', 'info', 'light', 'dark']
      return colors[Math.floor(Math.random() * 3)]
    },
  },
  components: {
    BSpinner,
  },
}
</script>

<style scoped>

</style>
