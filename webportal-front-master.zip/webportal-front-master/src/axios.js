/* eslint-disable */
import axios from 'axios'

axios.defaults.baseURL = 'http://192.168.1.112:8090/api/v1/'
axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*'

axios.interceptors.response.use(
  function (response) {
    return response
},
function (error,response) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    return Promise.reject(error)}
)


