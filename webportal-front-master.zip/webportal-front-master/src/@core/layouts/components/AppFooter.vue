<template>
  <p class="clearfix mb-0">
    <span class="float-md-left d-block d-md-inline-block mt-25">
      АВТОРСКИЕ ПРАВА  © {{ new Date().getFullYear() }}
      <b-link
        class="ml-25"
        href="https://instagram.com/webportal_aksukent?igshid=1v48u9vdt3528"
        target="_blank"
      >Webportal</b-link>
      <span class="d-none d-sm-inline-block">, Все права защищены</span>
    </span>

    <span class="float-md-right d-none d-md-block">Ручная работа Сделано с
      <feather-icon
        icon="HeartIcon"
        size="21"
        class="text-danger stroke-current"
      />
    </span>
  </p>
</template>

<script>
import { BLink } from 'bootstrap-vue'

export default {
  components: {
    BLink,
  },
}
</script>
