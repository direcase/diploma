package com.crm.servicebackend.dto.responseDto.product;

import lombok.Data;

@Data
public class ProductItemDtoResponse {
    private Long id;
    private String name;
}
