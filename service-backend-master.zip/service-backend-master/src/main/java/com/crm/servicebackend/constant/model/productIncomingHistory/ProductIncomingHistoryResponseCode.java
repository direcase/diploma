package com.crm.servicebackend.constant.model.productIncomingHistory;

public class ProductIncomingHistoryResponseCode {
    public static final String PRODUCT_INCOMING_HISTORY_NOT_FOUND_CODE = "incoming-history/not-found";
    public static final String PRODUCT_NOT_ENOUGH_IN_STORAGE_CODE = "incoming-history/not-enough-in-storage";
}
