package com.crm.servicebackend.dto.responseDto.statistics;

public interface SoldItemCount {
    int getCount();
}
