package com.crm.servicebackend.dto.responseDto.report;

public interface GivenOrderSum {
    double getOrderSum();
    double getNetProfitSum();
}
