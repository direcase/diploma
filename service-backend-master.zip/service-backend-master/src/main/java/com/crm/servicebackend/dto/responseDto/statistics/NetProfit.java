package com.crm.servicebackend.dto.responseDto.statistics;

public interface NetProfit {
    int getProfit();
}
