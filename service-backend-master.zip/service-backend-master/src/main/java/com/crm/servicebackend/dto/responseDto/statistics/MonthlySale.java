package com.crm.servicebackend.dto.responseDto.statistics;

public interface MonthlySale {
    int getMonth();
    int getCount();
}
