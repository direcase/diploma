package com.crm.servicebackend.dto.responseDto.statistics;

public interface Profit {
    int getProfit();
}
