package com.crm.servicebackend.dto.responseDto.statistics;

public interface TopSaleItem {
    Long getId();
    String getName();
    int getCount();
}
