package com.crm.servicebackend.dto.responseDto.experienceModel;

import lombok.Data;

@Data
public class ExperienceModelDtoResponse {
    private Long id;
    private String name;
    private int coefficient;
}
