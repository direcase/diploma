package com.crm.servicebackend.constant.model.document;

public class DocumentValidationConstants {
    public static final String FIELD_ORDER_ID_REQUIRED_MESSAGE = "Поле id заказа обязательно.";
    public static final String FIELD_DOCUMENT_TYPE_REQUIRED_MESSAGE = "Поле тип документа обязательно.";
    public static final String FIELD_DOCUMENT_ID_REQUIRED_MESSAGE = "Поле id обязательно";
    public static final String FIELD_DOCUMENT_STATUS_REQUIRED_MESSAGE = "Поле статус документа обязательно";
}
