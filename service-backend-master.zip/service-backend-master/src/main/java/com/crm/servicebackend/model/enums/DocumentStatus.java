package com.crm.servicebackend.model.enums;

public enum DocumentStatus {
    CREATED, PRINTED, SIGNED
}
