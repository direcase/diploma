package com.crm.servicebackend.dto.responseDto.model;

import lombok.Data;

@Data
public class ModelDtoResponse {
    private Long id;
    private String name;
}
