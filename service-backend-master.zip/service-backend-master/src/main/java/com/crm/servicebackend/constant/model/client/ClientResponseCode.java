package com.crm.servicebackend.constant.model.client;

public class ClientResponseCode {
    public static final String CLIENT_NOT_FOUND_CODE = "client/not-found";
    public static final String CLIENT_DELETED_CODE = "client/deleted";
    public static final String CLIENT_TWO_ANOTHER_ID_CODE = "client/two-another-id";
}
