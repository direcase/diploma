package com.crm.servicebackend.dto.responseDto.service;

import lombok.Data;

@Data
public class ServiceItemDtoResponse {
    private Long id;
    private String name;
}
