package com.crm.servicebackend.dto.responseDto.type;

import lombok.Data;

@Data
public class TypeDtoResponse {
    private Long id;
    private String name;
}
