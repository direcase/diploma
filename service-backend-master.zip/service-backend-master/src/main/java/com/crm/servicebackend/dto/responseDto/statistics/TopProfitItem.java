package com.crm.servicebackend.dto.responseDto.statistics;

public interface TopProfitItem {
    Long getId();
    String getName();
    int getProfit();
}
