package com.crm.servicebackend.model.enums;

public enum TypesOfPayments {
    cash,contract,online;
}
