package com.crm.servicebackend.constant.model.type;

public class TypeResponseCode {
    public static final String TYPE_NOT_FOUND_CODE = "type/not-found";
    public static final String TYPE_TWO_ANOTHER_ID_CODE = "type/two-another-id";
    public static final String TYPE_DELETED_CODE = "type/deleted";
    public static final String TYPE_EXISTS_BY_NAME_CODE = "type/exists-by-name";
}
