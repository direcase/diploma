package com.crm.servicebackend.constant.model.storage;

public class StorageResponseCode {
    public static final String PRODUCT_STORAGE_NOT_ENOUGH_CODE = "storage/product-not-enough";
}
