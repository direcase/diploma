package com.crm.servicebackend.dto.responseDto.user;

import lombok.Data;

@Data
public class UserForSelectDtoResponse {
    private Long value;
    private String surname;
    private String name;
}
