package com.crm.servicebackend.dto.responseDto.statistics;

public interface Sold {
    int getSoldCount();
}
