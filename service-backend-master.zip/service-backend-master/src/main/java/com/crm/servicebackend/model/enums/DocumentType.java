package com.crm.servicebackend.model.enums;

public enum DocumentType {
    ACCEPTANCE_CERTIFICATE, CERTIFICATE_OF_COMPLETION
}
