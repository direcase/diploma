package com.crm.servicebackend.constant.model.orderItem;

public class OrderItemResponseCode {
    public static final String ORDER_ITEM_NOT_FOUND_CODE = "order-item/not-found";
    public static final String ORDER_ITEM_DELETED_CODE = "order/order-item/successfully-deleted";
}
