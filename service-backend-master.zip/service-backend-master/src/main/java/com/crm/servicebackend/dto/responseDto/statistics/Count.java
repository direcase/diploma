package com.crm.servicebackend.dto.responseDto.statistics;

public interface Count {
    int getCount();
}
